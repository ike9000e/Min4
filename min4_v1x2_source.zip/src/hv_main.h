
#include "hef/hef_timeout_srv.h"
#include "hv_wnd_g.h"
#include "hv_cfg.h"

namespace hef{}
using namespace hef;

extern HfTimeoutSrv* TimeoutSrvGlob;
struct HvX11Pixmap;

/// The main window of the program.
class HvWnd
	: public HvGnuWnd, public sigslot::has_slots<>
	, HvQueryImageMode
{
	struct SFile;
public:
	;            HvWnd( int argc, const char*const* argv );
	virtual      ~HvWnd();
	int          exec2();
	bool         isValid( std::string* err = 0 )const;
	const char*  getMessage()const {return Success2.second.c_str();}
private:
	void         repaintWindowAt( const HfRct& xywh );
	void         repaintEntireWindow();
//	void         clearAreasGivenMouseDelta( const HfRct&, const HfPt& mouseDelta );
	void         innerImageRectChange( int mode2, int flags2 );
//	void         soDtRedrawTmo( HfTimeoutSrv::STimeout inp );
	void         clearDtRedrawTimeoutIfAny();
	void         loadNextImage( int direction2 );
	auto         isCurrentFirstLast()const -> std::pair<bool,bool>;
	void         initialFilelistSort();
	void         showHelp();
	auto         computeFileIndex( int ident3 )const -> std::pair<int,const SFile*>;
	// interfaces: HvIWnd, HvGnuWnd, HvQueryImageMode
	virtual void itwOnUserInput( const HvIWndUserInput& inp )override;
	virtual void itwOnRectRepaint( const HvIWndRectRepaint& inp )override;
	virtual void itwOnNewGeometry( const HvIWndNewGeometry& inp )override;
	virtual void postEventPerform()override;
	virtual int  getTimeoutMsForSelect()override;
	virtual bool qimGetAntiAliasForScale( float fScale )const override;
	//
	void         level2FitInFrame( int flags3 );
	void         level2CenterInFrame( int flags3 );
	void         level2CenterOrFitInFrame( int flags3 );
	void         level2PanOrMoveImage( const HfPt& mousedelta );
	void         level3UpdateMetricsInFrame( int flags3 );
	HfRct        convToValidGeometry( const HfRct& inp, const char* szFlags2 );
	HfRct        convMaximize2ToValidGeometry( float fFrac, int e_maximize_mode );
	void         getDirItemsFromInitialFile( const char* szFilename );
	std::string  getCurrentWindowTitle( const std::string ssStatusTag )const;
	void         updateCurrentWindowTitle( const std::string ssStatusTag, int uSkipIfFlags = 0 );
private:
	enum{ EUZM_ZoomReset = 1, EUZM_ZoomInStep, EUZM_ZoomOutStep, EUZM_Passthru, };
	enum{
		/// Flags for HvWnd::innerImageRectChange().
		EUZCF_SkipImageScaling = 0x1,
		EUZCF_SkipDirtyArClear = 0x2,
	};
	enum{
		/// Flags for HvWnd::level2FitInFrame() and
		/// HvWnd::level2CenterInFrame().
		EIFMF_ClearWindowArea = 0x2,
	};
	struct SMouseDrag{
		bool first;
		HfPt second;
		int iButton;  // mouse button, 1-based index on X11.
	};
	struct SFile{
		std::string       filename2;
		int               ident2;
		HvNatSortTokens_t tokenizedNs;
		SFile( const char* fnm, int id_ ) : filename2(fnm), ident2(id_) {}
	};
	std::pair<bool,std::string>    Success2 = {0,"",};//, _Maximize2 = {0,"",};
	HvOpts*                        Opt = 0;
	HvDpy*                         Dpy = 0;//Display*
	HvGC                           Gcx = 0;//GC
	HvWid                          Wid = 0;//Window
	int                            ScreenBpp = 0;
	std::pair<int,int>             Maximize2 = {0,0,};
	std::pair<int,HfDim>           DesktopRezFs = {0,{0,0,},};
	HvX11Pixmap*                   Img = 0;  //HvImage*, HvX11Pixmap*, HvImlibImage*
	SMouseDrag                     MouseDrag = {0,{0,0,},0,};
	HvComposedBox3                 Imt4;
	HfRct                          SubRect = {0,0,-1,-1,};
	const int                      FrameBorderSize = 23;
	int                            RedrawTmoId = 0;
	std::vector<SFile>             Files2;
	std::pair<int,int>             CurrFileId = {0,1001,};//<current-id,next-id>
	float                          Scale2 = 1.0f;
	uint32_t                       ClrBckg2 = 0xFFBB8080;
}; // HvWnd




