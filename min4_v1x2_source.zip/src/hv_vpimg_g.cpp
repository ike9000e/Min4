#include "hv_vpimg_g.h"
#include <assert.h>
#include <string.h>
#include "xehi_linux_helper.h"
#include "hv_ildr.h"
#include "hv_ildr_p.h"
#include "hef/hef_str.h"
#include "hef/hef_data.h"
#include "Imlib2.h"
//#include <unistd.h> //usleep()

HvX11Image::~HvX11Image()
{
	clearImageIfAny2();
}
// Progressive loading callbacks
//typedef int (*Imlib_Progress_Function) (Imlib_Image im, char percent,
//                                        int update_x, int update_y,
//                                        int update_w, int update_h);

bool HvX11Image::loadImage2( const char* filename )
{
	bool res = 0;
	clearImageIfAny2();
	uint32_t tm2 = 0, tm4 = hf_getGlobalTicks();
	{
	/*	Imlib_Image img3 = imlib_load_image_immediately_without_cache( filename );
		if(img3){
			//ImgImlib1x
			imlib_context_set_image(img3);
			Dim.w = Dim1x.w = imlib_image_get_width();
			Dim.h = Dim1x.h = imlib_image_get_height();
			Pixels1x.resize( Dim1x.w * Dim1x.h );
			const uint32_t* data3 = imlib_image_get_data_for_reading_only();
			assert( data3 );
			memcpy( &Pixels1x[0], data3, ( Pixels1x.size() * sizeof(Pixels1x[0]) ) );
			imlib_free_image();
			res = 1;
		}//*/
	}
	if( !res ){
		assert(!"JPEG and PNG not implemented [0AFJThU1jw]");
	/*	int nAdded = 0;
		uint32_t tm3;
		auto fnc = [&]( const HvImageReadInfo& inf )->bool{
				//printf("scanline y:%d/%d, w:%d, s:%d\n", inf.uRow+1, inf.nNumRows, inf.nNumCols, inf.nRowStride );
				if( ((tm3 = hf_getGlobalTicks()) - tm2) >= 100 ){
					printf("\r%.2f", ((float(inf.uRow) / inf.nNumRows)*100.f) );
					fflush( stdout );
					tm2 = tm3;
				}
				if( !inf.uRow ){
					Dim.w = Dim1x.w = inf.nNumCols;
					Dim.h = Dim1x.h = inf.nNumRows;
					Pixels1x.resize( Dim1x.w * Dim1x.h );
				}
				memcpy( &Pixels1x[nAdded], &inf.aLinePxs[0], (Dim1x.w*sizeof(inf.aLinePxs[0])) );
				nAdded += Dim1x.w;
				//usleep_(1000);
				return 1;
		};
		std::string ext2 = hf_toLowerAsAscii( hf_basename3(filename).second.c_str() );
		if( ext2 == "png" ){
			res = HvPNGReadFile( filename, fnc );
		}else{
			res = HvJPEGReadFile( filename, fnc );
		}
		//*/
	}
	tm2 = hf_getGlobalTicks();
	printf("\r100.00%% | %.2f""s\n", ( float(tm2-tm4) / 1000.f ) );
	return res;
}
/*
void drawPixelsNoPixmap()
{
	if( !Img.aPixels_.empty() ){
		int wdt = 0, hgt = 0;
		xehi_GetWindowWHXY( Dpy_, Wid, &wdt,&hgt, 0,0, 0 );
		std::vector<unsigned long>::const_iterator a;
		size_t W = Img.aPixels_[0], H = Img.aPixels_[1];
		const unsigned long* pxs_ = &Img.aPixels_[2];
		for( size_t y=0; y<H &&  y < static_cast<size_t>(hgt) ; y++ ){
			for( size_t x=0; x<W &&  x < static_cast<size_t>(wdt) ; x++ ){
				unsigned long px = pxs_[x + y * W];
				XSetForeground( Dpy_, Gcx, px );
				XDrawPoint( Dpy_, Wid, Gcx, x, y );
			}
		}
	}
}//*/

void HvX11Image::clearImageIfAny2()
{
	freePixmapIfAny();
	Pixels2.clear();
	Pixels1x.clear();
	//fScale_ = 1.0f;
	Dim1x = HfDim(0,0);
	Dim = HfDim(0,0);
	ZoomMode2 = HV_EPXMSM_Orig;
}

bool HvX11Pixmap::
drawImageWithin( HvWid wid, const HfRct& frame3, HvGC gcx, const HfPt& xyy )
{
	//printf("frame3: %s\n", frame3.toStr().c_str() );
	if( Pxm ){
		HfDim dim = ipmGetDim();
		HfRct ri2 = { xyy.x, xyy.y, dim.w, dim.h, };
		HfRct frame4 = frame3;
		if( frame4.isEmpty2() ){
			HfDim wdd = HfDim().fromStdPair( xehi_GetWindowWHXY2(
					HvToDpy2(ipmDisplay()), wid,"wh") );
			frame4 = HfRct{0,0,wdd.w,wdd.h,};
		}
		HfPt pos;
		HfRct r = ri2.filterInViewPort( frame4, &pos, 0 );
		XCopyArea( HvToDpy2(ipmDisplay()), Pxm, wid, HvToGcx2(gcx), r.x, r.y, r.w, r.h, pos.x, pos.y );
		return 1;
	}
	return 0;
}
void HvX11Pixmap::freePixmapIfAny()
{
	if( Pxm ){
		HvDpy* dpy = ipmDisplay(); //Display*
		assert( dpy );
		XFreePixmap( HvToDpy2(dpy), Pxm );
		Pxm = 0;
	}
}
bool HvX11Pixmap::reloadPixmap2( HvDpy* dpy, HvWid wid, HvGC gcx ) //reloadPixmap()
{
	freePixmapIfAny();
	assert( dpy );
	ipmDisplay( dpy );   //Dpy=dpy;
	{
		// HV_EPXMSM_Orig, else HV_EPXMSM_UseZoom
		const uint32_t* pxs = ( ipmGetDrawMode() == HV_EPXMSM_Orig ? ipmGetPixels1x() : ipmGetPixels());
		const HfDim     dim = ( ipmGetDrawMode() == HV_EPXMSM_Orig ? ipmGetDim1x() : ipmGetDim() );
		const unsigned int w = dim.w, h = dim.h;
		static const int nBitmapPad = 32; // 32 for 24 and 32 bpp, 16 for 15 and 16.
		assert( !Pxm );
		XImage* ximage2 = XCreateImage( HvToDpy2(dpy), CopyFromParent, 24, ZPixmap,
				0, const_cast<char*>(reinterpret_cast<const char*>( pxs )),
				w, h, nBitmapPad, w * sizeof(pxs[0]) );
		assert( pxs == reinterpret_cast<uint32_t*>(ximage2->data) );
		Pxm = XCreatePixmap( HvToDpy2(ipmDisplay()), wid, w, h, 24 );//24
		XPutImage( HvToDpy2(dpy), Pxm, HvToGcx2(gcx), ximage2, 0,0,0,0, w, h );
		XFree( ximage2 );
	}
	return 1;
}
/*bool HvX11Image::rescaleTo4( const HfDim& whScaleTo, HvWid wid, HvGC gcx )
{
	if( whScaleTo == Dim1x ){
		Dim = Dim1x;
		ZoomMode2 = HV_EPXMSM_Orig;
	}else{
		Dim = whScaleTo;
		ZoomMode2 = HV_EPXMSM_UseZoom;
		HvImageResampleOption( Pixels1x, Dim1x.w, Dim1x.h, Pixels2, Dim.w, Dim.h, 0, 0 );
	}
	return reloadPixmap2( Dpy, wid, gcx );
}//*/
/*bool HvX11Image::rescaleTo( float fScale2, HvWid wid, HvGC gcx )
{
	HfDim dim = { int(float(Dim1x.w) * fScale2), int(float(Dim1x.h) * fScale2), };
	return rescaleTo4( dim, wid, gcx );
}//*/
/// Rescales image given inner rectangle and new dimension.
/// Inner portion, the clip-rectangle, gets upscaled to dimension
/// specified by 'whRescaleTo'.
/// Input new dimension ('whRescaleTo') becomes the image dimension untill image
/// gets changed in some other way.
bool HvX11Image::
rescaleTo2( HvWid wid, HvGC gcx, const HfRct& clipAreaSel, const HfDim& whRescaleTo )
{
	HfRct clip2 = clipAreaSel;
	if( clip2.x >= Dim1x.w || clip2.y >= Dim1x.h || clip2.isEmpty2() || clip2.x < 0 || clip2.y < 0 ){
		printf("WARNING: rectangle clipAreaSel is invalid (%s(%d)) [WH1rGsDR]\n", hf_basename(__FILE__), __LINE__ );
		return 0;
	}
	// trim input rect to include only valid own image portion, if needed.
	HfRct clip3 = clip2.getClipped( {0,0,Dim1x.w,Dim1x.h,} );
	if( clip3 != clip2 ){
		//printf("WARNING: rectangle clip3 != clip2 (%s(%d)).\n", hf_basename(__FILE__), __LINE__ );
	}
	Pixels2.resize( clip3.w * clip3.h );
	// iterate over original, unscalled pixels 'Pixels1x' copying
	// clipped, yet unscaled, region onto 'Pixels2'.
	for( int cy = clip3.y, ky=0; ky < clip3.h; cy++, ky++ ){
		for( int cx = clip3.x, kx=0; kx < clip3.w; cx++, kx++ ){
			int i2 = ky * clip3.w + kx;
			assert( i2 < (int)Pixels2.size() );
			int i3 = cy * Dim1x.w + cx;
			assert( i3 < (int)Pixels1x.size() );
			Pixels2[i2] = Pixels1x[i3];
		}
	}
	std::vector<uint32_t> pxs2;
	pxs2.resize( whRescaleTo.w * whRescaleTo.h );
	HvImageResampleOption( Pixels2, clip3.w, clip3.h,
					pxs2, whRescaleTo.w, whRescaleTo.h, 0, 0 );
	std::swap( pxs2, Pixels2 );
	Dim = { whRescaleTo.w, whRescaleTo.h, };
	ZoomMode2 = HV_EPXMSM_UseZoom;
	return reloadPixmap2( Dpy, wid, gcx );
}
void HvX11Image::
rescaleTo3_ToSmaler( float fInitialZoom, const HfRct& rect2,
						const HfDim& rescaleToWH, uint32_t dfltPixel )
{
	HfRct rect4 = { -rect2.x, -rect2.y,
			int(float(rect2.w) * fInitialZoom), int(float(rect2.h) * fInitialZoom), };
	HfDim dim4 = Dim1x * fInitialZoom;
	//printf("rect4: %s, dim4:%s\n", rect4.toStr().c_str(), dim4.toStr().c_str() );
	{	// resize optimized, more lines but not using clear() call.
		size_t numpixels2 = rescaleToWH.w * rescaleToWH.h;
		std::fill_n( Pixels2.begin(), std::min( numpixels2, Pixels2.size() ), dfltPixel );
		Pixels2.resize( numpixels2, dfltPixel );
	}
	if( rect4.x + dim4.w < 0 || rect4.y + dim4.h < 0 || rect4.x > rescaleToWH.w || rect4.y > rescaleToWH.h ){
		// enters here if all of the edges of the selected rectangle are outside.
		//printf("%s(), L:%d, outside\n", __func__, __LINE__ );
	}else{
		// rescaale orig image to new (smaller) to put inside the output rectangle.
		std::vector<uint32_t> pxs3;
		HvImageResampleOption( Pixels1x, Dim1x.w, Dim1x.h, pxs3, dim4.w, dim4.h, 0, 0 );
		for( int cy = rect4.y, sy=0; sy < dim4.h; cy++, sy++ ){ // iterate Y direction.
			for( int cx = rect4.x, sx=0; sx < dim4.w; cx++, sx++ ){ // iterate X direction.
				int i2 = sy * dim4.w + sx;
				assert( i2 < (int)pxs3.size() );
				if( rescaleToWH.isPointInside( {cx,cy,} ) ){
					int i3 = cy * rescaleToWH.w + cx;
					assert( i3 < (int)Pixels2.size() );
					Pixels2[i3] = pxs3[i2];
				}
			}
		}
	}
}
void HvX11Image::
rescaleTo3_ToLarger( float fInitialZoom, const HfRct& rect2,
						const HfDim& rescaleToWH, uint32_t dfltPixel )
{
	HfRct region3 = rect2 / fInitialZoom;
	//HfRct region3 = { rect2.x, rect2.y, rect2.w / fInitialZoom, rect2.h / fInitialZoom, };
	const int numpixels = region3.w * region3.h;
	//printf("l:%d, region3: %s\n", __LINE__, region3.toStr().c_str() );
	std::vector<uint32_t> pxs2( numpixels );
	for( int cy = region3.y, ty=0; ty < region3.h; cy++, ty++ ){ // iterate Y direction.
		for( int cx = region3.x, tx=0; tx < region3.w; cx++, tx++ ){ // iterate X direction.
			int i2 = ty * region3.w + tx;
			assert( i2 < (int)pxs2.size() );
			//if( cx >= 0 && cx < Dim1x.w && cy >= 0 && cy < Dim1x.h )
			if( Dim1x.isPointInside( {cx,cy,} ) ){
				int i3 = cy * Dim1x.w + cx;
				assert( i3 < (int)Pixels1x.size() );
				pxs2[i2] = Pixels1x[i3];
			}else{
				pxs2[i2] = dfltPixel;
			}
		}
	}
	if( !Pixels1x.empty() ){
		assert( !pxs2.empty() );
	}
	HvImageResampleOption( pxs2, region3.w, region3.h,
						Pixels2, rescaleToWH.w, rescaleToWH.h, 0, 0 );
}
/**
	Rescales image given zoom level, inner clip-rectangle and new dimension.

	Input new dimension ('rescaleToWH') becomes the image dimension untill image
	gets changed in some other way.

	\param fInitialZoom - zoom level. values greater than 1.0 produce zoom-in.
	\param rect2        - rectangle of the image in already zommed-in region,
	&nbsp;                specified by 'fInitialZoom'.
	&nbsp;                Components x and y can be set to negative values
	&nbsp;                to include part outsode of the image, to the left.
	&nbsp;                And similarly, w and h can include empty part to the right.
	\param rescaleToWH  - size to rescale to, resulting dimensions.
	\param flags2       - not used.
	\param dfltColor    - default color of pixels that arent copied from
	&nbsp;                the original pixels, are outside. actually, all coords
	&nbsp;                less 0 or; 'x' or 'y' greater than width or height respectivelly.

	Steps performed:
	+ 1. starts by using zoom level ('fInitialZoom') on the original pixels.
	+ 2. selects rectangle of pixels ('rect2') inside zoommed image (from step #1).
	+ 3. copies them into new memory location.
	+ 4. rescales copied pixels to dimensions specified by 'rescaleToWH'.

	Note that for step #1 there is no corresponding operation inside the code,
	it is discrete.
*/
bool HvX11Image::
rescaleTo3( HvWid wid, HvGC gcx, float fInitialZoom, const HfRct& rect2,
						const HfDim& rescaleToWH, int flags2, uint32_t dfltPixel )
{
	// using different algorithm for when <1.0f bcos it would use
	// temporary pixel buffers significantly larger than the size of original,
	// unscalled image.
	// Nonetheless, both algo would still produce correctly re-scalled images.
	// This has been tested both ways, using rescaleTo3_ToLarger() to downscale and
	// using rescaleTo3_ToSmaler() to upscale. Both are producing correct results.
	if( fInitialZoom >= 1.0f ){
		rescaleTo3_ToLarger( fInitialZoom, rect2, rescaleToWH, dfltPixel );
	}else{ // else < 1.0f - downscalling.
		rescaleTo3_ToSmaler( fInitialZoom, rect2, rescaleToWH, dfltPixel );
	}
	Dim = { rescaleToWH.w, rescaleToWH.h, };
	ZoomMode2 = HV_EPXMSM_UseZoom;
	return reloadPixmap2( Dpy, wid, gcx );
}

// RED='\033[0;31m' // 0x1B = (octal) 033 //="\x1B\x5B\x30;31m"
// NC='\033[0m' # No Color = "\x1B\x5B\x30\x6D"
// BBlack='\033[1;30m' # Black bold
// ref: https://en.wikipedia.org/wiki/ANSI_escape_code
//const char* cTrmBlu = "\x1B\x5B\x31;31m";
//const char* cTrmNone = "\x1B\x5B\x30\x6D";//no-color.

/*
/// Resample rescale #5.
/// "rects_6part_clip_hfzjfue.png".
bool HvX11Image::
rescaleTo5( const HfPt& pos2, float fZoom, const HfDim& frameDim, int flags2, HvWid wid, HvGC gcx )
{
	HfRct sRct;
	HfDim dDim;
	std::tie( sRct, dDim ) = HvBoxToClippedAtPosZoomFrame( Dim1x, pos2, fZoom,
			HfRct( {0,0,}, frameDim ) );
	return rescaleTo2_( wid, gcx, sRct, dDim );
}//*/

uint32_t HvX11Pixmap::ioBackgroundColor( bool bSet, uint32_t clr )
{
	if( bSet ){
		BkgColor = clr;
	}
	return BkgColor;
}

HvImlibImage::~HvImlibImage()
{
	clearImageIfAny2();
}
void HvImlibImage::clearImageIfAny2()
{
	clearImlibImageIfAny();
	clearImlibImage1xIfAny();
	HvX11Image::clearImageIfAny2();
}
const uint32_t* HvImlibImage::ipmGetPixels()const
{
	if( ImgImlib ){
		Imlib_Image img2 = reinterpret_cast<Imlib_Image>( ImgImlib );
		assert( img2 );
		imlib_context_set_image( img2 );

		imlib_image_set_irrelevant_alpha(0);
		imlib_image_set_has_alpha(1);
		assert( imlib_image_has_alpha() );

		const uint32_t* data2 = imlib_image_get_data_for_reading_only();
		assert( data2 );
		return data2;
	}else{
		return HvX11Image::ipmGetPixels();
	}
}
const uint32_t* HvImlibImage::ipmGetPixels1x()const
{
	if( ImgImlib1x ){
		Imlib_Image img4 = reinterpret_cast<Imlib_Image>( ImgImlib1x );
		assert( img4 );
		imlib_context_set_image( img4 );

		imlib_image_set_irrelevant_alpha(0);
		imlib_image_set_has_alpha(1);
		assert( imlib_image_has_alpha() );

		const uint32_t* data4 = imlib_image_get_data_for_reading_only();
		assert( data4 );
		return data4;
	}else{
		return HvX11Image::ipmGetPixels1x();
	}
}
void HvImlibImage::clearImlibImageIfAny()
{
	if( ImgImlib ){
		Imlib_Image img2 = reinterpret_cast<Imlib_Image>( ImgImlib );
		imlib_context_set_image( img2 );
		imlib_free_image();
		ImgImlib = img2 = 0;
	}
}
void HvImlibImage::clearImlibImage1xIfAny()
{
	if( ImgImlib1x ){
		Imlib_Image img2 = reinterpret_cast<Imlib_Image>( ImgImlib1x );
		imlib_context_set_image( img2 );
		imlib_free_image();
		ImgImlib1x = img2 = 0;
	}
}
/*uint32_t HvGetColorBasedOnDistanceSimple( uint32_t colorA, uint32_t colorB,
									float fClrDist )
{
	int r = ((colorA >> 16) & 0xFF);
	int g = ((colorA >> 8 ) & 0xFF);
	int b = ((colorA >> 0 ) & 0xFF);
	int r2 = ((colorB >> 16) & 0xFF);
	int g2 = ((colorB >> 8 ) & 0xFF);
	int b2 = ((colorB >> 0 ) & 0xFF);
	r = r2 - (r>r2 ? r-r2 : r2-r) * ( (fClrDist - 1.f) * -1.f );
	g = g2 - (g>g2 ? g-g2 : g2-g) * ( (fClrDist - 1.f) * -1.f );
	b = b2 - (b>b2 ? b-b2 : b2-b) * ( (fClrDist - 1.f) * -1.f );
	uint32_t ouu = ( ( r << 16 ) | ( g << 8 ) | b );
	return ouu;
}//*/

bool HvImlibImage::
rescaleTo2( HvWid wid, HvGC gcx, const HfRct& clipAreaSel, const HfDim& whRescaleTo )
{
	HfRct clip2 = clipAreaSel;
	if( clip2.x >= Dim1x.w || clip2.y >= Dim1x.h || clip2.isEmpty2() || clip2.x < 0 || clip2.y < 0 ){
		printf("WARNING: rectangle clipAreaSel is invalid (%s(%d)) [2Sd5W3nv]\n", hf_basename(__FILE__), __LINE__ );
		return 0;
	}
	float fZoomDetected = 0.0f;
	if( whRescaleTo.w == clipAreaSel.w && whRescaleTo.h == clipAreaSel.h ){
		fZoomDetected = 1.0f;
	}else{
		fZoomDetected = std::max<float>(
					(float(whRescaleTo.w) / clipAreaSel.w),
					(float(whRescaleTo.h) / clipAreaSel.h) );
	}
	bool bUseAA = 0;
	if( ioQueryImageModeIntrf() ){
		bUseAA = ioQueryImageModeIntrf()->qimGetAntiAliasForScale( fZoomDetected );
	}
	//printf("fZoomDetected: %f, bUseAA: %d\n", fZoomDetected, bUseAA );
	// trim input rect to include only valid own image portion, if needed.
	HfRct clip3 = clip2.getClipped( {0,0,Dim1x.w,Dim1x.h,} );
	clearImlibImageIfAny();

	// Imlib_Image imlib_create_image_using_data()
	// Imlib_Image imlib_create_image_using_copied_data()
	assert( ImgImlib1x );
	imlib_context_set_anti_alias( bUseAA );
	Imlib_Image buffer2 = ImgImlib1x;
//	Imlib_Image buffer2 = imlib_create_image_using_data(
//				ipmGetDim1x().w, ipmGetDim1x().h,
//				const_cast<uint32_t*>( ipmGetPixels1x() ) );   //Pixels1x
//
//	assert( buffer2 );
	imlib_context_set_image( buffer2 );
	imlib_image_set_has_alpha(1);
	Imlib_Image buffer4 = imlib_create_cropped_scaled_image(
					clip3.x, clip3.y, clip3.w, clip3.h,
					whRescaleTo.w, whRescaleTo.h );
	assert( buffer4 );
//	imlib_free_image();

	//imlib_image_tile(void)
	//imlib_context_set_blend()
	//imlib_context_set_display(disp);
	//imlib_context_set_visual(vis);
	//imlib_context_set_colormap(cm);
	//imlib_context_set_drawable(win);
	//imlib_context_set_operation()

	uint32_t clrb = ioBackgroundColor(); //eg. 0xFFB0C4DE

	Imlib_Image buffer5 = imlib_create_image( whRescaleTo.w, whRescaleTo.h );
	assert( buffer5 );
	imlib_context_set_image( buffer5 );
	imlib_image_set_has_alpha(1);
	imlib_context_set_color( (clrb>>16)&0xFF, (clrb>>8)&0xFF, clrb&0xFF, (clrb>>24)&0xFF );
	imlib_image_fill_rectangle( 0, 0, whRescaleTo.w, whRescaleTo.h );

	imlib_blend_image_onto_image( buffer4, 1, 0,0, whRescaleTo.w, whRescaleTo.h,
				0,0, whRescaleTo.w, whRescaleTo.h );

	imlib_context_set_image( buffer4 );
	imlib_free_image();

	assert( !ImgImlib );
	ImgImlib = buffer5;
	Dim = { whRescaleTo.w, whRescaleTo.h, };
	ZoomMode2 = HV_EPXMSM_UseZoom;
	return reloadPixmap2( Dpy, wid, gcx );
}
/*int HvImlibImage::calbImlib2Progr( void* im, char percent2, int update_x, int update_y,
						int update_w, int update_h )
{
	printf("p: perc:%d \n", (int)percent2 );
	return 1;
}//*/
bool HvImlibImage::loadImage2( const char* filename )
{
	bool res = 0;
	clearImageIfAny2();
	std::pair<char,Imlib_Progress_Function> params2 = { imlib_context_get_progress_granularity(), imlib_context_get_progress_function() };
	{
		uint32_t tm2 = 0, tm3 = hf_getGlobalTicks();
		//imlib_context_set_progress_function( calbImlib2Progr );
		imlib_context_set_progress_function( [&]( void* im, char percent2, int update_x, int update_y, int update_w, int update_h ){
					printf("\r%d", int(percent2) );
					fflush( stdout );
					//usleep(200);
					return 1;
				});
		// Value 0 seems to cause crashes - floating point exceptions -
		// despite official doc saying it's valid. Tested and crashes on a GIF
		// image loading, while no crash on any other image.
		imlib_context_set_progress_granularity( 1 );
		Imlib_Image img3 = imlib_load_image_immediately_without_cache( filename );
		if(img3){
			ImgImlib1x = img3;
			imlib_context_set_image( img3 );
			Dim.w = Dim1x.w = imlib_image_get_width();
			Dim.h = Dim1x.h = imlib_image_get_height();
			res = 1;
		}
		tm2 = hf_getGlobalTicks();
		printf("\r""%d%% | %.2f""s | %d*%d\n", (res?100:0), (float(tm2-tm3) / 1000.f), Dim.w, Dim.h );
	}
	imlib_context_set_progress_function( params2.second );
	imlib_context_set_progress_granularity( params2.first );
	return res;
}





