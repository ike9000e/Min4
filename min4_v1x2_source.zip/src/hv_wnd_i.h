#ifndef _HV_WND_I_H_
#define _HV_WND_I_H_
#include <stdint.h>
#include "hv_util.h"
#include <X11/Xlib.h>

using HvDpy = size_t;//Display
using HvWid = uint64_t;//Window,HWND
using HvGC = unsigned short*;// GC aka _XGC*, HDC
#if defined(HV_X11)
	//#include <X11/Xlib.h>
	// each function must be instantiated in platform specific cpp file.
	Display* HvToDpy2( HvDpy* inp );
	HvDpy*   HvToDpy3( Display* inp );
	GC       HvToGcx2( HvGC inp );
	HvGC     HvToGcx3( GC inp );
#elif defined(HV_WIN32)
	//#include <windows.h>
	#error "Not implemented."

#else
	#error "Either HV_X11 or HV_WIN32 must be defined prior including this file."
#endif


struct HvIWndUserInput{
	bool bKeyDown = 0, bMouseDown = 0, bMouseUp = 0, bMouseMotion = 0;
	int nMouseButton = 0; // 1=LMB, 2=MMB, 3=RMB, 4=WheelF, 5=WheelB.
	int xyMouse[2] = {0,0,}; // only valid if bMouseDown|bMouseUp|bMouseMotion.
	uint32_t nKeysym = 0;
};
struct HvIWndCreate{
	int x,y,w,h;
	uint32_t clrFrgg, clrBckg;
	std::string title2;
};
struct HvIWndRectRepaint{
	struct {
		int x,y,w,h;
	} ;//rect
};
struct HvIWndNewGeometry{
	int w, h;
};

//using HvDpy2 = size_t; //Display*.HvDpy
//using HvWid2 = uint64_t; //Window,HvWid
//using HvGC2  = unsigned short*; // GC aka _XGC*, HDC,HvGC
/*
/// Window context.
struct HvWC{ //HvIWndId
	HvDpy* ioDpy( HvDpy* inp = 0 );
	HvWid ioWid( bool bSet=0, HvWid inp = 0 );
	HvGC ioGcx( bool bSet=0, HvGC inp = 0 );
private:
	HvDpy* dpy3 = 0;
	HvWid  wid3 = 0;
	HvGC   gcx3 = 0;
};//*/

struct HvIWndId{
	HvDpy*  dpy2; //Display*, HvDpy
	HvWid   wid2; //Window, HWND, int, HvWid
	HvGC    gcx2; //GC, 'struct _XGC', HDC
	HvIWndId() : dpy2(0), wid2(0), gcx2(0) {}
};
struct HvIWnd {
	virtual bool     itwCreateTitleWindow( const HvIWndCreate& inp ) = 0;
	virtual void     itwDestroyTitleWindow() = 0;
	virtual int      itwExec() = 0;
	virtual void     itwQuitNotify() = 0;
	virtual void     itwOnUserInput( const HvIWndUserInput& inp ) = 0;
	virtual void     itwOnRectRepaint( const HvIWndRectRepaint& inp ) = 0;
	virtual void     itwOnNewGeometry( const HvIWndNewGeometry& inp ) = 0;
	virtual void     itwCloseTitleWindow() = 0;
	virtual HvIWndId itwGetTitleWindowInfo() = 0;
	virtual void     itwFlush() = 0; //fe, XFlush()
	virtual void     itwClearArea( int x, int y, int w, int h, int flags_ ) = 0; //fe. XClearArea()
};
struct HvQueryImageMode
{
	virtual bool qimGetAntiAliasForScale( float fScale )const = 0;
};

struct HvImage {
	virtual ~HvImage() {}
	virtual bool          drawImageWithin( HvWid wid, const HfRct& updatearea, HvGC gcx, const HfPt& xy ) = 0;
	virtual bool          reloadPixmap2( HvDpy* dpy, HvWid wid, HvGC gcx ) = 0;
	virtual bool          loadImage2( const char* filename ) = 0;
	virtual void          clearImageIfAny2() = 0;
	virtual const HfDim&  dimWH()const = 0;
	virtual const HfDim&  dimWH1x()const = 0;
	virtual bool          rescaleTo2( HvWid wid, HvGC gcx, const HfRct&, const HfDim& ) = 0;
	virtual bool          rescaleTo3( HvWid wid, HvGC gcx, float fInitialZoom, const HfRct& region2, const HfDim& whRescaleTo, int, uint32_t dfltPixel ) = 0;
	virtual auto          ioQueryImageModeIntrf( bool bSet = 0, HvQueryImageMode* inp = 0 ) -> HvQueryImageMode*;
private:
	HvQueryImageMode* QueryIntrf = 0;
};

#endif //_HV_WND_I_H_
