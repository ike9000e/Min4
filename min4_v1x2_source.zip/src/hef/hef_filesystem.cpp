
#include "hef_filesystem.h"

#ifdef WIN32
#	include <windows.h>
#elif defined(__GNUC__)
#	include <dirent.h>   //opendir()
#endif
#include <stdio.h>
#include <string.h>
#include "hef_assert.h"

namespace hef{

/// Constructor.
/// \param szDir - input directory.
/// \param flags2 - flags, fe. \ref EHFDCF_IncludeDotedOnes.
HfDirContents::HfDirContents( const char* szDir, size_t flags2 )
	: Dir2(szDir), Flags2(flags2), WfdHandle(0), Dh3(0)
{
	Dir2 = hf_rtrim_stdstring( hf_rtrim_stdstring( Dir2.c_str(), "*" ).c_str(), "/\\" );
}
HfDirContents::~HfDirContents()
{
	cleanup();
}
bool HfDirContents::getNextFile( SFile& outp )
{
#	ifdef WIN32
		outp = SFile();
		WIN32_FIND_DATA wf;
		memset( &wf, 0, sizeof(WIN32_FIND_DATA) );
		bool bOk = 0;
		if( !WfdHandle ){
			WfdHandle = FindFirstFile( std::string(Dir2 + "/*").c_str(), &wf );
			if( WfdHandle && WfdHandle != INVALID_HANDLE_VALUE ){
				bOk = 1;
			}else
				WfdHandle = 0;
		}else{
			bOk = !!FindNextFile( WfdHandle, &wf );
		}
		if( bOk ){
			outp.fname  = wf.cFileName;
			outp.bDir   = !!(wf.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY);
			while( bOk && !isFnameAcceptable( outp.fname ) ){
				bOk = getNextFile( outp );
			}
		}
		if( bOk )
			return 1;
		cleanup();
#	elif defined(__GNUC__)
		// ref: https://stackoverflow.com/questions/4204666/how-to-list-files-in-a-directory-in-a-c-program
		struct dirent* dir2;
		DIR* Dh2 = reinterpret_cast<DIR*>( Dh3 );
		if( !Dh2 ){
			Dh2 = opendir( Dir2.c_str() );
			Dh3 = Dh2;
		}
		if( Dh2 ){
			dir2 = readdir( Dh2 );
			if( !(Flags2 & EHFDCF_IncludeDotedOnes) ){
				for(; dir2 && ( !strcmp(dir2->d_name,".") || !strcmp(dir2->d_name,"..") ); )
					dir2 = readdir( Dh2 );
			}
			if( dir2 ){
				outp.fname       = dir2->d_name;
				outp.bDir        = ( dir2->d_type == DT_DIR );
				outp.pUnixDirent = dir2;
			}else{
				closedir(Dh2);
				Dh3 = Dh2 = 0;
				return 0;
			}
		}else{
			return 0;
		}
		return 1;
#	else
		hf_assert(!"Not implemented.");
#	endif //WIN32
	return 0;
}
void HfDirContents::cleanup()
{
#	ifdef WIN32
	if( WfdHandle ){
		FindClose( WfdHandle );
		WfdHandle = 0;
	}
#	elif defined(__GNUC__)
		if(Dh3){
			DIR* Dh2 = reinterpret_cast<DIR*>( Dh3 );
			closedir( Dh2 );
			Dh3 = Dh2 = 0;
		}
#	else
		hf_assert(!"Not implemented.");
#	endif //WIN32
}
bool HfDirContents::isFnameAcceptable( const std::string& fname2 )
{
	if( !(Flags2 & EHFDCF_IncludeDotedOnes) ){
		return fname2 != "." && fname2 != "..";
	}
	return 1;
}

} // end namespace hef
