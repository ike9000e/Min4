#!/bin/bash
#

	szBasedir="$(dirname "$(readlink -f "${BASH_SOURCE:-$0}")")"
	
	exec="$szBasedir/bin/dbg/min4iv"
	##$exec --help
	##exit 255
	
	exec="$szBasedir/bin/release/min4iv"
	$exec --file_in_dir "$szBasedir/testimages/fruit_grn_leaf.jpg" --bDontRotate 1 \
			--initial_metrics center --bg_fs AA8080 \
			--geometry 800x600+C+C
