
#ifndef _HV_ILDR_H_
#define _HV_ILDR_H_
#include <algorithm>


struct HvImageReadInfo{
	size_t uRow;
	size_t nNumRows, nNumCols;
	size_t nBtPerPx;   //num bytes per pixel, 3=3bytes=24bit
	const std::vector<uint32_t>& aLinePxs;
	HvImageReadInfo( const std::vector<uint32_t>& lns_ ) : aLinePxs(lns_) {}
};
void HvJPEGShowVersionInfo();
bool HvJPEGReadFileIntrnl( const char* szFilename,
			std::function<bool(const HvImageReadInfo&)> calbEachScanline );

template<class T> bool
HvJPEGReadFile( const char* szFilename, T calbEachScanline2 )
{
	return HvJPEGReadFileIntrnl( szFilename, calbEachScanline2 );
}

#endif //HV_ILDR_H_
