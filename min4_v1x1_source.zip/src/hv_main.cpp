#include "hv_main.h"
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
#include <algorithm>
//#include <X11/Xutil.h>   //XK_Escape
//#include <X11/Xatom.h>
#include "hef/hef_data.h"
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "hef/hef_filesystem.h"
#include "xehi_linux_helper.h"
//#include "xehi_globhotkey.h"  //xehi_TestKeysDown3()
#include "hv_vpimg_g.h"
//#include "hv_ildr.h"
//#include "hv_ildr_p.h"
//#include "hv_md5.h"
//#include <thread> //-Wl,--no-as-needed//-lpthread//-pthread

// declared as extern in "hv_main.h".
HfTimeoutSrv* TimeoutSrvGlob = 0;


/// Constructor.
HvWnd::HvWnd( int argc, const char*const* argv )
	: Imt4( {0,0,0,0,}, {0,0,0,0,} )
{
	Img = new HvImlibImage;//HvX11Image;
	assert( !TimeoutSrvGlob );
	TimeoutSrvGlob = new HfTimeoutSrv;
	assert(!Opt);
	Opt = new HvOpts;
	Opt->fromArgv( argc-1, &argv[1], 0 );
	if( Opt->bHelp ){
		showHelp();
		Success2.first = 1;
		return;
	}
	if( Opt->bShowActions ){
		printf("-- Actions: --\n%s\n", Opt->getAllActionNames().c_str() );
		Success2.first = 1;
		return;
	}
	if( Opt->bShowBinds ){
		printf("-- Keyboard and Mouse Binds: --\n%s\n", Opt->getAllBinds().c_str() );
	}
	if( Opt->bLDD ){
		std::vector<std::string> lsx;
		HvGetSharedLibraries( lsx );
		for( const auto& a: lsx ){
			printf("so: [%s]\n", a.c_str() );
		}
	}
	DesktopRezFs.second.fromStdPair( xehi_GetWindowWHXY2( getXDisplay(), DefaultRootWindow( getXDisplay() ), "wh" ) );
	ioXUtilFlags( {1, HV_GWUF_MotionNotifyDeClutter|HV_GWUF_MouseWheelDeClutter,} );

	ClrBckg2 = Opt->clrBckg;
	HfRct geo2;
	if( Opt->eMaximize2.first > 0.f && Opt->eMaximize2.first < 0.9f ){
		geo2 = convMaximize2ToValidGeometry( Opt->eMaximize2.first, Opt->eMaximize2.second );
	}else{
		geo2 = convToValidGeometry( Opt->Geometry2.second, Opt->Geometry2.first.c_str() );
	}
	HvIWndCreate iwc;
	iwc = {geo2.x,geo2.y,geo2.w,geo2.h, (uint32_t)Opt->clrFrgg, (uint32_t)Opt->clrBckg, };
	iwc.title2 = "Min4";
	if( !itwCreateTitleWindow(iwc) ) //createMainWindow()
		return;
	assert( !Dpy && !Wid && !Gcx );
	const HvIWndId swi = itwGetTitleWindowInfo();

	if( Opt->bMaximize ){ //--wmax
		Maximize2.first = 1;
		Maximize2.second = iwc.w;
		xehi_SetWindowNetWmStates( HvToDpy2(swi.dpy2), swi.wid2, XEHI_SWS_MaximizeOn );
		//usleep(1000000);
	}
	//Dpy = reinterpret_cast<Display*>(swi.dpy2);
	//Gcx = reinterpret_cast<GC>(swi.gcx2);//struct _XGC
	Dpy = (swi.dpy2);
	Wid = static_cast<Window>(swi.wid2);
	Gcx = swi.gcx2;
	{
		// dont use xehi_GetWindowWHXY2() cause X11 usually does not updates
		// window props fast enough.
		HfDim dim = { iwc.w, iwc.h, };
		//auto wh2 = xehi_GetWindowWHXY2( HvToDpy2(swi.dpy2), swi.wid2, "wh" );
		//HfDim dim = { wh2.first, wh2.second, };
		int siz = ( Opt->bUseDbgFrame ? FrameBorderSize : 0 );
		SubRect = {siz,siz,dim.w-(siz*2),dim.h-(siz*2),};
	}
	if( !Opt->PidFilename.empty() ){ //--pidfile
		hf_PutFileBytes( Opt->PidFilename.c_str(), HfArgs("%1").arg( getpid() ).c_str(), -1, 0 );
	}
	if( !Opt->FilelistFilename.empty() ){ //--filelist
		std::vector<std::string> lsf;
		hf_GetFileDSVContents( Opt->FilelistFilename.c_str(), "\n", lsf, "\r\n" );
		for( const auto& a : lsf ){
			SFile fss( a.c_str(), CurrFileId.second++ );
			Files2.push_back( fss );
		}
	}
	if( !Opt->LooseFiles.empty() ){
		for( const auto& a : Opt->LooseFiles ){
			SFile fss( a.c_str(), CurrFileId.second++ );
			Files2.push_back( fss );
		}
	}
	if( !Opt->FileAndDirItems.empty() ){   //--file_in_dir
		getDirItemsFromInitialFile( Opt->FileAndDirItems.c_str() );
		if( Opt->FileStartAt.empty() )
			Opt->FileStartAt = Opt->FileAndDirItems;
	}
	if( !Opt->FileStartAt.empty() ){
		std::find_if( Files2.begin(), Files2.end(), [&]( const SFile& a )->bool{
				if( a.filename2 == Opt->FileStartAt ){
					CurrFileId.first = a.ident2;
					return 1;
				}
				return 0;
		});
	}
	if( Opt->eSortFilelistMode != HV_ESFM_Unsorted ){ //--sort_mode
		initialFilelistSort();
	}
	if( !CurrFileId.first && !Files2.empty() ){
		CurrFileId.first = Files2[0].ident2;
	}
	if( CurrFileId.first && Opt->bFirstAutoLoad )
		loadNextImage( 0 );
	Success2.first = 1;
}
HvWnd::~HvWnd()
{
	Img->clearImageIfAny2();
	delete Img;
	Img = 0;
	itwDestroyTitleWindow();

	assert(TimeoutSrvGlob);
	delete TimeoutSrvGlob;
	TimeoutSrvGlob = 0;

	if( !Opt->PidFilename.empty() ){ //--pidfile
		hf_Unlink( Opt->PidFilename.c_str() );
	}
	assert(Opt);
	delete Opt;
	Opt = 0;
}
HfRct HvWnd::convToValidGeometry( const HfRct& inp, const char* szFlags2 )
{
	HfRct ouu;  //Opt->Geometry2
	ouu.x = ( inp.x == -5229341 ? 16 : inp.x );
	ouu.y = ( inp.y == -5229341 ? 16 : inp.y );
	ouu.w = ( !inp.w ? 800 : inp.w );
	ouu.h = ( !inp.h ? 600 : inp.h );
	if( strchr( szFlags2, 'c' ) ){
		int w = DesktopRezFs.second.w;
		if( w > 16 ) // sanity check.
			ouu.x = w / 2 - ouu.w / 2;
	}
	if( strchr( szFlags2, 'm' ) ){
		int h = DesktopRezFs.second.h;
		if( h > 16 ) // sanity check.
			ouu.y = h / 2 - ouu.h / 2;
	}
	return ouu;
}
// eMaximize2; --wmax2 FLOAT/E
HfRct HvWnd::convMaximize2ToValidGeometry( float fFrac, int mMaxzMode )
{
	HfRct ouu = {0,0,800,600,};
	HfDim rez2 = DesktopRezFs.second;
	if( rez2.w > 0 && rez2.h > 0 ){
		if( mMaxzMode == HV_EMEN_LeftEdge ){
			ouu.x = int( fFrac * rez2.w );
			ouu.w = rez2.w - ouu.x;
			ouu.h = rez2.h;
		}else if( mMaxzMode == HV_EMEN_RightEdge ){
			ouu.w = rez2.w - int( fFrac * rez2.w );
			ouu.h = rez2.h;
		}else if( mMaxzMode == HV_EMEN_TopEdge ){
			ouu.y = int( fFrac * rez2.h );
			ouu.w = rez2.w;
			ouu.h = rez2.h - ouu.y;
		}else if( mMaxzMode == HV_EMEN_BottomEdge ){
			ouu.w = rez2.w;
			ouu.h = rez2.h - int( fFrac * rez2.h );
		}else{
			assert(0);
		}
	}
	return ouu;
}
// __func__ - function name as c-string.
// __cplusplus - denotes the version of C++ standard that is being used,
//               expands to value 199711L(until C++11), 201103L(C++11),
//               or 201402L(C++14).

int main( int argc, const char*const* argv )
{
	HvWnd hvw( argc, argv );
	if( !hvw.isValid() ){
		printf("ERROR: %s\n", hvw.getMessage() );
		return 1;
	}
	int res = hvw.exec2();
	//printf("exitting %d...\n", res );
	return res;
}
bool HvWnd::isValid( std::string* err )const
{
	if(err)
		*err = Success2.second;
	return Success2.first;
}

void HvWnd::initialFilelistSort()
{
	if( Opt->eSortFilelistMode == HV_ESFM_Alpha ){ //--sort_mode alpha
		//--high_prio --low_prio
		if(Opt->bShowDbg)
			printf("INFO: Sorting alphabetically.\n");
		std::sort( Files2.begin(), Files2.end(), [&]( const SFile& a, const SFile& b )->bool{
				//int res = hf_strcasecmp( a.filename2.c_str(), b.filename2.c_str(), -1 );
				//PrioChars.first
				int res = HvStrCmpWithPrio( a.filename2.c_str(), b.filename2.c_str(),
						Opt->PrioChars.first.c_str(),
						Opt->PrioChars.second.c_str(),
						0 );
				return (res == -1);
		});
	}else if( Opt->eSortFilelistMode == HV_ESFM_NatSort ){ //natsort
		if(Opt->bShowDbg)
			printf("INFO: Sorting using nat-sort.\n");
		for( auto& a : Files2 ){ //creating tokenized strings.
			a.tokenizedNs = HvTokenizeStringToNumericAware( a.filename2.c_str() );
		}
		std::sort( Files2.begin(), Files2.end(), []( const SFile& a, const SFile& b )->bool{
				int res = HvNumericAwareTokensCompare( a.tokenizedNs, b.tokenizedNs );
				return (res == -1);
		});
		for( auto& a : Files2 ){ //clearing tokenized strings.
			a.tokenizedNs.clear();
		}
	}else{
		assert(0);
	}
}
void HvWnd::showHelp()
{
	printf("Showing Help...\n");
	const char* usage2 =
		"\n"
		"--filelist FILE\n"
		"\n"
		"    Text file that contains files to browse, one file per line.\n"
		"    Additionally, one or more of individual files can be specified\n"
		"    at command line.\n"
		"\n"
		"--start_at FILE\n"
		"\n"
		"    File name to start browsing at. For use toogether with the\n"
		"    '--filelist' option. If not used, then by default, first file\n"
		"    in the list is used to start the browsing at.\n"
		"\n"
		"--file_in_dir FILE\n"
		"\n"
		"    File to open at startup, and also, a directory with image\n"
		"    files that will be added to the list automatically.\n"
		"    The other option, '--start_at', should not be used with this one.\n"
		"\n"
		"--help\n"
		"\n"
		"    Show this help and exit.\n"
		"\n"
		"--sort_mode alpha|natsort|none  --  default: alpha\n"
		"\n"
		"    Initial list sorting mode.\n"
		"    All input files will be sorted if method specified is\n"
		"    different than 'none'.\n"
		"    Sorting is done on UTF-8 strings only.\n"
		"    In alphanumerical sorting, 'alpha', comparision is\n"
		"    case-insensitive while case is considered only for english\n"
		"    characters.\n"
		"\n"
		"--initial_metrics fit|center|center2  --  default: fit\n"
		"\n"
		"    How to position newly loaded images.\n"
		"    By default image may be resized to fit inside \n"
		"    the windpw.\n"
		"\n"
		"--zoom_step FLOAT  --  default: 1.17\n"
		"\n"
		"    Floating point value used when zoommin-in or out.\n"
		"    Eg. value 1.2 causes bigger scalling steps than value 1.1.\n"
		"\n"
		"--pidfile FILE\n"
		"\n"
		"    Name of file that is created and contains PID of\n"
		"    the process.\n"
		"\n"
		"--bg COLOR\n"
		"\n"
		"    Background color. 6 hex digit format, only.\n"
		"    Eg. AA8080 or FF00FF.\n"
		"\n"
		"--bg_fs COLOR\n"
		"\n"
		"    Same as '--bg' option but for use only when in full-screen mode,\n"
		"    when there is no title bar or task manager visible.\n"
		"    Eg. on many X-Desktop window managers, window can be switched into\n"
		"    full-screen using the F11 key.\n"
		"\n"
		"--wmax\n"
		"\n"
		"    Maximize on startup.\n"
		"\n"
		"--wmax2 FLOAT/EDGE\n"
		"\n"
		"    Pseudo maximize on startup.\n"
		"    Float value is the amout of how much to make the window smaller.\n"
		"    Value marked as EDGE tells form which window side to subtract\n"
		"    the size from. EDGE must be set to 'L', 'R', 'T' or 'B'.\n"
		"    While window can be maximized with the '--wmax' switch instead, this one\n"
		"    is provided as an alternative, potentially smoother way.\n"
		"    Eg. '--wmax2 0.1/B' makes window 'maximized' but with the height set to \n"
		"    90 percent instead, leaving some space below the window not covered.\n"
		"\n"
		"--bShowDbg\n"
		"\n"
		"    Print more info to stdout.\n"
		"\n"
		"--bDontRotate 0|1   --   default: 0\n"
		"\n"
		"    Do not go to the first image file on the list end.\n"
		"\n"
		"--geometry WxH[+X+Y]\n"
		"--g WxH[+X+Y]\n"
		"\n"
		"    Window Geometry on startup.\n"
		"    X and Y can be both set to 'C', special value,\n"
		"    to cause centering on the screen.\n"
		"\n"
		"--high_prio CHARACTERS\n"
		"\n"
		"    For use when sorting in alpha-numerical mode, ie. when '--sort_mode' is\n"
		"    set to 'alpha'.\n"
		"    ASCII Characters that are considered the highest priority.\n"
		"    Eg. including character tilde ('~' (0x7E)) in this list, will sort\n"
		"    this character with highest priority, before letters,\n"
		"    numbers, and even before 0x01.\n"
		"    Characters in the list, priority between themself, is determined\n"
		"    by their order.\n"
		"\n"
		"--low_prio CHARACTERS\n"
		"\n"
		"    Same as '--high_prio' option, but this is to cause placement\n"
		"    at the end of the list, after any other character.\n"
		"    Characters can be specified percent-encoded, under condition\n"
		"    that the last character is itself percent-encoded.\n"
		"    Eg. set the last character to '%00' to have it itself ignored,\n"
		"    but actually, percent-decode the other characters.\n"
		"\n"
		"--bShowActions\n"
		"\n"
		"    Shows action names and exits.\n"
		"    These are names that can be used when binding action to keys\n"
		"    or buttons.\n"
		"\n"
		"--bind_k KEY=ACTION\n"
		"\n"
		"    Binds key or button to an action.\n"
		"    Eg. to make the delete key quit the program use 'Delete=Quit'\n"
		"    KEY can also be specified as HEX value with 0x prefix,\n"
		"    eg. '0xffbe' (F1 in this case) (This is an Xlib feature).\n"
		"\n"
		"--bNoDefaultBinds 0|1   --   default: 0\n"
		"\n"
		"    Do not assign any default binds.\n"
		"    This switch must appear before any actual user bind made via\n"
		"    the '--bind_k' switch.\n"
		"\n"
		"--bShowBinds 0|1   --   default: 1\n"
		"\n"
		"    Shows all key binds in the program on startup. Includes\n"
		"    any default binds.\n"
		"\n"
		"--nMoveByKeyAmount NUMBER    --    default: 16\n"
		"\n"
		"    How much to move when using keyboard, in sigle button press.\n"
		"\n"
		"--config_file FILE\n"
		"\n"
		"    Configuration file that contains command line options.\n"
		"    Each line should contain option name followed by value. Simple parsing.\n"
		"    Example file contents:\n"
		"        --bg_fs FF88FF\n"
		"        --bind_k Delete=Quit\n"
		"        --bind_k c=Quit\n"
		"    Each line must begin with correct option name, that starts with\n"
		"    double dash, followed by space character. Only after that space\n"
		"    character the string can be quoted.\n"
		"    If file names are to be specified, that potentially contain space\n"
		"    characters, the line must start with a double dash ('--'), followed \n"
		"    by space, then followed by quoted file name.\n"
		"\n"
		"\n"
		"Notes About Binding Actions\n"
		"---------------------------\n"
		"    The action 'MousePanButton' can only be bound to a mouse button,\n"
		"    M1, M2, M3, and so forth. Eg. 'M1=MousePanButton'\n"
		"\n"
		"\n";
		//"--bLDD 0|1 --  Show loaded modules.\n"
	printf("%s", usage2 );
}
/// Fits picture in frame.
/// \param flags3 - flags. eg. \ref EIFMF_ClearWindowArea.
void HvWnd::level2FitInFrame( int flags3 )
{
	auto ffm = Imt4.getFrameFitMetrics();
	Scale2 = ffm.first;
	HvBoxDirtyOut bso3 = Imt4.resetScale( ffm.first );
	bso3.appendFromOther( Imt4.resetRectPosition( { ffm.second.x, ffm.second.y, } ) );
	if( !(flags3 & EIFMF_ClearWindowArea) ){
		for( const auto& r : bso3.dirty3 )
			itwClearArea( r.x, r.y, r.w, r.h, 0 );
	}
	innerImageRectChange( EUZM_Passthru,
			(flags3 & EIFMF_ClearWindowArea ? EUZCF_SkipDirtyArClear : 0 ) );
	if( flags3 & EIFMF_ClearWindowArea )
		repaintEntireWindow();
}
void HvWnd::level2CenterInFrame( int flags3 )
{
	Scale2 = 1.0;
	HvBoxDirtyOut bso2 = Imt4.resetScale( 1.0 );
	bso2.appendFromOther( Imt4.centerInFrame2() );
	if( !(flags3 & EIFMF_ClearWindowArea) ){
		for( const auto& r : bso2.dirty3 )
			itwClearArea( r.x, r.y, r.w, r.h, 0 );
	}
	innerImageRectChange( EUZM_Passthru,
			(flags3 & EIFMF_ClearWindowArea ? EUZCF_SkipDirtyArClear : 0 ) );
	if( flags3 & EIFMF_ClearWindowArea )
		repaintEntireWindow();
}
void HvWnd::repaintEntireWindow()
{
	HfRct rc = { 0,0,0,0, };
	xehi_GetWindowWHXY( HvToDpy2(Dpy), Wid, &rc.w, &rc.h );
	repaintWindowAt( rc );
}
void HvWnd::level2CenterOrFitInFrame( int flags3 )
{
	auto ffm = Imt4.getFrameFitMetrics();
	if( ffm.first >= 1.0 ){
		level2CenterInFrame( flags3 );
	}else{
		level2FitInFrame( flags3 );
	}
}

void HvWnd::repaintWindowAt( const HfRct& r )
{
	itwClearArea( r.x, r.y, r.w, r.h, 0 );
//	HvBoxCurrentOut bco = Imt3.getCurrentBox();
	//
	const HvBoxCurrentOut bco = Imt4.getCurrentComposition();
	if(Opt->bShowDbg)
		printf("b: im-crp: [%s] dp-dim: [%s] composedOrigin: [%s]\n",
				bco.imageCropRect.toStr().c_str(),
				bco.displayDim.toStr().c_str(),
				bco.composedOrigin.toStr().c_str() );
	Img->drawImageWithin( Wid, SubRect, Gcx, bco.composedOrigin );
	itwFlush();
}
/// Inner image rectangle changes, Zoom-in, zoom-out, cropping, reset to 100%, etc.
/// \param flags2 - flags, fe. \ref EUZCF_SkipImageScaling.
void HvWnd::innerImageRectChange( int mode2, int flags2 )
{
	//static float scale2 = 1.0f;
	HvBoxDirtyOut bso2;
	clearDtRedrawTimeoutIfAny();
	if( mode2 == EUZM_ZoomReset ){
		Scale2 = 1.0f;
		bso2 = Imt4.resetScale( 1.0 );
	}else if( mode2 == EUZM_ZoomInStep ){
		Scale2 *= Opt->ZoomStep;   //--zoom_step 1.1
		bso2 = Imt4.resetScale( Scale2 );
	}else if( mode2 == EUZM_ZoomOutStep ){
		Scale2 /= Opt->ZoomStep;
		bso2 = Imt4.resetScale( Scale2 );
	}else if( mode2 == EUZM_Passthru ){
	}
	uint32_t uDn = 0;//xehi_TestKeysDown3( HvToDpy2(Dpy), {XK_Control_L,XK_Shift_L,}, 0, 0 );
	if( !uDn ){
		bool bSkpSc = (flags2 & EUZCF_SkipImageScaling);
		const HvBoxCurrentOut bco = Imt4.getCurrentComposition();
		//Opt->bShowDbg
		//printf("a: crop:[%s] dim:[%s] origin:[%s], SkpSc:%d\n",
		//		bco.imageCropRect.toStr().c_str(),
		//		bco.displayDim.toStr().c_str(),
		//		bco.composedOrigin.toStr().c_str(), bSkpSc );//*/
		if( !bSkpSc ){
			Img->rescaleTo2( Wid, Gcx, bco.imageCropRect, bco.displayDim );
			//Img_->rescaleTo3( Wid, Gcx, 1.0f, bco.imageCropRect, bco.displayDim, 0, 0x00 );
		}
		Img->drawImageWithin( Wid, SubRect, Gcx, bco.composedOrigin );

		if( !(flags2 & EUZCF_SkipDirtyArClear) ){
			//printf("bso2.dirty3 size: %ld\n", bso2.dirty3.size() );
			for( const auto& r : bso2.dirty3 ){
				//printf("[%s]\n", r.toStr().c_str() );
				itwClearArea( r.x, r.y, r.w, r.h, 0 );
			}
			itwFlush();
		}
	}else{
		repaintEntireWindow();
	}
}
std::pair<bool,bool> HvWnd::isCurrentFirstLast()const
{
	std::vector<SFile>::const_iterator a, lastt;
	a = std::find_if( Files2.begin(), Files2.end(), [&]( const SFile& a )->bool{
		return ( a.ident2 == CurrFileId.first );
	});
	lastt = Files2.end();
	--lastt;
	return { a == Files2.begin(), a == lastt, };
}
void HvWnd::itwOnRectRepaint( const HvIWndRectRepaint& inp )
{
	HfRct rcx = { inp.x, inp.y, inp.w, inp.h, };
	//printf("rc:%d,%d,%d,%d, %d\n",
	//	rcx.x,rcx.y,rcx.w,rcx.h, static_cast<uint16_t>(hf_getTimeTicksMs()) );
	repaintWindowAt( rcx );
}
int HvWnd::exec2()
{
	if( Opt->bHelp || Opt->bShowActions )
		return 0;
	itwExec();
	return 0;
}
/*void HvWnd::
clearAreasGivenMouseDelta( const HfRct& rct, const HfPt& mouseDelta )
{
	const HfPt& mdt = mouseDelta;
	HfRct wo = { 0, 0, 0, 0, };
	xehi_GetWindowWHXY( HvToDpy2(Dpy), Wid, &wo.w, &wo.h );
	HfRct io = rct;
	HfRct in2 = {0,0,0,0,}; // new area #1 resulting from mouse delta.
	HfRct in3 = {0,0,0,0,}; // new area #2 resulting from mouse delta.
	if( mdt.x > 0 )
		in2 = { io.x, io.y, mdt.x, rct.h, };
	else if( mdt.x < 0 )
		in2 = { ((io.x + io.w) + mdt.x), io.y, (-mdt.x), rct.h, };
	if( mdt.y > 0 )
		in3 = { io.x, io.y, rct.w, mdt.y, };
	else if( mdt.y < 0 )
		in3 = { io.x, ((io.y + io.h) + mdt.y), rct.w, -mdt.y, };
	in2.clipAgainst( wo ).constrainTo( wo );
	in3.clipAgainst( wo ).constrainTo( wo );
	//printf("dt-rep, i-rc-in2: %s\n", in2.toStr().c_str() );
	if( !in2.isEmpty2() )
		itwClearArea( in2.x, in2.y, in2.w, in2.h, 0 );
	if( !in3.isEmpty2() )
		itwClearArea( in3.x, in3.y, in3.w, in3.h, 0 );
}//*/
void HvWnd::clearDtRedrawTimeoutIfAny()
{
	if( RedrawTmoId ){
		assert(TimeoutSrvGlob);
		TimeoutSrvGlob->clearTimeout( RedrawTmoId );
		RedrawTmoId = 0;
	}
}
/*void HvWnd::soDtRedrawTmo( HfTimeoutSrv::STimeout inp )
{
	//static int xxx = 1;
	//printf("auto-redraw-2. %d\n", xxx++ );
	assert( inp.idTimeout == RedrawTmoId );
	RedrawTmoId = 0;
	innerImageRectChange( EUZM_Passthru, 0 );
}//*/
int HvWnd::computeFileIndex( int ident3 )const
{
	std::vector<SFile>::const_iterator a;
	int i = 0;
	for( a = Files2.begin(); a != Files2.end(); ++a, i++ ){
		if( a->ident2 == ident3 )
			break;
	}
	return ( i < static_cast<int>(Files2.size()) ? i : -1 );
}
void HvWnd::loadNextImage( int direction2 )
{
	assert( direction2 >= -2 && direction2 <= 2 );
	if( CurrFileId.first && !Files2.empty() ){
		std::vector<SFile>::iterator a,b;
		a = std::find_if( Files2.begin(), Files2.end(), [&]( const SFile& a )->bool{
				return ( a.ident2 == CurrFileId.first );
		});
		assert( a != Files2.end() );
		if( direction2 == 1 || direction2 == -1 ){
			b = a;
			if( direction2 == 1 ){
				b = ( ++b == Files2.end() ? Files2.begin() : b );
			}else if( direction2 == -1 ){
				if( b == Files2.begin() )
					b = Files2.end();
				--b;
			}else{
				assert(0);
			}
			if( CurrFileId.first == b->ident2 ){
				assert( Files2.size() == 1 );
				printf("WARN: Couldn't go to next|prev image. One image in the list.\n");
				return;
			}
			CurrFileId.first = b->ident2; // assigns next image to load.
		}else if( direction2 == -2 || direction2 == 2 ){
			if( direction2 == -2 ){   // eg. on home-button
				b = Files2.begin();
			}else{   // direction2 == 2   // eg. on end-button
				b = Files2.begin() + (Files2.size() - 1);
			}
			CurrFileId.first = b->ident2; // assigns next image to load.
		}
	}else if( !Files2.empty() ){
		CurrFileId.first = Files2[0].ident2; // assigns next image to load.
	}
	if( !CurrFileId.first ){
		printf("WARN: Couldn't find next image to load. (%s(%d))\n", hf_basename(__FILE__), __LINE__ );
		return;
	}
	//
	// got the 'next' iamge, load it now.
	//
	SFile imFile("",-1);
	{
		std::vector<SFile>::iterator a;
		a = std::find_if( Files2.begin(), Files2.end(), [&]( const SFile& a )->bool{
				return ( a.ident2 == CurrFileId.first );
		});
		assert( a != Files2.end() );
		imFile = *a;
	}
	int nIndex = computeFileIndex( imFile.ident2 );
	std::string strImf = imFile.filename2.c_str();

	std::string strTitle = HfArgs("%1/%2 _Loading_\\x20[%3] - Min4")
				.arg( nIndex + 1 ).arg( static_cast<int>( Files2.size() ) )
				.arg( hf_basename2( strImf.c_str() ).c_str() )
				.c_str();
	//
	printf("Loading image [%s] ...\n", hf_basename(strImf.c_str()) );
	xehi_SetWindowName( getXDisplay(), Wid, strTitle.c_str() );

	Img->ioBackgroundColor( 1, (ClrBckg2 | 0xFF000000) );
	if( !Img->loadImage2( strImf.c_str() ) ){
		printf("Image load failed.\n");
		strTitle = HvStrReplace( strTitle, "_Loading_\\x20", "ERROR " );
		xehi_SetWindowName( getXDisplay(), Wid, strTitle.c_str() );
		repaintEntireWindow();
	}else{
		printf("Image loaded. WxH: %d*%d\n", Img->dimWH().w, Img->dimWH().h );
		Img->reloadPixmap2( Dpy, Wid, Gcx );
		//
		Scale2 = 1.0f;
		Imt4 = HvComposedBox3( SubRect, { 0, 0, Img->dimWH1x().w, Img->dimWH1x().h, } );
		level3UpdateMetricsInFrame( EIFMF_ClearWindowArea );
		strTitle = HvStrReplace( strTitle, "_Loading_\\x20", "" );
		xehi_SetWindowName( getXDisplay(), Wid, strTitle.c_str() );
	}
}
void HvWnd::level3UpdateMetricsInFrame( int flags3 )
{
	if( Opt->eMetricsOnLoad == HV_EMOIL_FitCentered ){
		level2FitInFrame( EIFMF_ClearWindowArea );
	}else if( Opt->eMetricsOnLoad == HV_EMOIL_CenteredOrFit ){
		level2CenterOrFitInFrame( EIFMF_ClearWindowArea );
	}else if( Opt->eMetricsOnLoad == HV_EMOIL_CenteredUnsc ){
		level2CenterInFrame( EIFMF_ClearWindowArea );
	}else if( Opt->eMetricsOnLoad == HV_EMOIL_UpperLeft ){
		assert(0);
	}else{
		assert(0);
	}
}
//case ConfigureNotify: // notify: resize, pos, etc., StructureNotifyMask
void HvWnd::itwOnNewGeometry( const HvIWndNewGeometry& inp )
{
	//uint32_t tm2 = hf_getGlobalTicks();
	//printf("itwOnNewGeometry(), t:%u, wh:%d,%d \n", tm2, inp.w, inp.h );
	int siz = ( Opt->bUseDbgFrame ? FrameBorderSize : 0 );
	SubRect = { siz, siz, inp.w-siz*2, inp.h-siz*2, };
	Imt4.setFrame2( SubRect );
	bool bRepaintImg = 0;
	// Check if going full screen (eg. F11 key) and do dispatch if needed.
	if( DesktopRezFs.second == HfDim( inp.w, inp.h ) ){
		if( !DesktopRezFs.first ){
			// if going full-screen.
			DesktopRezFs.first = 1;
			if(Opt->bShowDbg)
				printf("Going Fullscreen\n");
			if( Opt->clrBckgFs >> 24 ){  //Opt->clrBckg
				const HvIWndId swi = itwGetTitleWindowInfo();
				XSetWindowBackground( HvToDpy2(swi.dpy2), swi.wid2, Opt->clrBckgFs );
				ClrBckg2 = Opt->clrBckgFs;
				Img->ioBackgroundColor( 1, Opt->clrBckgFs | 0xFF000000 );
				bRepaintImg = 1;
			}
		}
	}else{
		if( DesktopRezFs.first ){
			// if going windowed, full-screen off.
			if(Opt->bShowDbg)
				printf("Going Windowed\n");
			DesktopRezFs.first = 0;
			if( Opt->clrBckgFs >> 24 ){
				const HvIWndId swi = itwGetTitleWindowInfo();
				XSetWindowBackground( HvToDpy2(swi.dpy2), swi.wid2, Opt->clrBckg );
				ClrBckg2 = Opt->clrBckg;
				Img->ioBackgroundColor( 1, Opt->clrBckg | 0xFF000000 );
				bRepaintImg = 1;
			}
		}
	}
	// Check if maximizing via desktop manager (eg. '--wmax'). Doings are
	// required here since there are lazy responses from the desktop manager.
	if( Maximize2.first == 1 && Maximize2.second < inp.w ){
		Maximize2.first = 0;
		bRepaintImg = 1;
	}
	if( bRepaintImg ){
		level3UpdateMetricsInFrame( 0 );
	}else{
		HfRct rcx = { 0, 0, inp.w, inp.h, };
		repaintWindowAt( rcx );
	}
}
void HvWnd::postEventPerform()
{
	assert( TimeoutSrvGlob );
	TimeoutSrvGlob->performTm();
}
int HvWnd::getTimeoutMsForSelect()
{
	assert( TimeoutSrvGlob );
	int msNrst = TimeoutSrvGlob->getNearestTimeout();
	//printf("msNrst: %d\n", msNrst );
	if( msNrst != -1 )
		return msNrst;
	return -1;
}
void HvWnd::getDirItemsFromInitialFile( const char* szFilename )   //--file_in_dir
{
	std::string dn2 = hf_dirname( szFilename );
	std::string ext2 = hf_basename3( szFilename, HF_EBN3F_ExtAnyChars ).second;
	ext2 = hf_toLowerAsAscii( ext2.c_str() );
	static const std::vector<std::string> commonExts = {
			"png","jpg","jpeg","jpe","gif","tiff", "tif","tga","pcx","ico","bmp",};
	HfDirContents::SFile dcf;
	HfDirContents dcs( dn2.c_str(), 0 );
	for( ; dcs.getNextFile( dcf ); ){
		if( !dcf.bDir ){
			std::string ext3 = hf_basename3( dcf.fname.c_str(), HF_EBN3F_ExtAnyChars ).second;
			ext3 = hf_toLowerAsAscii( ext3.c_str() );
			bool bOk = 0;
			std::find_if( commonExts.begin(), commonExts.end(), [&]( const std::string& a )->bool{
				return (bOk = (a == ext3));
			});
			if( bOk || ext2 == ext3 ){
				std::string fn2 = dn2 + "/" + dcf.fname;
				HvWnd::SFile fss( fn2.c_str(), CurrFileId.second++ );
				//printf("[%s]\n", fn2.c_str() );
				Files2.push_back( fss );
			}
		}
	}
}

void HvWnd::itwOnUserInput( const HvIWndUserInput& inp )
{
	if( inp.bKeyDown ){
		int ksm = inp.nKeysym;
		if(0){
		}else if( Opt->testKey( HV_ACTT_Quit, ksm ) ){
			itwCloseTitleWindow();
		//}else if( strchr("m", ksm ) ){
		//	Opt->bAutoPosChgRedraw = !Opt->bAutoPosChgRedraw;
		//	printf("bAutoPosChgRedraw: %d\n", (int)Opt->bAutoPosChgRedraw );
		}else if( Opt->testKey( HV_ACTT_LoadNext, ksm ) ){
			if( !(Opt->bDontRotate && isCurrentFirstLast().second) )
				loadNextImage( 1 );
		}else if( Opt->testKey( HV_ACTT_LoadPrev, ksm ) ){
			if( !(Opt->bDontRotate && isCurrentFirstLast().first) )
				loadNextImage( -1 );
		}else if( Opt->testKey( HV_ACTT_LoadNextR, ksm ) ){
			loadNextImage( 1 );
		}else if( Opt->testKey( HV_ACTT_LoadPrevR, ksm ) ){
			loadNextImage( -1 );
		}else if( Opt->testKey( HV_ACTT_LoadFirst, ksm ) ){
			loadNextImage(-2);
		}else if( Opt->testKey( HV_ACTT_LoadLast, ksm ) ){
			loadNextImage(2);
		}else if( Opt->testKey( HV_ACTT_CenterInFrame, ksm ) ){
			level2CenterInFrame( 0 );
		}else if( Opt->testKey( HV_ACTT_FitInFrame, ksm ) ){
			level2FitInFrame( 0 );
		}else if( Opt->testKey( HV_ACTT_CenterOrFitInFrame, ksm ) ){
			level2CenterOrFitInFrame( 0 );
		}else if( Opt->testKey( HV_ACTT_ZoomInStep, ksm ) ){
			HfPt xym = HfPt().set( xehi_GetMouseCoordsRelative2(HvToDpy2(Dpy),Wid) );
			Imt4.setScaleOrigin3( xym );
			innerImageRectChange( EUZM_ZoomInStep , 0 );
		}else if( Opt->testKey( HV_ACTT_ZoomOutStep, ksm ) ){
			HfPt xym = HfPt().set( xehi_GetMouseCoordsRelative2(HvToDpy2(Dpy),Wid) );
			Imt4.setScaleOrigin3( xym );
			innerImageRectChange( EUZM_ZoomOutStep, 0 );
		}else if( Opt->testKey( HV_ACTT_Repaint, ksm ) ){
			repaintEntireWindow();
		}else if( Opt->testKey( HV_ACTT_ZoomReset, ksm ) ){
			innerImageRectChange( EUZM_ZoomReset, 0 );
		//}else if( strchr("y", ksm ) ){
		//	Img->rescaleTo3( Wid, Gcx, 1.0f, {-10,-5,64,64,}, {64,64,}, 0, 0xFF0000 );
		//	repaintEntireWindow();

		}else if( Opt->testKey( HV_ACTT_MoveLeft, ksm ) ){
			HfPt mousedt2 = { -Opt->nMoveByKeyAmount, 0, };
			level2PanOrMoveImage( mousedt2 );
		}else if( Opt->testKey( HV_ACTT_MoveRight, ksm ) ){
			HfPt mousedt2 = { Opt->nMoveByKeyAmount, 0, };
			level2PanOrMoveImage( mousedt2 );
		}else if( Opt->testKey( HV_ACTT_MoveDown, ksm ) ){
			HfPt mousedt2 = { 0, Opt->nMoveByKeyAmount, };
			level2PanOrMoveImage( mousedt2 );
		}else if( Opt->testKey( HV_ACTT_MoveUp, ksm ) ){
			HfPt mousedt2 = { 0, -Opt->nMoveByKeyAmount, };
			level2PanOrMoveImage( mousedt2 );
		}
	}else if( inp.bMouseDown || inp.bMouseUp ){
		//printf("%d.\n", inp.nMouseButton );
		HfPt xym = HfPt().set( xehi_GetMouseCoordsRelative2(HvToDpy2(Dpy),Wid) );
		//HV_ACTT_MousePanButton
		//if( inp.nMouseButton == 1 )  //"\1\2"
		if( Opt->testMouseButton( HV_ACTT_MousePanButton, inp.nMouseButton ) ){
			//printf("button: %d, down:%d\n", xb.button, bPress );
			MouseDrag.iButton = inp.nMouseButton;
			if( inp.bMouseDown ){
				MouseDrag.first = 1;
				MouseDrag.second = { xym.x, xym.y, };
			}else{
				MouseDrag.first = 0;
				MouseDrag.second = { 0, 0, };
			}
		}
		if( inp.bMouseDown ){
			if( Opt->testMouseButton( HV_ACTT_ZoomInStep, inp.nMouseButton ) ){
				Imt4.setScaleOrigin3( xym );
				innerImageRectChange( EUZM_ZoomInStep, 0 );
			}else if( Opt->testMouseButton( HV_ACTT_ZoomOutStep, inp.nMouseButton ) ){
				Imt4.setScaleOrigin3( xym );
				innerImageRectChange( EUZM_ZoomOutStep, 0 );
			}
		}
	}else if( inp.bMouseMotion ){ //case MotionNotify
		//if( MouseDrag.first && MouseDrag.iButton == 1 )
		if( MouseDrag.first && Opt->testMouseButton( HV_ACTT_MousePanButton, MouseDrag.iButton ) ){
			HfPt xym = HfPt().set( xehi_GetMouseCoordsRelative2(HvToDpy2(Dpy),Wid) );
			HfPt mousedt = xym.subConst( MouseDrag.second );
			level2PanOrMoveImage( mousedt );
			MouseDrag.second = xym;
		}
	}
}
void HvWnd::level2PanOrMoveImage( const HfPt& mousedelta )
{
	bool bWasInside = Imt4.isRectCompletelyInside();
	HvBoxDirtyOut bdo = Imt4.addPositionDelta2( mousedelta );
	for( const auto& r : bdo.dirty3 ){
		itwClearArea( r.x, r.y, r.w, r.h, 0 );
	}
	//HV_ACTT_MoveLeft
	bool bIsInside = Imt4.isRectCompletelyInside();
	innerImageRectChange( EUZM_Passthru, ( ( bWasInside && bIsInside ) ?
					EUZCF_SkipImageScaling : 0 ) );
//	if( Opt->bAutoPosChgRedraw /*&& !Imt3.isBoxCompletelyInside()*/ ){
//		if( !RedrawTmoId ){
//			assert( TimeoutSrvGlob );
//			//RedrawTmoId = TimeoutSrvGlob->setTimeout( Opt->msDtRedrawTimeout, this, &HvWnd::soDtRedrawTmo, 0 );
//		}
//	}
}





