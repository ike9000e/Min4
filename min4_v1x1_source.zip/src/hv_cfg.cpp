#include "hv_cfg.h"
#include <string.h>
#include <assert.h>
#include "hef/hef_data.h"
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "hef/hef_filesystem.h"
#include <X11/Xlib.h>

const std::pair<int,const char*> HvOpts::ActionNamesApp[] = {
	{ HV_ACTT_Quit, "HV_ACTT_Quit", },
	{ HV_ACTT_LoadNext, "HV_ACTT_LoadNext", },
	{ HV_ACTT_LoadPrev, "HV_ACTT_LoadPrev", },
	{ HV_ACTT_LoadNextR, "HV_ACTT_LoadNextR", },
	{ HV_ACTT_LoadPrevR, "HV_ACTT_LoadPrevR", },
	{ HV_ACTT_LoadFirst, "HV_ACTT_LoadFirst", },
	{ HV_ACTT_LoadLast, "HV_ACTT_LoadLast", },
	{ HV_ACTT_CenterInFrame, "HV_ACTT_CenterInFrame", },
	{ HV_ACTT_FitInFrame, "HV_ACTT_FitInFrame", },
	{ HV_ACTT_CenterOrFitInFrame, "HV_ACTT_CenterOrFitInFrame", },
	{ HV_ACTT_ZoomInStep, "HV_ACTT_ZoomInStep", },
	{ HV_ACTT_ZoomOutStep, "HV_ACTT_ZoomOutStep", },
	{ HV_ACTT_Repaint, "HV_ACTT_Repaint", },
	{ HV_ACTT_ZoomReset, "HV_ACTT_ZoomReset", },
	{ HV_ACTT_MousePanButton, "HV_ACTT_MousePanButton", },
	{ HV_ACTT_MoveLeft, "HV_ACTT_MoveLeft", },
	{ HV_ACTT_MoveRight, "HV_ACTT_MoveRight", },
	{ HV_ACTT_MoveDown, "HV_ACTT_MoveDown", },
	{ HV_ACTT_MoveUp, "HV_ACTT_MoveUp", },

	{ 0, 0, },
};
/// Returns action type or zero on error.
int HvOpts::lookupActionTypeByName( const std::string ssActName )
{
	// "HV_ACTT_Quit" - "HV_ACTT_" --> "Quit"
	const std::string strPrfx("HV_ACTT_");
	for( int i=0; ActionNamesApp[i].second; i++ ){
		auto aKvName = ActionNamesApp[i];
		assert( aKvName.first > 0 );
		assert( strlen(aKvName.second) > strPrfx.size() );
		if( ssActName == aKvName.second ){
			return aKvName.first;
		}
		std::string strKvName2( aKvName.second + strPrfx.size() );
		if( ssActName == strKvName2 ){
			return aKvName.first;
		}
	}
	return 0;
}
std::string HvOpts::lookupActionNameByType( int nActType3 )
{
	std::string outp;
	const std::string strPrfx("HV_ACTT_");
	for( int i=0; ActionNamesApp[i].second; i++ ){
		auto aaa = ActionNamesApp[i];
		if( aaa.first == nActType3 ){
			std::string str( aaa.second + strPrfx.size() );
			assert( !str.empty() );
			return str;
		}
	}
	return "";
}
/// Returns all action names in the program as lines of text.
std::string HvOpts::getAllActionNames()
{
	std::string outp;
	const std::string strPrfx("HV_ACTT_");
	for( int i=0; ActionNamesApp[i].second; i++ ){
		auto aKvName = ActionNamesApp[i];
		assert( aKvName.first > 0 );
		assert( strlen(aKvName.second) > strPrfx.size() );
		std::string strKvName2( aKvName.second + strPrfx.size() );
		outp += strKvName2 + "\n";
	}
	return outp;
}
void HvOpts::fromArgv( int argc, const char*const* argv, Display* dpy )
{
	std::vector<std::string> argv2;
	for( int i=0; i<argc; i++ ){
		argv2.push_back( argv[i] );
	}
	dpy = ( dpy ? dpy : XOpenDisplay(0) );
	bool bLMadeSomeBinds = 0, bLAddedDefaultBinds = 0;
	std::vector<std::pair<const char*,bool*> >::const_iterator b;
	std::vector<std::pair<const char*,bool*> > params2 = {
		{"--bLDD", &bLDD, },
		{"--bFirstAutoLoad", &bFirstAutoLoad, },
		{"--wmax", &bMaximize, },
		{"--bDontRotate", &bDontRotate, },
		{"--bAutoPosChgRedraw", &bAutoPosChgRedraw, },
		{"--bShowDbg", &bShowDbg, },
		{"--bUseDbgFrame", &bUseDbgFrame, },
		{"--bShowActions", &bShowActions, },
		{"--bShowBinds", &bShowBinds, },
	};
	// iterate over dynamic array of arguments.
	// keep checking size every time since new arguments can be added from
	// input config file with '--config_file'.
	for( size_t i=0; i < argv2.size(); i++ ){
		const char* sz2 = argv2[i].c_str();
		const char* sz3 = ( i+1 < argv2.size() ? argv2[i+1].c_str() : "" );
		const char* szB = ( (*sz3 && strchr("01",*sz3)) ? sz3 : "1");
		b = std::find_if( params2.begin(), params2.end(), [&]( const std::pair<const char*,bool*>& a )->bool{
				return !strcmp( a.first, sz2 );
		});
		if( b != params2.end() ){
			*b->second = !!atoi( szB );
			i += ( szB == sz3 ? 1 : 0 );
		}else if( !strcmp("--bHelp",sz2) || !strcmp("--help",sz2) || !strcmp("-help",sz2) || !strcmp("-h",sz2) ){
			bHelp = atoi( szB );
			i += ( szB == sz3 ? 1 : 0 );
		}else if( !strcmp("--bg",sz2) && *sz3 ){ //fe. "F88888" or "#F88888".
			clrBckg = strtoul( (*sz3 == '#'? sz3+1 : sz3),0,16);
			i++;
		}else if( !strcmp("--bg_fs",sz2) && *sz3 ){ //fe. "F88888" or "#F88888".
			clrBckgFs = ( strcmp( sz3, "none" ) ? (strtoul( (*sz3 == '#'? sz3+1 : sz3),0,16) | 0xFF000000) : 0 );
			i++;
		}else if( !strcmp("--fg",sz2) && *sz3 ){ //fe. "F88888" or "#F88888".
			clrFrgg = strtoul( (*sz3 == '#'? sz3+1 : sz3),0,16);
			i++;
		}else if( !strcmp("--msDtRedrawTimeout",sz2) ){
			int arg2;
			if( (arg2 = atoi( sz3 )) > 0 ){
				msDtRedrawTimeout = arg2;
				i++;
			}
		}else if( !strcmp("--filelist",sz2) ){
			FilelistFilename = sz3;
			i++;
		}else if( !strcmp("--pidfile",sz2) ){
			PidFilename = sz3;
			i++;
		}else if( !strcmp("--start_at",sz2) ){
			FileStartAt = sz3;
			i++;
		}else if( !strcmp("--file_in_dir",sz2) ){
			FileAndDirItems = sz3;
			i++;
		}else if( !strcmp("--zoom_step",sz2) ){
			ZoomStep = strtod( sz3, 0 );
			i++;
		}else if( !strcmp("--initial_metrics",sz2) ){
			std::string s = sz3;
			if( s == "fit" ){
				eMetricsOnLoad = HV_EMOIL_FitCentered;
			}else if( s == "center" ){  // center or fit
				eMetricsOnLoad = HV_EMOIL_CenteredOrFit;
			}else if( s == "center2" ){
				eMetricsOnLoad = HV_EMOIL_CenteredUnsc;
			}else{
				assert( eMetricsOnLoad == HV_EMOIL_CenteredOrFit );
			}
			i++;
		}else if( !strcmp("--sort_mode",sz2) ){
			std::string s = sz3;
			eSortFilelistMode = ( s == "alpha" ? HV_ESFM_Alpha :
					( s == "natsort" ? HV_ESFM_NatSort :
					( s == "none" ? HV_ESFM_Unsorted :  HV_ESFM_Alpha ) ) );
			i++;
		}else if( (!strcmp("--geometry",sz2) || !strcmp("--g",sz2) ) && *sz3 ){
			//--geometry WxH[+X+Y]
			auto szH = strchr( sz3, 'x' );
			auto szX = strchr( sz3, '+' );
			auto szY = strchr( (szX ? szX+1 : ""), '+' );
			szH = szH ? szH+1  : "0";
			szX = szX ? szX+1 : "-5229341";
			szY = szY ? szY+1 : "-5229341";
			Geometry2.first = ( std::string( *szX == 'C' ? "c" : "") +
								std::string( *szY == 'C' ? "m" : "") );
			Geometry2.second = {    atoi( szX ), atoi( szY ),
									atoi( sz3 ), atoi( szH ), };
			i++;
		}else if( !strcmp("--wmax2",sz2) ){
			// Format: --wmax2 FLOAT/E, where E being the screen edge: L|R|T|B.
			eMaximize2.first = atof( sz3 );
			const char* szEdge = strchr(sz3,'/');
			szEdge = ( szEdge ? szEdge+1 : "B" );
			eMaximize2.second =
				( strchr(szEdge,'L') ? HV_EMEN_LeftEdge :
				( strchr(szEdge,'R') ? HV_EMEN_RightEdge :
				( strchr(szEdge,'T') ? HV_EMEN_TopEdge :
				( strchr(szEdge,'B') ? HV_EMEN_BottomEdge : HV_EMEN_BottomEdge ) ) ) );
			i++;
		}else if( !strcmp("--high_prio",sz2) ){
			PrioChars.first = hf_PercentDecodeIf( sz3, 0 );
			i++;
		}else if( !strcmp("--low_prio",sz2) ){
			PrioChars.second = hf_PercentDecodeIf( sz3, 0 );
			i++;
		}else if( !strcmp("--bind_k",sz2) ){
			if( !bNoDefaultBinds && !bLAddedDefaultBinds ){
				addDefaultBinds( dpy );
				bLAddedDefaultBinds = 1;
			}
			std::string err;
			if( !parseBind( sz3, &err, dpy, 0 ) ){
				printf("WARN: binding failed: [%s]\n", err.c_str() );
				printf("      [%s]", sz3 );
				printf("\n");
			}
			bLMadeSomeBinds = 1;
			i++;
		}else if( !strcmp("--bNoDefaultBinds",sz2) ){
			if( (bNoDefaultBinds = atoi(szB)) && bLMadeSomeBinds ){
					printf("WARN: Some key or button binds has been already made.\n");
					printf("      Switch '--bNoDefaultBinds' is at this point ignored.\n");
					printf("      Make sure to place it before any '--bind_k' switch.\n");
					printf("\n");
			}
			i++;
		}else if( !strcmp("--nMoveByKeyAmount",sz2) ){
			nMoveByKeyAmount = atoi(sz3);
			i++;
		}else if( !strcmp("--config_file",sz2) ){
			printf("Processing config file '%s' ...\n", hf_basename2( sz3 ).c_str() );
			if( !hf_FileExists( sz3 ) ){
				printf("WARN: File not found. Specified by '--config_file' option.\n");
				printf("      [%s]\n", sz3 );
				printf("\n");
			}else{
				std::vector<std::string> lines2;
				hf_GetFileDSVContents( sz3, "\n", lines2, "\r\n\t\x20" );
				size_t nOldSize = argv2.size();
				const char* xxx, *yyy;
				for( const auto& a : lines2 ){
					xxx = a.c_str();
					if( (yyy = strchr( xxx, '\x20' )) ){
						std::string str2( xxx, yyy-xxx ), str3( yyy+1 );
						str2 = unquoteStrIf( str2, "\r\n\t\x20", "\r\n\t\x20" );
						str3 = unquoteStrIf( str3, "\r\n\t\x20", "\r\n\t\x20" );
						if( str2 != "--" )
							argv2.emplace_back( str2 );
						argv2.emplace_back( str3 );
					}else{
						argv2.push_back( a.c_str() );
					}
				}
				printf("Got %ld new arguments.\n", (argv2.size() - nOldSize) );
			}
			i++;
		}else{
			std::string arg3 = sz2;
			bool bOk = ( arg3.substr(0,1) != "-" );
			//if( !bOk && !arg3.empty() && hf_FileExists( arg3.c_str() ) )
			//	bOk = 1;
			if(bOk){
				LooseFiles.push_back(sz2);
			}
		}
	}
	if( !bNoDefaultBinds && !bLAddedDefaultBinds ){
		addDefaultBinds( dpy );
		bLAddedDefaultBinds = 1;
	}
}
bool HvOpts::testKey( int eActionTy, int nKeySym )const
{
	std::vector<KeySym>::const_iterator b;
	for( const auto& a : Binds2 ){
		if( a.eActionTy == eActionTy ){
			if( static_cast<int>(a.keysym2) == nKeySym )
				return 1;
		}
	}
	return 0;
}
bool HvOpts::testMouseButton( int eActionTy, int nMouseButton2 )const
{
	std::vector<KeySym>::const_iterator b;
	for( const auto& a : Binds2 ){
		if( a.eActionTy == eActionTy ){
			if( static_cast<int>(a.keysym2) == nMouseButton2 ){ //a.nMouseButton3
				return 1;
			}
		}
	}
	return 0;
}
std::string HvOpts::unquoteStrIf( std::string inp, const char* szTrimFirst, const char* szTrimLater )
{
	if( szTrimFirst && *szTrimFirst )
		inp = hf_trim_stdstring( inp, szTrimFirst );
	if( inp.size() >= 2 )
		if( (inp[0] == '\x22' && inp.back() == '\x22') || (inp[0] == '\x27' && inp.back() == '\x27') )
			inp = inp.substr( 1, inp.size()-2 );
	if( szTrimLater && *szTrimLater )
		inp = hf_trim_stdstring( inp, szTrimLater );
	return inp;
}
std::string HvOpts::getAllBinds()const   //--bShowBinds
{
	char bfr[256];
	std::string zzz;
	for( const auto& a : Binds2 ){
		snprintf( bfr, sizeof(bfr), "%8s %-12s --> %s %d\n",
				( a.bMouseButton ? "0x0" : HfArgs("0x%1").arg( a.keysym2, 16 ).c_str() ),
				(HfArgs("[%1]").arg(a.ssOrigKeyName.c_str()).c_str()),
				(HfArgs("[%1]").arg( lookupActionNameByType(a.eActionTy).c_str() ).c_str()),
				a.eActionTy );
		zzz += bfr;
	}
	return zzz;
}
void HvOpts::addDefaultBinds( Display* dpy )
{
	const char* aBinds3[] = {
		"         q=HV_ACTT_Quit",
		"    Escape=HV_ACTT_Quit",
		"     space=HV_ACTT_LoadNext",
		" Page_Down=HV_ACTT_LoadNext",
		"         2=HV_ACTT_LoadNext",
		"    period=HV_ACTT_LoadNext",
		" BackSpace=HV_ACTT_LoadPrev",
		"   Page_Up=HV_ACTT_LoadPrev",
		"         1=HV_ACTT_LoadPrev",
		"     comma=HV_ACTT_LoadPrev",//XK_comma=0x002c=44
		"         n=HV_ACTT_LoadNextR",
		"         p=HV_ACTT_LoadPrevR",
		"      Home=HV_ACTT_LoadFirst",
		"       End=HV_ACTT_LoadLast",
		"         g=HV_ACTT_CenterInFrame",
		"         f=HV_ACTT_FitInFrame",
		"         t=HV_ACTT_CenterOrFitInFrame",
		"      plus=HV_ACTT_ZoomInStep",
		"     equal=HV_ACTT_ZoomInStep",
		"     minus=HV_ACTT_ZoomOutStep",
		"underscore=HV_ACTT_ZoomOutStep",
		"         r=HV_ACTT_Repaint",
		"         o=HV_ACTT_ZoomReset",
		"        M1=HV_ACTT_MousePanButton",
		"        M4=HV_ACTT_ZoomInStep",
		"        M5=HV_ACTT_ZoomOutStep",
		"      Left=HV_ACTT_MoveLeft",
		"     Right=HV_ACTT_MoveRight",
		"      Down=HV_ACTT_MoveDown",
		"        Up=HV_ACTT_MoveUp",
		0,
	};
	for( int i=0; aBinds3[i]; i++ ){
		const char* bindstr = aBinds3[i];
		std::string err;
		if( !parseBind( bindstr, &err, dpy, 1 ) ){
            printf("WARN: Default binding failed, i:%d [eg1wYuc]\n", i );
            printf("      [%s]\n", err.c_str() );
            printf("\n");
		}
	}
}
/// Parses single key or mouse button bind.
/// Format is KEYNAME=ACTION, no quotes.
bool HvOpts::
parseBind( const char* szBindCmdArg, std::string* err4, Display* dpy, bool bIsDfltBind )
{
	std::string err3, &err2 = ( err4 ? *err4 : err3 );
	if( bIsDfltBind ){
		auto c = std::find_if( Binds2.begin(), Binds2.end(), [&]( const HvKeyBind& a )->bool{
				return !a.bDfltBind;
		});
		assert( c == Binds2.end() );
	}
	auto xxx = strchr( szBindCmdArg, '=' );
	if( !xxx ){
		err2 = "Bad key/button to action bind format. No equal sign found.";
		return 0;
	}
	std::string kname2( szBindCmdArg, xxx - szBindCmdArg ), kname3;
	std::string action2( xxx+1 );
	kname2 = hf_trim_stdstring( kname2, "\r\n\t\x20");
	action2 = hf_trim_stdstring( action2, "\r\n\t\x20");
	if( kname2.substr(0,3) == "XK_" ){
		kname3 = kname2.substr(3,-1);
	}else
		kname3 = kname2;
	if( kname3.empty() ){
		err2 = "Empty key name.";
		return 0;
	}
	HvKeyBind kba;
	std::vector<KeySym> keysyms2;
	if( kname3.size() >= 2 && strchr("mM", kname3[0]) && isdigit( kname3[1] ) ){
		kba.bMouseButton = 1;
		//kba.nMouseButton3
		kba.keysym2 = atoi( kname3.substr(1,-1).c_str() );
	}else{
		KeySym ksym2 = NoSymbol;
		if( NoSymbol == ( ksym2 = XStringToKeysym( kname3.c_str() ) ) ){
			err2 = HfArgs("Key name not recognized ('%1').").arg(kname2.c_str()).c_str();
			return 0;
		}
		kba.bKbdKey = 1;
		kba.keysym2 = ksym2;
	}
	if( action2.empty() ){
		err2 = "Empty action name.";
		return 0;
	}
	if( !(kba.eActionTy = lookupActionTypeByName( action2 ) )){
		err2 = HfArgs("Action name not recognized ('%1').").arg(action2.c_str()).c_str();
		return 0;
	}
	kba.ssOrigKeyName = kname2;
	kba.bDfltBind     = bIsDfltBind;
	{
		auto a = Binds2.end();
		a = std::find_if( Binds2.begin(), Binds2.end(),
				[&]( const HvKeyBind& a )->bool{
						return ( a.keysym2 == kba.keysym2 );
				});
		if( bIsDfltBind ){
			// blow is an assertive check whenver default, hardcoded binding
			// does not override any of its own binding.
			if( a != Binds2.end() ){
				printf("ERROR: Default key/button appears to be repeated in the binds list [kilXDnP].\n");
				printf("       Name of the key: '%s'\n", kba.ssOrigKeyName.c_str() );
				assert(!"Bad default bindings [bBpn1bLfY]");
			}
		}else{
			if( a != Binds2.end() ){
				if( !a->bDfltBind ){
					printf("WARN: New key/button bind is overriding old user bind [2evbqOG]\n");
					printf("      Old key: [%s], Old action: [%s]\n",
									a->ssOrigKeyName.c_str(),
									lookupActionNameByType(a->eActionTy).c_str() );
					printf("      New key: [%s], New action: [%s]\n",
									kba.ssOrigKeyName.c_str(),
									lookupActionNameByType(kba.eActionTy).c_str() );
					printf("\n");
				}else{
					Binds2.erase( a );
				}
			}
		}
	}
	Binds2.push_back( kba );
	return 1;
}



