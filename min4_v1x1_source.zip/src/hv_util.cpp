
#include "hv_util.h"
#include <string.h>
#include <algorithm>
#include <cmath>
#include <assert.h>
#include <link.h> //struct link_map
#include "Imlib2.h"
#include "hef/hef_data.h"

using namespace hef;


/*
double lanczos_size_ = 3.0;
inline double sinc(double x) {
  double pi = 3.1415926;
  x = (x * pi);
  if (x < 0.01 && x > -0.01)
    return 1.0 + x*x*(-1.0/6.0 + x*x*1.0/120.0);
  return sin(x)/x;
}

inline double LanczosFilter(double x) {
  if ( std::abs( x ) < lanczos_size_ ) {
    //double pi = 3.1415926;
    return sinc(x)*sinc(x/lanczos_size_);
  } else {
    return 0.0;
  }
}
// Image resizing - Lanczos Resampling error - Stack Overflow
// https://stackoverflow.com/questions/15800827/lanczos-resampling-error
struct Image {
	int w = 0, h = 0;
	std::vector<int> pixels2;

	Image( int w2, int h2 ) : w(w2), h(h2), pixels2( w2*h2, 0 ) {}

	int& operator()( int x, int y ){
		size_t idx = y*w + x;
		assert( idx < pixels2.size() );
		return pixels2[ idx ];
	}
};

Image Resize( Image& image, int new_rows, int new_cols) {
  int old_cols = image.w; //image.size().cols;
  int old_rows = image.h; //image.size().rows;
  double col_ratio = static_cast<double>(old_cols)/static_cast<double>(new_cols);
  double row_ratio = static_cast<double>(old_rows)/static_cast<double>(new_rows);

  // Apply filter first in width, then in height.
  Image horiz_image(new_cols, old_rows);
  for (int r = 0; r < old_rows; r++) {
    for (int c = 0; c < new_cols; c++) {
      // x is the new col in terms of the old col coordinates.
      double x = static_cast<double>(c)*col_ratio;
      // The old col corresponding to the closest new col.
      int floor_x = static_cast<int>(x);

      horiz_image(r,c) = 0.0;//horiz_image[r][c] = 0.0;
      double weight = 0.0;
      // Add up terms across the filter.
      for (int i = floor_x - lanczos_size_ + 1; i < floor_x + lanczos_size_; i++) {
        if (i >= 0 && i < old_cols) {
          double lanc_term = LanczosFilter(x - i);
          horiz_image(r,c) += image(r,i)*lanc_term;//horiz_image[r][c] += image[r][i]*lanc_term;
          weight += lanc_term;
        }
      }
      // Normalize the filter.
      horiz_image(r,c) /= weight;//horiz_image[r][c] /= weight;
      // Strap the pixel values to valid values.
      horiz_image(r,c) = (horiz_image(r,c) > 1.0) ? 1.0 : horiz_image(r,c);
      horiz_image(r,c) = (horiz_image(r,c) < 0.0) ? 0.0 : horiz_image(r,c);
    }
  }

  // Now apply a vertical filter to the horiz image_.
  Image new_image(new_cols, new_rows);
  for (int r = 0; r < new_rows; r++) {
    double x = static_cast<double>(r)*row_ratio;
    int floor_x = static_cast<int>(x);
    for (int c = 0; c < new_cols; c++) {
      new_image(r,c) = 0.0;
      double weight = 0.0;
      for (int i = floor_x - lanczos_size_ + 1; i < floor_x + lanczos_size_; i++) {
        if (i >= 0 && i < old_rows) {
          double lanc_term = LanczosFilter(x - i);
          new_image(r,c) += horiz_image(i,c)*lanc_term;//new_image(r,c) += horiz_image[i][c]*lanc_term;
          weight += lanc_term;
        }
      }
      new_image(r,c) /= weight;
      new_image(r,c) = (new_image(r,c) > 1.0) ? 1.0 : new_image(r,c);
      new_image(r,c) = (new_image(r,c) < 0.0) ? 0.0 : new_image(r,c);
    }
  }
  return new_image;
}//*/

struct _HvBoxPrecalc {
    int boxStart;
    int boxEnd;
};
inline int _HvBoxBetween( int value, int low, int high )
{
    return std::max( std::min( value, high ), low );
}
void _HvResampleBoxPrecalc( std::vector<_HvBoxPrecalc>& boxes, int oldDim )
{
	const int newDim = boxes.size();
	const double scale_factor_1 = double(oldDim) / newDim;
	const int scale_factor_2 = (int)(scale_factor_1 / 2);

	for ( int dst = 0; dst < newDim; ++dst ){
		// Source pixel in the Y direction
		const int src_p = int(dst * scale_factor_1);

		_HvBoxPrecalc& precalc = boxes[dst];
		precalc.boxStart = _HvBoxBetween( int(src_p - scale_factor_1/2.0 + 1),
								0, oldDim - 1 );
		precalc.boxEnd = _HvBoxBetween( std::max( precalc.boxStart + 1,
								int(src_p + scale_factor_2) ), 0, oldDim - 1 );
	}
}
/**
	Image scalling using simple Resample-Box method.
	Can be used to upscale or downscale the image.
	Taken from wxWidgets:
		 wxImage wxImage::ResampleBox(int width, int height)
		 ".../src/common/image.cpp" and ".../include/wx/image.h".
	\param pixels2 - input image.
	\param width2  -
	\param height2 -
	\param pixels3 - output image.
	\param width3  -
	\param height3 -
	\param flags2 - flags, fe. \ref HV_RBF_SkipAlpha.
	\param bRunSemaphore - optional, set to 0 to not use.
				this is for multi-threading.
	            if the pointer is set, it must point to a boolean value that gets
	            monitored for true state. if at any time value changes to false,
	            image reasampling stops and function returns failure.

	\verbatim
		Original wxWidgets Note:
		// This function implements a simple pre-blur/box averaging method for
		// downsampling that gives reasonably smooth results. To scale the image
		// down we will need to gather a grid of pixels of the size of the scale
		// factor in each direction and then do an averaging of the pixels.
	\endverbatim
*/
bool HvImageResampleBox( const std::vector<uint32_t>& pixels2, int width2, int height2,
						std::vector<uint32_t>& pixels3, int width3, int height3,
						int flags2, const bool* bRunSemaphore )
{
	const bool dmy0 = 1, &bRun = ( bRunSemaphore ? *bRunSemaphore : dmy0 );

	pixels3.resize( width3*height3, 0 ); //wxImage ret_image(width, height, false);

	std::vector<_HvBoxPrecalc> vPrecalcs(height3);//wxVector
	std::vector<_HvBoxPrecalc> hPrecalcs(width3);//wxVector

	_HvResampleBoxPrecalc( vPrecalcs, height2 );//_HvResampleBoxPrecalc(vPrecalcs, M_IMGDATA->m_height);
	_HvResampleBoxPrecalc( hPrecalcs, width2 );//_HvResampleBoxPrecalc(hPrecalcs, M_IMGDATA->m_width);

	const uint8_t* src_data = reinterpret_cast<const uint8_t*>( &pixels2[0] );//M_IMGDATA->m_data;
	uint8_t*       dst_data = reinterpret_cast<uint8_t*>( &pixels3[0] ); //ret_image.GetData();
	int averaged_pixels, src_px_index;
	double sum_r, sum_g, sum_b, sum_a;

	for( int y = 0; y < height3 && bRun; y++ ){         // Destination image - Y direction
		// Source pixel in the Y direction
		const _HvBoxPrecalc& vPrecalc = vPrecalcs[y];
		for( int x = 0; x < width3 && bRun; x++ ){      // Destination image - X direction
			// Source pixel in the X direction
			const _HvBoxPrecalc& hPrecalc = hPrecalcs[x];
			// Box of pixels to average
			averaged_pixels = 0;
			sum_r = sum_g = sum_b = sum_a = 0.0;
			for( int j = vPrecalc.boxStart; j <= vPrecalc.boxEnd && bRun; ++j ){
				for( int i = hPrecalc.boxStart; i <= hPrecalc.boxEnd && bRun; ++i ){
					// Calculate the actual index in our source pixels
					src_px_index = j * width2 + i;
					sum_r += src_data[ src_px_index * 4 + 0 ];
					sum_g += src_data[ src_px_index * 4 + 1 ];
					sum_b += src_data[ src_px_index * 4 + 2 ];
					if( !(flags2 & HV_RBF_SkipAlpha) )
						sum_a += src_data[src_px_index * 4 + 3]; //sum_a += src_alpha[src_px_index];
					averaged_pixels++;
				}
			}
			// Calculate the average from the sum and number of averaged pixels
			dst_data[0] = (uint8_t)(sum_r / averaged_pixels);//(unsigned char)(sum_r / averaged_pixels);
			dst_data[1] = (uint8_t)(sum_g / averaged_pixels);//(unsigned char)(sum_g / averaged_pixels);
			dst_data[2] = (uint8_t)(sum_b / averaged_pixels);//(unsigned char)(sum_b / averaged_pixels);
			if( !(flags2 & HV_RBF_SkipAlpha) )
				dst_data[3] = (uint8_t)(sum_a / averaged_pixels); //*dst_alpha++ = (unsigned char)(sum_a / averaged_pixels);
			dst_data += 4;
		}
	}
	return bRun;
}
/**
	Checks what shared libraries are loaded at run time.
	>> How to check what shared libraries are loaded at run time for a given process?
	>> by "abyss.7"
	>> https://stackoverflow.com/questions/5103443/how-to-check-what-shared-libraries-are-loaded-at-run-time-for-a-given-process
	>> ref-2: http://syprog.blogspot.ru/2011/12/listing-loaded-shared-objects-in-linux.html
	>> >> The same should work with dlinfo() called with RTLD_DI_LINKMAP (see "man dlinfo")
	\code
		Example output:
		so: ./libjpeg.so.9
		so: /lib/x86_64-linux-gnu/libdl.so.2
		so: /lib/x86_64-linux-gnu/libgcc_s.so.1
		so: /lib/x86_64-linux-gnu/libc.so.6
		so: /lib64/ld-linux-x86-64.so.2
		so: /lib/x86_64-linux-gnu/libm.so.6
	\endcode
//*/
void HvGetSharedLibraries( std::vector<std::string>& outp )
{
	using UnknownStruct = struct unknown_struct {
		void*  pointers[3];
		struct unknown_struct* ptr;
	};
	auto* handle = dlopen( NULL, RTLD_NOW );
	auto* p = reinterpret_cast<UnknownStruct*>(handle)->ptr;
	auto* mapx = reinterpret_cast<struct link_map*>(p->ptr);

	while( mapx ){
		//printf("so: %s\n", map->l_name );
		outp.push_back( mapx->l_name );
		// do something with |map| like with handle, returned by |dlopen()|.
		mapx = mapx->l_next;
	}

}

/// Creates new thread.
/// Remember to not capture by reference, only by copy.
bool HvCreateThread( std::function<void(void*)> calb2, void* param2, pthread_t* thread3 )
{
	pthread_t thread4, *thread2 = ( thread3 ? thread3 : &thread4 );
	*thread2 = 0;
	struct SArgs{
		std::function<void(void*)> calb3;
		void* param2;
	};
	SArgs* ptr = new SArgs;
	ptr->calb3  = calb2;
	ptr->param2 = param2;
	int iret = pthread_create( thread2, 0, []( void* ptr_ )->void*{
			SArgs* ptr = reinterpret_cast<SArgs*>( ptr_ );
			ptr->calb3( ptr->param2 );
			delete ptr;
			return 0; //pthread_self()
	}, ptr );
	if( iret ){ // if error
		//printf( "ERROR: pthread_create() failed, return code %d\n", iret );
		delete ptr;
		return 0;
	}
	return 1;
}

bool HvImageResampleOption( const std::vector<uint32_t>& pixels2, int width2, int height2,
						std::vector<uint32_t>& pixels3, int width3, int height3,
						int flags2, const bool* bRunSemaphore )
{
	;
//	return HvImageResampleBox( pixels2, width2, height2,
//						pixels3, width3, height3, flags2, bRunSemaphore );
	return HvImageResampleImlib2( pixels2, width2, height2,
						pixels3, width3, height3, flags2, bRunSemaphore );
}
bool HvImageResampleImlib2( const std::vector<uint32_t>& pixels2, int width2, int height2,
						std::vector<uint32_t>& pixels3, int width3, int height3,
						int flags2__, const bool* bRunSemaphore__ )
{
	imlib_context_set_anti_alias( 0 );
	Imlib_Image inpd = imlib_create_image_using_data(
				width2, height2, (uint32_t*)&pixels2[0] );
	if( !inpd )
		return 0;
	pixels3.resize( width3 * height3, 0 );

//	uint32_t tm2 = hf_getGlobalTicks();
	Imlib_Image buffer2 = imlib_create_image_using_data(
				width3, height3, (uint32_t*)&pixels3[0] );
	if( !buffer2 )
		return 0;
	imlib_context_set_image( buffer2 );
	imlib_blend_image_onto_image( inpd, 0, 0,0,
				width2, height2,
				0,0, width3, height3 );//*/
//	uint32_t tm3 = hf_getGlobalTicks();
//	printf("Imlib2 time delta: %u ms\n", tm3-tm2 );

//	imlib_context_set_image( inpd );
//	Imlib_Image buffer2 = imlib_create_cropped_scaled_image(
//					0,0, width2, height2,
//					width3, height3 );

	imlib_free_image();
//	imlib_free_image_and_decache();

	return 1;
}
//
/**
	Analyzes input box and returns it's rectangle and new dimensions as if
	it (box) was a resized image inside a viewport of an UI window.

	\param boxx - input box to be scalled.
	\param pos2 - position of input box.
	\param fZoom - zoom to perform on the input box ('boxx') at input position ('pos2').
	\param frameDim - frame dimensions the rescalled input is clipped to.
	&nbsp;            //rectangle of it is created as if: '{0,0,frameDim.w,frameDim.h,}'.

	\return  -  Rectangle and dimensions of the input box (as std::pair).
	&nbsp;      Rectangle is the clip-area and dimensions is the resize-to,
	&nbsp;      width and height.

	"rects_6part_clip_hfzjfue.png"
*/
std::pair<HfTRct<int>,HfTDim<int> >
HvBoxToClippedAtPosZoomFrame( const HfDim& boxx, const HfPt& pos2, float fZoom,
				const HfRct& frame2 )
{
	HfFMidRct sca2 = (HfFRct({ float(pos2.x), float(pos2.y), (boxx.w*fZoom), (boxx.h*fZoom),}) ).toMidRect();
	HfFMidRct frm2 = HfFRct().fromIntRect(frame2).toMidRect();//HfFRct({0,0,float(frameDim.w),float(frameDim.h),}).toMidRect();
	HfFMidRct clp2 = sca2.getClipped( frm2 );
	HfFMidRct clp3 = { clp2.p, clp2.d / fZoom, }; // back to rect coords relative to input dimensions.
	HfFDim cd2 = HfFRct().fromMidRect(frm2).clip6PartCD( HfFRct().fromMidRect(sca2) );
	cd2 = {( cd2.w < 0.f ? -cd2.w : 0.f ), ( cd2.h < 0.f ? -cd2.h : 0.f ),};
	HfFDim cd3 = cd2 / fZoom;
	// isolate output rect and dim (T-integer) with rounding.
	HfTRct<int> clp4 = HfFRct().fromMidRect(clp3).toIntRectRounded();
	//HfTRct<int> clp4 = HfFRct().fromMidRect(clp3).toIntRect();

	HfTDim<int> cd4 = cd3.toIntDimRounded();
	//HfTDim<int> cd4({int(cd3.w), int(cd3.h),});//cd4.w = std::min(cd4.w,clp4.w);//cd4.h = std::min(cd4.h,clp4.h);
	//
	HfTRct<int> srcRect = { cd4.w, cd4.h, clp4.w, clp4.h, };
	//HfTDim<int> destDim = HfFRct().fromMidRect(clp2).toIntRectRounded().getDim();
	HfTDim<int> destDim = HfFRct().fromMidRect(clp2).toIntRect().getDim();
	//printf("cd4:%s sRct:%s ddim:%s\n", cd4.toStr().c_str(), srcRect.toStr().c_str(), destDim.toStr().c_str() );
	return { srcRect, destDim, };
}
/// Returns X Y offset ... .
/// \param flags3__ - not used.
std::pair<int,int>
HvGetBoxOffsetForULOnPreScale( const HfRct& imgRect2, const HfPt& xyMouse2,
			float fOldScale, float fNewScale, int flags3__ )
{
	std::pair<int,int> res(0,0);
	// Challenge Note: if cursor x pos is at image w length, then it must happen that
	// right edge not move at all.
	HfPt  xyMouse = xyMouse2;
	HfRct imgRect = imgRect2;
	HfDim oldDim = imgRect.getDim() * fOldScale;
	HfDim newDim = imgRect.getDim() * fNewScale;
	HfDim sizeDt = { newDim.w - oldDim.w, newDim.h - oldDim.h, };
	HfPt  xyMRel = { xyMouse.x - imgRect.x, xyMouse.y - imgRect.y,};
	xyMRel.x = std::min( xyMRel.x, oldDim.w );
	xyMRel.y = std::min( xyMRel.y, oldDim.h );
	// get perc pos of corsor inside image, separate for x and y.
	float fHPerc = -1.f, fVPerc = -1.f;
	if( xyMRel.x >= 0 && xyMRel.x <= oldDim.w ){
		fHPerc = float(xyMRel.x) / oldDim.w;
		if( fHPerc >= 0.f && fHPerc <= 1.f )
			//res.first = -int( llroundf(sizeDt.w * fHPerc) );
			res.first = -int( (sizeDt.w * fHPerc) );
	}
	if( xyMRel.y >= 0 && xyMRel.y <= oldDim.h ){
		fVPerc = float(xyMRel.y) / oldDim.h;
		if( fVPerc >= 0.f && fVPerc <= 1.f )
			//res.second = -int( llroundf(sizeDt.h * fVPerc)  );
			res.second = -int( (sizeDt.h * fVPerc)  );
	}
	//printf("xm:%d iw:%d wDt:%d f:%.2f ofsx:%d\n",
	//		xyMRel.x, imgRect.w, sizeDt.w, fHPerc, res.first );
	return res;
}

void HvSetupTimevalFromMilisecs( struct timeval* tvv, int nMilisconds )
{
	tvv->tv_usec = ( nMilisconds % 1000 ) * 1000;
	tvv->tv_sec  = nMilisconds / 1000; // number of seconds.
}
/// Natural sorting helper (aka nat-sort, aka natsort).
HvNatSortTokens_t HvTokenizeStringToNumericAware( const char* inp )
{
	const char* deci = "0123456789";
	HvNatSortTokens_t ouu;
	for( ; *inp; inp++ ){
		int k = 0;
		for(; *inp && strchr( deci, *inp ); k++, inp++ );
		if(!k){
			ouu.push_back( HvNatSortToken( *inp, 0, 0 ) );
		}else{
			std::string str( inp-k, k );
			ouu.push_back( HvNatSortToken( 0, atoi( str.c_str() ), str.size() ) );
			inp--;
		}
	}
	return ouu;
}
HvBoxDirtyOut& HvBoxDirtyOut::appendFromOther( const HvBoxDirtyOut& otherr )
{
	dirty3.insert( dirty3.end(), otherr.dirty3.begin(), otherr.dirty3.end() );
	return *this;
}
int _HvNumericAwareCompareToken( const HvNatSortTokens_t::value_type& aaa, const HvNatSortTokens_t::value_type& bbb )
{
	if( aaa.first && bbb.first ){
		return ( aaa.first == bbb.first ? 0 : ( aaa.first < bbb.first ? -1 : 1 ) );
	}else if( !aaa.first && !bbb.first ){
		return ( aaa.second == bbb.second ?
			( aaa.strLen2 < bbb.strLen2 ? -1 : ( aaa.strLen2 == bbb.strLen2 ? 0 : 1 ) ) :
				( aaa.second < bbb.second ? -1 : 1 ) );
	}else{
		assert( !aaa.first || !strchr("0123456789", aaa.first ) );
		assert( !bbb.first || !strchr("0123456789", bbb.first ) );
		if( aaa.first && !bbb.first ){
			return ( aaa.first < '0' ? -1 : 1 );
		}else if( bbb.first && !aaa.first ){
			return ( bbb.first <= '0' ? 1 : -1 );
		}else{
			assert(0);
		}
	}
	assert(0);
	return 0;
}

int HvNumericAwareTokensCompare( const HvNatSortTokens_t& strA, const HvNatSortTokens_t& strB )
{
	HvNatSortTokens_t::const_iterator a,b;
	a = strA.begin();
	b = strB.begin();
	for(; a != strA.end() && b != strB.end(); ++a, ++b ){
		int res = _HvNumericAwareCompareToken( *a, *b );
		if( res )
			return res;
	}
	if( a == strA.end() && b == strB.end() ){
		return 0;
	}else if( a != strA.end() ){
		return 1;
	}
	return -1;
}
/// Test purposes function.
void HvTestNatSertToeknsCompare()
{
	std::vector<HvNatSortTokens_t> lsTknzd;
	std::vector<std::string> strs2 = {
		"abc",
		"bcd",
		"aaa11a",
		"aaa2x",
		"aaa00x2",
		"aaa00x3",
		"aaa00x1",
		"c0a",
		"c11a",
		"c02a",
		"b01b",
		"b003a",
		"b2x",
	};
	for( const auto& a : strs2 ){
		printf("cstr: [%s]\n", a.c_str() );
		lsTknzd.push_back( HvTokenizeStringToNumericAware( a.c_str() ) );
	}
	std::sort( lsTknzd.begin(), lsTknzd.end(), [](
			const HvNatSortTokens_t& aaa, const HvNatSortTokens_t& bbb )->bool{
					int res = HvNumericAwareTokensCompare( aaa, bbb );
					return (res == -1);
	});
	for( const auto& a : lsTknzd ){
		for( const auto& b : a ){
			if( b.first )
				printf("%c", b.first );
			else
				printf("%d(%d)", b.second, static_cast<int>(b.strLen2) );
		}
		printf("\n");
	}
}




HvComposedBox3::
HvComposedBox3( const HfRct& frame2, const HfRct& rect2 )
	: EnclX( frame2.x, frame2.w, rect2.x, rect2.w )
	, EnclY( frame2.y, frame2.h, rect2.y, rect2.h )
	, ScaOrig( {rect2.x, rect2.y,} )
	, OrigRectDim( rect2.w, rect2.h )
{
//	EnclX.resetZoom( 1.0f, ScaOrig.x );
//	EnclY.resetZoom( 1.0f, ScaOrig.y );
}
void HvComposedBox3::setScaleOrigin3( const HfPt& inp )
{
	ScaOrig = inp;
}
void HvComposedBox3::setFrame2( const HfRct& frame2 )
{
	EnclX.resetStretch( { frame2.x, frame2.w,} );
	EnclY.resetStretch( { frame2.y, frame2.h,} );
}
HvBoxDirtyOut HvComposedBox3::centerInFrame2()
{
	auto segx = EnclX.getSegment();
	auto segy = EnclY.getSegment();
	auto frax = EnclX.getStretch();
	auto fray = EnclY.getStretch();
	int framidx = frax.Pos2 + frax.Len2 / 2;
	int framidy = fray.Pos2 + fray.Len2 / 2;
	int xSeg = framidx - segx.Len2 / 2;
	int ySeg = framidy - segy.Len2 / 2;

	//segx.Pos2 += inp.x;
	//segy.Pos2 += inp.y;
	HvBoxDirtyOut bso = resetRectPosition( { xSeg, ySeg, } );
	return bso;
}
HvBoxDirtyOut HvComposedBox3::resetScale( double inp )
{
	HfRct oldRc( getCurrentComposition().composedOrigin, getCurrentComposition().displayDim );

	auto lsx = EnclX.resizeSegmentAtOriginOrAtEdge( OrigRectDim.w * inp, ScaOrig.x );
	auto lsy = EnclY.resizeSegmentAtOriginOrAtEdge( OrigRectDim.h * inp, ScaOrig.y );

	HfRct newRc( getCurrentComposition().composedOrigin, getCurrentComposition().displayDim );
	HvBoxDirtyOut bso; //mergeWHDirtyRects( lsx, lsy, oldRc );
	bso.dirty3 = newRc.getRectsInsideBigger( oldRc, 0x0 );

	return bso;
}
HvBoxDirtyOut HvComposedBox3::addPositionDelta2( const HfPt& inp )
{
	auto segx = EnclX.getSegment();
	auto segy = EnclY.getSegment();
	segx.Pos2 += inp.x;
	segy.Pos2 += inp.y;
	HvBoxDirtyOut bso = resetRectPosition( { segx.Pos2, segy.Pos2, } );
	return bso;
}
HvBoxCurrentOut HvComposedBox3::getCurrentComposition()const
{
	HvBoxCurrentOut bco;
	bco.imageCropRect.x = EnclX.getPortionOfSegmentUnscaled().Pos2;//EnclX.getPortionOfSegmentUnscaled().Pos2;
	bco.imageCropRect.y = EnclY.getPortionOfSegmentUnscaled().Pos2;//EnclY.getPortionOfSegmentUnscaled().Pos2;
	bco.imageCropRect.w = EnclX.getPortionOfSegmentUnscaled().Len2;//getPortionOfSegment//EnclX.getSegment().Len2;
	bco.imageCropRect.h = EnclY.getPortionOfSegmentUnscaled().Len2;

	bco.displayDim.w = EnclX.getPortionOfSegment().Len2;//EnclX.getPortionOfSegment().Len2;
	bco.displayDim.h = EnclY.getPortionOfSegment().Len2;//EnclY.getPortionOfSegment().Len2;

	bco.composedOrigin.x = EnclX.getPortion().Pos2;//getSegment
	bco.composedOrigin.y = EnclY.getPortion().Pos2;
	return bco;
}
bool HvComposedBox3::isRectCompletelyInside()const
{
	if( EnclX.isSegmentCompletelyInside() )
		if( EnclY.isSegmentCompletelyInside() )
			return 1;
	return 0;
}
HvBoxDirtyOut HvComposedBox3::resetRectPosition( const HfPt& inp )
{
	HvBoxDirtyOut bso;
	auto oldSegX = EnclX.getPortion();
	auto oldSegY = EnclY.getPortion();//getPortionOfSegment
	EnclX.resetSegment( { inp.x, EnclX.getSegment().Len2, } );
	EnclY.resetSegment( { inp.y, EnclY.getSegment().Len2, } );
	auto newSegX = EnclX.getPortion();
	auto newSegY = EnclY.getPortion();
	HfRct oldRc = { oldSegX.Pos2, oldSegY.Pos2, oldSegX.Len2, oldSegY.Len2, };
	HfRct newRc = { newSegX.Pos2, newSegY.Pos2, newSegX.Len2, newSegY.Len2, };
	HfRct mrgdRc = newRc.getMaxExtend( oldRc );
	bso.dirty3 = newRc.getRectsInsideBigger( mrgdRc, 0x0 );
	return bso;
}
HfRct HvComposedBox3::
rectFrom2xSegment( const HfSegmentHO<int,double>& a, const HfSegmentHO<int,double>& b )
{
	return { a.Pos2, b.Pos2, a.Len2, b.Len2,};
}
/// Returns new scale and new pos to which to change the inner rectangle
/// to make it fit inside the frame (the frame of this object).
std::pair<double,HfPt>
HvComposedBox3::getFrameFitMetrics()const
{
	std::pair<double,HfPt> ouu( 0.0, {0,0,} );
	auto rct2 = rectFrom2xSegment( EnclX.getStretch(), EnclY.getStretch() );
	double fScale2 = std::min(
					double(rct2.w) / OrigRectDim.w,
					double(rct2.h) / OrigRectDim.h );
	int w = fScale2 * OrigRectDim.w;
	int h = fScale2 * OrigRectDim.h;
	rct2.x += rct2.w / 2 - w / 2;
	rct2.y += rct2.h / 2 - h / 2;
	ouu = { fScale2, { rct2.x, rct2.y,} };
	return ouu;
}

// http://stackoverflow.com/questions/1494399/how-do-i-search-find-and-replace-in-a-standard-string/1494435#1494435
std::string HvStrReplace( std::string str, const std::string& oldStr, const std::string& newStr )
{
	std::string::size_type pos = 0u;
	while( (pos = str.find(oldStr, pos)) != std::string::npos ){
		str.replace( pos, oldStr.length(), newStr );
		pos += newStr.length();
	}
	return str;
}
std::pair<bool,int>
HvCharCmpWithPrio_( char a, char b, const char* sHighPrio )
{
	const char* xxx, *yyy;
	if( (xxx = strchr( sHighPrio, a )) ){
		if( (yyy = strchr( sHighPrio, b )) ){
			if( xxx == yyy )
				return {1,0,};
			return { 1, ( xxx < yyy ? -1 : 1 ), };
		}
		return {1,-1,};
	}
	return {0,0,};
}
/// String compare ... .
/// flags3 - eg. \ref HV_SCWP_CaseSensitive.
int HvStrCmpWithPrio( const char* a, const char* b, const char* sHighPrio, const char* sLowPrio, int flags3 )
{
	char ch2,ch3;
	std::pair<bool,int> rs2;
	int i = 0, rs3;
	for( ; a[i] && b[i]; ++i ){
		ch2 = a[i];
		ch3 = b[i];
		if( ch2 == ch3 )
			continue;
		if( (rs2 = HvCharCmpWithPrio_( ch2, ch3, sHighPrio )).first )
			return rs2.second;
		if( (rs2 = HvCharCmpWithPrio_( ch3, ch2, sHighPrio )).first )
			return rs2.second * -1;
		if( (rs2 = HvCharCmpWithPrio_( ch2, ch3, sLowPrio )).first )
			return rs2.second * -1;
		if( (rs2 = HvCharCmpWithPrio_( ch3, ch2, sLowPrio )).first )
			return rs2.second;
		if( flags3 & HV_SCWP_CaseSensitive ){
			if( ch2 < ch3 ){
				return -1;
			}else if( ch2 > ch3 )
				return 1;
		}else{
			if( (rs3 = hf_charcmp_ci( ch2, ch3 )) )
				return rs3;
		}
	}
	if( !a[i] && b[i] ){
		return -1;
	}else if( a[i] && !b[i] ){
		return 1;
	}
	return 0;
}


