#ifndef _HEF_FLAT_GEOM_H_
#define _HEF_FLAT_GEOM_H_
#include <vector>
#include <string>
namespace hef{

/**
	\file
	Basic geometry, possibly 1D and 2D only.
	Flat geometric objects.
	Using C++11 features (switch: -std=c++11).
	For template classes having code in cpp file, see instantiations section named:
	"Instantiations [ost3v7qvhf8m]" for actual types that has been instantiated.
*/


// forward declarations.
template<class Txv> struct HfTPt;
template<class Tvz> struct HfTMidRct;
template<class Tvv> struct HfTRct;
template<class Tvx> struct HfTDim;
//
using HfDim = HfTDim<int>;
using HfFDim = HfTDim<float>;
using HfDDim = HfTDim<double>;
using HfRct = HfTRct<int>;
using HfFRct = HfTRct<float>;
using HfDRct = HfTRct<double>;
using HfPt = HfTPt<int>;
using HfFPt = HfTPt<float>;
using HfDPt = HfTPt<double>;
using HvMidRct = HfTMidRct<int>;
using HfFMidRct = HfTMidRct<float>;
using HfDMidRct = HfTMidRct<double>;

/// Point.
template<class Txv>
struct HfTPt {
	Txv x, y;

	HfTPt() : x(0), y(0) {}
	HfTPt( std::initializer_list<Txv> inp );
//	/// Constructor Overload for 'long long int' only.
//	template<
//		typename T, typename = typename std::enable_if<
//			std::is_same<T, long long int>::value //fe. '0LL'
//		>::type
//	>
//	explicit HfTPt( T dmy0 ) {}
	HfTPt subConst( const HfTPt& oth )const{
		return { x - oth.x, y - oth.y, };
	}
	HfTPt& add( const HfTPt& oth ){
		x += oth.x;
		y += oth.y;
		return *this;
	}
	HfTPt operator+( const HfTPt& oth )const{
		return HfTPt(*this).add(oth);
	}
	HfTPt operator-()const {return {-x,-y,};}
	HfTPt& set( const std::pair<Txv,Txv>& inp ){
		x = inp.first;
		y = inp.second;
		return *this;
	}
	auto toStr()const -> std::string{
		return ( HfTDim<Txv>::sprintfAny( x ) + "," + HfTDim<Txv>::sprintfAny( y ) );
	}
	bool       isZero()const {return !x && !y;}
	HfTPt<Txv> getMaxWith( const HfTPt<Txv>& otherr )const;
	HfTPt<Txv> getMinWith( const HfTPt<Txv>& otherr )const;
}; // HfTPt

/// Dimension.
template<class Tvx>
struct HfTDim {
	Tvx w, h;
	;            HfTDim() {}
	;            HfTDim( Tvx w_, Tvx h_ ) : w(w_), h(h_) {}
	HfTDim<Tvx>& fromStdPair( const std::pair<Tvx,Tvx>& inp );
	HfTDim<Tvx>  operator*( float inp )const;
	HfTDim<Tvx>  operator/( float inp )const;
	auto         toStr()const -> std::string;
	bool         isPointInside( const HfTPt<Tvx>& inp )const;
	bool         isEmpty()const {return (!w || !h);}
	bool         operator==( const HfTDim<Tvx>& otherr )const;
	bool         operator!=( const HfTDim<Tvx>& otherr )const;
	HfTDim<int>  toIntDimRounded()const;
	Tvx          getArea()const {return w*h;}
	static auto  sprintfAny( float a ) -> std::string;
	static auto  sprintfAny( double a ) -> std::string;
	static auto  sprintfAny( int a ) -> std::string;
}; // HfTDim

/// Rectangle with origin at it's upper left corner.
template<class Tvv>
struct HfTRct {
	Tvv x,y,w,h;
	//
	;            HfTRct() : x(0), y(0), w(0), h(0) {}
	;            HfTRct( std::initializer_list<Tvv> inp );
	;            HfTRct( HfTPt<Tvv> p, HfTDim<Tvv> d ) : x(p.x), y(p.y), w(d.w), h(d.h) {}
	Tvv          r()const {return x+w;} // x coords of right edge.
	Tvv          b()const {return y+h;} // y coords of bottom edge.
	std::string  toStr()const;
	HfTRct<Tvv>  getClipped( const HfTRct<Tvv>& inp )const;
	HfTRct<Tvv>  getClippedInv( const HfTRct<Tvv>& inp )const;
	HfTRct<Tvv>& clipAgainst( const HfTRct<Tvv>& inp );
	bool         constrainTo( const HfTRct<Tvv>& inp );
	HfTRct<Tvv>  filterInViewPort( const HfTRct<Tvv>& vport, HfTPt<Tvv>* outp, int flags2 )const;
	bool         isEmpty()const {return !w || !h;}
	bool         isEmpty2()const;
	bool         operator==( const HfTRct<Tvv>& otherr )const;
	bool         operator!=( const HfTRct<Tvv>& otherr )const;
	HfTRct<Tvv>  operator/( float inp )const;
	HfTRct<Tvv>  operator*( float inp )const;
	bool         isPointInside( const HfTPt<Tvv>& inp )const;
	HfTRct<int>  toIntRectRounded()const;
	HfTRct<int>  toIntRect()const;
	HfTRct<Tvv>& fromIntRect( const HfTRct<int>& inp );
	HfTDim<Tvv>  clip6PartCD( const HfTRct<Tvv>& rectB )const;
	HfTDim<Tvv>  clip6PartEF( const HfTRct<Tvv>& rectB )const;
	HfTDim<Tvv>  clip6PartGH( const HfTRct<Tvv>& rectB )const;
	auto         toMidRect()const -> HfTMidRct<Tvv>;
	auto         fromMidRect( const HfTMidRct<Tvv>& inp ) -> HfTRct<Tvv>&;
	HfTDim<Tvv>  getDim()const {return {w,h,};}
	HfTPt<Tvv>   getUL()const {return {x,y,};}
	auto         getRectsInsideBigger( const HfTRct<Tvv>& biggerr, int flags4 )const -> std::vector<HfTRct<Tvv> >;
	HfTRct<Tvv>  getMaxExtend( const HfTRct<Tvv>& otherr )const;
}; // HfTRct


/// Rectangle with origin in it's middle.
template<class Tvz>
struct HfTMidRct {
	HfTPt<Tvz>  p; //point, origin, center of the rectangle.
	HfTDim<Tvz> d; //dimensions.
	//
	HfTMidRct<Tvz>  operator/( float inp )const;
	HfTMidRct<Tvz>  operator*( float inp )const;
	bool            isEmpty()const {return (!d.w || !d.h);}
	std::string     toStr()const;
	HfTMidRct<Tvz>  getClipped( const HfTMidRct<Tvz>& inp )const;
	HfTMidRct<int>  toIntMRectRounded()const;
};
enum{
	/// Flags for HfRct::filterInViewPort().
	HF_FIVPF_NegativeDimensionOK = 0x1,
};
enum{
	/// flags for HfTRct<Tvv>::getRectsInsideBigger().
	HF_RIB_KeepEmpty = 0x1,
	HF_RIB_DontMerge = 0x2,
};
enum{
	/// Flags for HfSegmentHO::scaleAtOriginOrAtEdge().
	HF_SGF_Prevent0Len = 0x1,
};

/// Segment as position and length.
/// A half-open line segment with
/// its posistion, Pos2, considered inside while its end, Pos2+Len2 outside.
template<class Txi,class Txf>
struct HfSegmentHO {
	;            HfSegmentHO( Txi pos_, Txi len_ ) : Pos2(pos_), Len2(len_) {}
	;            HfSegmentHO(){}
	virtual Txi  getEndPos()const {return Pos2 + Len2;}
	virtual void scaleAtOriginOrAtEdge( Txf scale_, Txi orig_, int flags2 );
	virtual auto getDifference( const HfSegmentHO<Txi,Txf>& otherr )const -> std::vector<HfSegmentHO<Txi,Txf> >;
	virtual void makeAbsoluteIfLenNeg();
	virtual auto getClipped( const HfSegmentHO<Txi,Txf>& otherr )const -> HfSegmentHO<Txi,Txf>;
	virtual auto getInverted()const -> HfSegmentHO<Txi,Txf>;
	static void  simpleSegmentTests2();
	virtual auto resizeAtOriginOrAtEdge( Txi len2, Txi orig2 ) -> std::vector<HfSegmentHO<Txi,Txf> >;
	//
	Txi Pos2, Len2;
};
/**
	Enclosure in one-dimensional space as an outer-stretch and an inner-segment.
	Stretch and segment, both, are represented as position and length.
	Provides scaling and other routines with 'dirty' segments output.
*/
template<class Txi, class Txf>
struct HfEnclosure
{
	;            HfEnclosure( Txi posStrch, Txi lenStrch, Txi posSeg, Txi lenSeg );
	virtual auto getPortion()const -> HfSegmentHO<Txi,Txf>;
	virtual auto getPortionOfSegment()const -> HfSegmentHO<Txi,Txf>;
	virtual auto scaleSegmentAtOriginOrAtEdge( Txf scale2, Txi orig2, int flags2 ) -> std::vector<HfSegmentHO<Txi,Txf> >;
	virtual auto resetSegment( const HfSegmentHO<Txi,Txf>& seg2 ) -> std::vector<HfSegmentHO<Txi,Txf> >;
	virtual auto resetStretch( const HfSegmentHO<Txi,Txf>& stretch2 ) -> HfSegmentHO<Txi,Txf>;
	virtual auto getSegment()const -> HfSegmentHO<Txi,Txf>;
	virtual auto getStretch()const -> HfSegmentHO<Txi,Txf>;
	virtual bool isSegmentCompletelyInside()const;
	virtual auto resizeSegmentAtOriginOrAtEdge( Txi len2, Txi orig2 ) -> std::vector<HfSegmentHO<Txi,Txf> >;
private:
	void clipAgainstStretch( std::vector<HfSegmentHO<Txi,Txf> >& inp )const;
private:
	HfSegmentHO<Txi,Txf> Strch, Seg;
}; // HfEnclosure

template<class Txi, class Txf>
struct HfScaledEnclosure : HfEnclosure<Txi,Txf>
{
	;            HfScaledEnclosure( Txi posStrch, Txi lenStrch, Txi posSeg, Txi lenSeg );
	virtual auto getPortionOfSegmentUnscaled()const -> HfSegmentHO<Txi,Txf>;
private:
	HfSegmentHO<Txi,Txf> OrigSeg;
};

} // end namespace hef
#endif //_HEF_FLAT_GEOM_H_
