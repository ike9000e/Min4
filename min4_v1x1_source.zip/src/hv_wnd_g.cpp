#include "hv_wnd_g.h"
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>
//#include <X11/Xlib.h>
#include <X11/Xutil.h>   //XK_Escape
#include "hef/hef_data.h"
#include "hef/hef_str_args.h"
#include "hef/hef_file.h"
#include "hv_util.h"
using namespace hef;

HvGnuWnd::HvGnuWnd()
{
	assert( !Dpy );
	if( !(Dpy = XOpenDisplay( 0 )) ){
		//Success2.second = HfArgs("Call to XOpenDisplay() failed.").c_str();
		return;
	}
}
HvGnuWnd::~HvGnuWnd()
{
	if(Dpy){
		XCloseDisplay( Dpy );
		Dpy = 0;
	}
}
Display* HvGnuWnd::getXDisplay()
{
	return Dpy;
}
bool HvGnuWnd::itwCreateTitleWindow( const HvIWndCreate& inp )
{
//	assert( !Dpy );
//	if( !(Dpy = XOpenDisplay( 0 )) ){
//		Success2.second = HfArgs("Call to XOpenDisplay() failed.").c_str();
//		return 0;
//	}
	assert( Dpy );
	ScreenBpp = DefaultDepth( Dpy, DefaultScreen(Dpy) );
	if( ScreenBpp != 24 ){
		Success2.second = HfArgs(
				"Supported screen bits-per-pixel depth is 24 only (detected: %1).")
				.arg(ScreenBpp).c_str();
		return 0;
	}
	int cBlack, cWhite;
	const int X = inp.x, Y = inp.y, W = inp.w, H = inp.h;
	// Get white_ and black_ color
	cBlack = ( inp.clrFrgg == 0xFEFFFFFF ? BlackPixel( Dpy, DefaultScreen(Dpy) ) : inp.clrFrgg );
	cWhite = ( inp.clrBckg == 0xFEFFFFFF ? WhitePixel( Dpy, DefaultScreen(Dpy) ) : inp.clrBckg );

	Wid = XCreateSimpleWindow( Dpy, DefaultRootWindow(Dpy),
							X, Y, W, H,
							0, cWhite, cWhite );
	XSelectInput( Dpy, Wid, ExposureMask | StructureNotifyMask |
						  KeyPressMask | KeyReleaseMask | PointerMotionMask |
						  ButtonPressMask | ButtonReleaseMask |
						  FocusChangeMask );

//	XMapWindow( Dpy, Wid );
	XStoreName( Dpy, Wid, ( inp.title2.empty() ? "main_window" : inp.title2.c_str() ) );

	WmDeleteWindow = XInternAtom( Dpy, "WM_DELETE_WINDOW", 1 );
	XSetWMProtocols( Dpy, Wid, &WmDeleteWindow, 1 );

	// Create a graphics context for the window
	Gcx = XCreateGC( Dpy, Wid, 0, 0 );

	XSetForeground( Dpy, Gcx, cBlack );//cBlack
	XSetBackground( Dpy, Gcx, cWhite );//cWhite

	XMapWindow( Dpy, Wid );
	XMoveResizeWindow( Dpy, Wid, X, Y, W, H );
//	XMoveWindow( Dpy, Wid, X, Y );
//	XMapWindow( Dpy, Wid );
//	XFlush( Dpy );
	return 1;
}
void HvGnuWnd::itwDestroyTitleWindow()
{
	if(Dpy){
		if(Gcx){
			XFreeGC( Dpy, Gcx );
			Gcx = 0;
		}
		if(Wid){
			XDestroyWindow( Dpy, Wid );
			Wid = 0;
		}
	}
}
int HvGnuWnd::itwExec()
{
	assert(Dpy);
	// This returns the FD of the X11 display.
	int x11_fd = XConnectionNumber( Dpy );
	fd_set in_fds[2];
	struct timeval tvv;
	XEvent evt, evt2;
/*	{
		struct SX{
			fd_set in_fds2[24];
			int v;
		} sxx;
		memset( &sxx, 0, sizeof(sxx) );
		sxx.v = 0;
		FD_SET( int(0x1D000), &sxx.in_fds2[0] );
		assert( !sxx.v );
		//assert( !sxx.in_fds2[1].fds_bits[0] );
		for( size_t k=1; k < sizeof(SX::in_fds2)/sizeof(SX::in_fds2[0]); k++ ){
			for( size_t i=0; i< sizeof(fd_set::fds_bits)/sizeof(fd_set::fds_bits[0]); i++ ){
				assert( !sxx.in_fds2[k].fds_bits[i] );
			}
		}
	}
	printf("len0: %u, len: %u\n", sizeof(in_fds[0].fds_bits[1]), sizeof(in_fds[0]) );
	//*/
	for( ; RunFlag; ){ // Event loop.
		// max const unsigned value for FD_SET() to not cause
		// '__fdelt_warn' warnings is 1023. It's propably ok to use
		// value less than 65536 if 'in_fds' is an array of 2 elements.
		assert( x11_fd < 65536 );
		FD_ZERO( &in_fds[0] );
		FD_ZERO( &in_fds[1] );
		FD_SET( x11_fd, &in_fds[0] );
	/*	//for( size_t i=0; i<(sizeof(x11_fd)*8); i++ )
		//for( size_t i=0; i<16 && i<(sizeof(x11_fd)*8); i++ )
		const int n = (sizeof(fd_set::fds_bits) / sizeof(fd_set::fds_bits[0]));
		for( size_t i=0; i<n && i<(sizeof(x11_fd)*8); i++ ){
			bool bBitValue = x11_fd & (1<<i);
			in_fds[0].fds_bits[i] = (bBitValue ? 0b1111 : 0);
			//0xFFFFFFFFFFFFFFFF
		}//*/
		//memset( &in_fds, 0, sizeof(in_fds) );
		//const uint64_t x = 1023;

	//	// alternate method to FD_SET().
	//	in_fds[0].fds_bits[ x11_fd / (sizeof(long)*8) ] |=
	//			( ((long)1) << ( x11_fd % (sizeof(long)*8) ) );

		//int msNearest = TimeoutSrvGlob->getNearestTimeout();
		int msNearest = getTimeoutMsForSelect();
		HvSetupTimevalFromMilisecs( &tvv, (msNearest != -1 ? msNearest : 1000) );

		// Wait for X Event or a Timer.
		int num_ready_fds = select( x11_fd + 1, &in_fds[0], 0, 0, &tvv );
		if( num_ready_fds > 0 ){
			//printf("Event Received!\n");
		}else if( num_ready_fds == 0 ){
			//printf("Timer Fired!\n");
		}else{
			//printf("An error occured!\n");
		}
		// Handle XEvents and flush the input
	//	while( XPending(Dpy) ){
	//		XNextEvent( Dpy, &evt );
	//		perform3( evt, RunFlag );
	//	}
		while( XPending(Dpy) ){
			XNextEvent( Dpy, &evt );
			{
				// Possible uncluttering of mouse motion events by looking
				// at the current message queue for the other mouse motion events
				// and processing only one of them, newest one, discarding all the others.
				// Later, similiar is done for the mouse wheel, buttons 4 and 5.
				if( Flags2 & HV_GWUF_MotionNotifyDeClutter && evt.type == MotionNotify ){ // PointerMotionMask
					uint32_t tm2 = evt.xmotion.time;
					for(; XCheckMaskEvent( Dpy, PointerMotionMask|0, &evt2 ); ){
						if( tm2 < evt2.xmotion.time )
							evt = evt2;
					}
				}
				// ButtonPress,ButtonRelease -> ButtonPressMask|ButtonReleaseMask
				if( Flags2 & HV_GWUF_MouseWheelDeClutter && evt.type == ButtonPress ){
					std::vector<XEvent> evtsOk;
					uint32_t tm2 = evt.xbutton.time;
					for(; XCheckMaskEvent( Dpy, ButtonPressMask|0, &evt2 ); ){
						// xbb.button: 1=LMB, 2=MMB, 3=RMB, 4=WheelF, 5=WheelB
						if( strchr("\4\5", evt2.xbutton.button ) ){
							if( tm2 < evt2.xbutton.time )
								evt = evt2;
						}else
							evtsOk.push_back( evt2 );
					}
					for( auto& a : evtsOk )
						XPutBackEvent( Dpy, &a );
				}
			}
			perform3( evt, RunFlag );
		}
		postEventPerform();
	}
	return 0;
}


void HvGnuWnd::perform3( XEvent& evt, bool& RunFlag )
{
	switch( evt.type ){
	case ClientMessage:
		if( evt.xclient.data.l[0] == static_cast<long>(WmDeleteWindow) ){
			RunFlag = 0;
			itwQuitNotify();
		}
		break;
	case KeyPress: {
			//const XKeyEvent& kevt = reinterpret_cast<XKeyEvent&>(evt);
			int ksm = XLookupKeysym( &evt.xkey, 0 );
			HvIWndUserInput sui;
			sui.bKeyDown = 1;
			sui.nKeysym = ksm;
			itwOnUserInput( sui );
		}
		break;
	case ButtonRelease:
	case ButtonPress: {
			const XButtonEvent& xbb = evt.xbutton;
			//xbb.button: 1=LMB, 2=MMB, 3=RMB, 4=WheelF, 5=WheelB
			HvIWndUserInput sui;
			sui.bMouseDown   = (xbb.type == ButtonPress);
			sui.bMouseUp     = (xbb.type == ButtonRelease);
			sui.nMouseButton = xbb.button;
			sui.xyMouse[0]   = xbb.x;
			sui.xyMouse[1]   = xbb.y;
			itwOnUserInput( sui );
		}
		break;
	case MotionNotify:{ //PointerMotionMask
			const XMotionEvent& xme = evt.xmotion;
			HvIWndUserInput smi;
			smi.bMouseMotion = 1;
			smi.xyMouse[0] = xme.x;
			smi.xyMouse[1] = xme.y;
			itwOnUserInput( smi );
		}
		break;
	case ConfigureNotify:{ // notify: resize, pos, etc., StructureNotifyMask
			const XConfigureEvent& xce = evt.xconfigure;
			//printf("ConfigureNotify, wh:%d,%d \n", xce.width, xce.height );
			assert( Wid == xce.window );
			//int siz = FrameBorderSize;
			//SubRect = { siz, siz, xce.width-siz*2, xce.height-siz*2, };
			//Imt3.setFrame( SubRect );
			//Imt3.setScaleOrigin2( HV_ESSO_Centered );
			//HfRct rcx = { 0, 0, xce.width, xce.height, };
			//repaintWindowAt( rcx );
			HvIWndNewGeometry sng;
			sng.w = xce.width;
			sng.h = xce.height;
			itwOnNewGeometry( sng );
		}
		break;
	case Expose: { //case MapNotify:
			assert( Wid == evt.xexpose.window );
			const XExposeEvent& xee = evt.xexpose;
			if( !xee.count ){
				//int ww, wh;
				//xehi_GetWindowWHXY( Dpy, Wid, &ww, &wh );
				//printf("rc:%d,%d,%d,%d, wnd:[%d,%d] %d\n",
				//	xee.x,xee.y,xee.width,xee.height, ww, wh, static_cast<uint16_t>(hf_getTimeTicksMs()) );
				//HfRct rc = { xee.x, xee.y, xee.width, xee.height, };
				//repaintWindowAt( rc );
				HvIWndRectRepaint srr;// = { xee.x, xee.y, xee.width, xee.height, };
				//srr.rect = { xee.x, xee.y, xee.width, xee.height, };
				srr = { xee.x, xee.y, xee.width, xee.height, };
				itwOnRectRepaint( srr );
			}
		}
		break;
	}
}
void HvGnuWnd::itwCloseTitleWindow()
{
	RunFlag = 0;
}
HvIWndId HvGnuWnd::itwGetTitleWindowInfo()
{
	HvIWndId ouu;
	ouu.dpy2 = HvToDpy3( Dpy );//reinterpret_cast<HvDpy*>(Dpy);
	ouu.wid2 = Wid;
	ouu.gcx2 = HvToGcx3( Gcx );
	return ouu;
}
void HvGnuWnd::itwFlush()
{
	XFlush( Dpy );
}
void HvGnuWnd::itwClearArea( int x, int y, int w, int h, int flags_ )
{
	XClearArea( Dpy, Wid, x,y,w,h, 0 );
}
/// Sets or retrieves flags this class provides, X11 functionalty related.
/// \param flags2 - flags, eg. \ref HV_GWUF_MotionNotifyDeClutter.
//int HvGnuWnd::ioXUtilFlags( bool bSet, int flags2 )
int HvGnuWnd::ioXUtilFlags( std::pair<bool,int> flags2 )
{
	if(flags2.first)
		Flags2 = flags2.second;
	return Flags2;
}

Display* HvToDpy2( HvDpy* inp )
{
	return reinterpret_cast<Display*>(inp);
}
HvDpy* HvToDpy3( Display* inp )
{
	return reinterpret_cast<HvDpy*>(inp);
}
GC HvToGcx2( HvGC inp )
{
	return reinterpret_cast<GC>(inp);
}
HvGC HvToGcx3( GC inp )
{
	return reinterpret_cast<HvGC>(inp);
}
