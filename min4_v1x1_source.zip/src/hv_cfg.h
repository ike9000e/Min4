
#ifndef _HV_CFG_H_
#define _HV_CFG_H_
#include <vector>
#include <string>
#include "hv_wnd_i.h"

enum{
	/// Action names in the program.
//	HV_ACTT_AnyAction = -1,
	HV_ACTT_Quit = 1,
	HV_ACTT_LoadNext,
	HV_ACTT_LoadPrev,
	HV_ACTT_LoadNextR,
	HV_ACTT_LoadPrevR,
	HV_ACTT_LoadFirst,
	HV_ACTT_LoadLast,
	HV_ACTT_CenterInFrame,
	HV_ACTT_FitInFrame,
	HV_ACTT_CenterOrFitInFrame,
	HV_ACTT_ZoomInStep,
	HV_ACTT_ZoomOutStep,
	HV_ACTT_Repaint,
	HV_ACTT_ZoomReset,
	HV_ACTT_MousePanButton,
	HV_ACTT_MoveLeft,
	HV_ACTT_MoveRight,
	HV_ACTT_MoveDown,
	HV_ACTT_MoveUp,
};
struct HvKeyBind{
//	std::vector<KeySym> keysyms3;
	KeySym              keysym2 = 0; ///< eg. NoSymbol
	int                 eActionTy = 0;    ///< fe. \ref HV_ACTT_Quit.
	std::string         ssOrigKeyName;
	bool                bDfltBind = 0, bKbdKey = 0, bMouseButton = 0;
//	int                 nMouseButton3 = 0;  ///< LMB=1, MMB=2, RMB=3, WheelForward=4, WheelBack=5
//	int                 nModKeys = 0;
};
/// Enums used by HvOpts and HvWnd.
enum{ HV_EMOIL_FitCentered = 1, HV_EMOIL_CenteredOrFit, HV_EMOIL_CenteredUnsc, HV_EMOIL_UpperLeft, };
/// Enums used by HvOpts and HvWnd.
enum{ HV_ESFM_Unsorted = 1, HV_ESFM_Alpha, HV_ESFM_NatSort, };

/// Type for \ref HvOpts::eMaximize2.
enum{ HV_EMEN_LeftEdge = 1, HV_EMEN_RightEdge, HV_EMEN_TopEdge, HV_EMEN_BottomEdge, };

/// Options for the program. Used by HvWnd class.
/// Use fromArgv() to initialize from command line.
struct HvOpts {
	virtual ~HvOpts() {}
	// xxxx//0xC0C0C0//x //0xDEB887//xx //0x8FBC8B//xx //0xADD8E6//xx //0xB0E0E6//x //0xD8BFD8//x //0xF5DEB3
	unsigned long clrFrgg = 0xFEFFFFFF, clrBckg = 0xB0C4DE, clrBckgFs = 0;
	bool          bLDD = 0, bHelp = 0, bShowActions = 0, bShowBinds = 1;
	bool          bNoDefaultBinds = 0;
	int           eMetricsOnLoad = HV_EMOIL_CenteredOrFit;//--initial_metrics fit|center2|...
	bool          bAutoPosChgRedraw = 1; // if auto redraaw image on pos change, fe. mouse dragging or with keyboard arrows.
	uint32_t      msDtRedrawTimeout = 200;//--
	bool          bFirstAutoLoad = 1; //--
	double        ZoomStep = 1.17; //--zoom_step 1.1
	bool          bDontRotate = 0;//-- // do not go to first or last when reached end or begin, respectivelly.
	std::string   FilelistFilename; //--filelist FILE
	std::string   FileStartAt; //--start_at FILE
	std::string   FileAndDirItems; //--file_in_dir FILE
	int           eSortFilelistMode = HV_ESFM_Alpha;//HV_ESFM_Unsorted; //--sort_mode alpha|natsort|none
	std::string   PidFilename; //--pidfile FILE
	std::vector<std::string> LooseFiles;
	//int         eZoomOriginMode;
	//--window_centered 1
	//--randomize - Randomize the filelist
	//--scroll-step COUNT   scroll COUNT pixels when movement key is pressed
	//--frame_padding NUM
	//--bg_color #RRGGBB
	//--alt_bg_color #RRGGBB,#RRGGBB,...
	bool bMaximize = 0; //--wmax
	/// Type can be eg. \ref HV_EMEN_BottomEdge.
	/// Format: --wmax2 FLOAT/E, where E being the screen edge: L|R|T|B.
	std::pair<float,int>               eMaximize2 = {0.f,0,};
	bool                               bShowDbg = 0, bUseDbgFrame = 0;  //--bShowDbg
	std::pair<std::string,HfRct>       Geometry2 = {"",{-5229341,-5229341,0,0,},};   //--geometry WxH[+X+Y], --g
	std::pair<std::string,std::string> PrioChars = {"","",};  //--high_prio --low_prio
	std::vector<HvKeyBind>             Binds2;
	static const std::pair<int,const char*> ActionNamesApp[]; // prefix is "HV_ACTT_". Eg. "HV_ACTT_Quit".
	int                                nMoveByKeyAmount = 16;
	//--config_file
	//
	void        fromArgv( int argc, const char*const* argv, Display* dpy );
	static auto getAllActionNames() -> std::string;
	auto        getAllBinds()const -> std::string;
	bool        testKey( int eActionTy_, int nKeySym_ )const;
	bool        testMouseButton( int eActionTy, int nMouseButton2 )const;
private:
	static int  lookupActionTypeByName( const std::string ssActName );
	static auto lookupActionNameByType( int nActType3 ) -> std::string;
	void        addDefaultBinds( Display* dpy );
	bool        parseBind( const char* szBindCmdArg, std::string* err2, Display* dpy, bool bIsDfltBind );
	static auto unquoteStrIf( std::string inp, const char* szTrimFirst, const char* szTrimLater ) -> std::string;
};

#endif // _HV_CFG_H_
