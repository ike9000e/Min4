#ifndef _HV_WND_G_H_
#define _HV_WND_G_H_
#include <string>
#include <vector>
#include <X11/Xlib.h>
#include "hv_wnd_i.h"

enum{
	HV_GWUF_MotionNotifyDeClutter = 0x1,
	HV_GWUF_MouseWheelDeClutter = 0x2,
};
struct HvGnuWnd : public HvIWnd
{
	;            HvGnuWnd();
	virtual      ~HvGnuWnd();
	virtual bool itwCreateTitleWindow( const HvIWndCreate& inp );
	virtual void itwDestroyTitleWindow();
	virtual int  itwExec();
	virtual void itwQuitNotify() {}
	virtual void itwOnUserInput( const HvIWndUserInput& inp ) {}
	virtual void itwOnRectRepaint( const HvIWndRectRepaint& inp ) {}
	virtual void itwOnNewGeometry( const HvIWndNewGeometry& inp ) {}
	virtual auto getXDisplay() -> Display*;
	virtual int  ioXUtilFlags( std::pair<bool,int> flags2 = {0,0,} );
	//
	virtual void postEventPerform() {}
	virtual int  getTimeoutMsForSelect() {return -1;}
	void         itwCloseTitleWindow() final;
	HvIWndId     itwGetTitleWindowInfo() final;
	void         itwFlush() final;
	void         itwClearArea( int x, int y, int w, int h, int flags_ ) final;
private:
	void perform3( XEvent& evt, bool& bRun );
private:
	std::pair<bool,std::string>    Success2 = {0,"",};
	Display*                       Dpy = 0; //HvDpy*
	HvWid                          Wid = 0; //Window
	GC                             Gcx = 0; //HvGC
	int                            ScreenBpp = 0, Flags2 = 0; //eg. HV_GWUF_MotionNotifyDeClutter.
	Atom                           WmDeleteWindow;
	bool                           RunFlag = 1;
}; // HvGnuWnd

#endif //_HV_WND_G_H_
