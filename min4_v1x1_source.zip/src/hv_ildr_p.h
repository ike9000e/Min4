
#ifndef _HV_ILDR_P_H_INCLUDED_
#define _HV_ILDR_P_H_INCLUDED_
#include "hv_ildr.h"

void HvPNGReadPngVersionInfo();

bool HvPNGReadFileIntrnl( const char* szFilename,
			std::function<bool(const HvImageReadInfo&)> calbEachScanline );

template<class T> bool
HvPNGReadFile( const char* szFilename, T calbEachScanline2 )
{
	return HvPNGReadFileIntrnl( szFilename, calbEachScanline2 );
}

#endif //_HV_ILDR_P_H_INCLUDED_
