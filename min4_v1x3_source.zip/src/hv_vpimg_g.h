#ifndef _HV_VPIMG_G_H_
#define _HV_VPIMG_G_H_
#include <string>
#include <vector>
#include <X11/Xlib.h>
#include "hv_util.h"
#include "hv_wnd_i.h"

bool HvLoadImageFromFile( const char* szFilename, std::vector<unsigned long>& outp );

struct HvX11Pixmap : public HvImage
{
	virtual bool            drawImageWithin( HvWid wid, const HfRct& updatearea, HvGC gcx, const HfPt& xy ) override;
	;       bool            reloadPixmap2( HvDpy* dpy, HvWid wid, HvGC gcx ) override;
//	virtual bool            isValid()const {return !!pxm;}
	virtual void            freePixmapIfAny();
	virtual uint32_t        ioBackgroundColor( bool bSet = 0, uint32_t clr = 0 );
protected:
	enum{ HV_EPXMSM_Orig = 0, HV_EPXMSM_UseZoom, };
	virtual int             ipmGetDrawMode()const = 0; //fe. HV_EPXMSM_Orig.
	virtual HvDpy*          ipmDisplay() = 0;
	virtual void            ipmDisplay( HvDpy* inp ) = 0;
	virtual const HfDim&    ipmGetDim()const = 0;
	virtual const HfDim&    ipmGetDim1x()const = 0;
	virtual const uint32_t* ipmGetPixels()const = 0;
	virtual const uint32_t* ipmGetPixels1x()const = 0;

	int ipmGetFirstAlphaPixel()const;
private:
	Pixmap Pxm = 0;
	uint32_t BkgColor = 0xFF000000;   //eg. 0xFFB0C4DE
};

///	Image inside viewport with scalling and cropping.
struct HvX11Image : public HvX11Pixmap
{
	virtual         ~HvX11Image();
	virtual bool    loadImage2( const char* filename )override;
	virtual void    clearImageIfAny2()override;
	virtual const HfDim& dimWH()const override {return ipmGetDim();}
	virtual const HfDim& dimWH1x()const override {return ipmGetDim1x();}
//	virtual bool    rescaleTo( float fScale2, HvWid wid, HvGC gcx );
	virtual bool    rescaleTo2( HvWid wid, HvGC gcx, const HfRct& clipAreaSel, const HfDim& whRescaleTo ) override;
	virtual bool    rescaleTo3( HvWid wid, HvGC gcx, float fInitialZoom, const HfRct& region2, const HfDim& whRescaleTo, int, uint32_t dfltPixel ) override;
//	virtual bool    rescaleTo4( const HfDim& newdim, HvWid wid, HvGC gcx );
//	virtual bool    rescaleTo5( const HfPt& pos2, float fZoom, const HfDim& frameDim, int flags2, HvWid wid, HvGC gcx );
protected:
	virtual int             ipmGetDrawMode()const override {return ZoomMode2;}
	virtual HvDpy*          ipmDisplay()override {return Dpy;}
	virtual void            ipmDisplay( HvDpy* inp )override {Dpy = inp;}
	virtual const HfDim&    ipmGetDim()const override {return Dim;}
	virtual const HfDim&    ipmGetDim1x()const override {return Dim1x;}
	virtual const uint32_t* ipmGetPixels()const override {return &Pixels2[0];}
	virtual const uint32_t* ipmGetPixels1x()const override {return &Pixels1x[0];}
private:
	void rescaleTo3_ToSmaler( float fInitialZoom, const HfRct& rect2, const HfDim& rescaleToWH, uint32_t dfltPixel );
	void rescaleTo3_ToLarger( float fInitialZoom, const HfRct& rect2, const HfDim& rescaleToWH, uint32_t dfltPixel );
protected:
	HvDpy*                Dpy = 0;
	std::vector<uint32_t> Pixels1x, Pixels2;
	int                   ZoomMode2 = HV_EPXMSM_Orig;
	HfDim                 Dim1x = {0,0,}; //unscalled dimension, fe. original loaded from file.
	HfDim                 Dim = {0,0,};
}; // HvX11Image

struct HvImlibImage : HvX11Image
{
	virtual                 ~HvImlibImage();
	virtual void            setOmniImageLoader( HvOmniLdr* inp ) { OmniLdr = inp; }
	// intrf. HvX11Image
	virtual bool            loadImage2( const char* filename )override;
	virtual bool            rescaleTo2( HvWid wid, HvGC gcx, const HfRct& clipAreaSel, const HfDim& whRescaleTo ) override;
	virtual void            clearImageIfAny2()override;
	virtual const uint32_t* ipmGetPixels()const override;
	virtual const uint32_t* ipmGetPixels1x()const override;
private:
	void clearImlibImageIfAny();
	void clearImlibImage1xIfAny();
	//static int calbImlib2Progr( void* im, char percent2, int update_x, int update_y, int update_w, int update_h );
private:
	void* ImgImlib = 0;   //Imlib_Image, void*
	void* ImgImlib1x = 0;
	bool HasAlphaPixels = 1;
	HvOmniLdr* OmniLdr = 0;
};

#endif //_HV_VPIMG_G_H_
