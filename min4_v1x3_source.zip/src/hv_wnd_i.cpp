#include "hv_wnd_i.h"

HvQueryImageMode* HvImage::ioQueryImageModeIntrf( bool bSet, HvQueryImageMode* inp )
{
	if(bSet)
		QueryIntrf = inp;
	return QueryIntrf;
}
