
#ifndef _HV_UTIL_H_
#define _HV_UTIL_H_
#include <string>
#include <vector>
#include <algorithm>
#include "hef/hef_flat_geom.h"
#include "hef/hef_assert.h"
using namespace hef;

enum{
	/// Flags for HvImageResampleBox().
	HV_RBF_SkipAlpha = 0x1,
};
enum{
	HV_SCWP_CaseSensitive = 0x1,
};

/// Natural sorting token struct for numeric aware comparision.
/// \sa HvTokenizeStringToNumericAware() and HvNumericAwareTokensCompare().
struct HvNatSortToken {
	char     first;
	uint32_t second;
	size_t   strLen2;
	HvNatSortToken( char chr_, uint32_t numval_, size_t clen_ ) : first(chr_), second(numval_), strLen2(clen_) {}
};
/// Natural sorting tokens for numeric aware comparision.
/// \sa HvTokenizeStringToNumericAware() and HvNumericAwareTokensCompare().
using HvNatSortTokens_t = std::vector<HvNatSortToken>;

bool HvImageResampleOption( const std::vector<uint32_t>& pxs2, int width2, int height2, std::vector<uint32_t>& pxs3, int width3, int height3, int flags2, const bool* );
bool HvImageResampleBox( const std::vector<uint32_t>& pxs2, int width2, int height2, std::vector<uint32_t>& pxs3, int width3, int height3, int flags2, const bool* );
bool HvImageResampleImlib2( const std::vector<uint32_t>& pixels2, int width2, int height2, std::vector<uint32_t>& pixels3, int width3, int height3, int flags2__, const bool* bRunSemaphore__ );
void HvGetSharedLibraries( std::vector<std::string>& outp );
bool HvCreateThread( std::function<void(void*)> calb2, void* param2, pthread_t* thread3 );
void HvSetupTimevalFromMilisecs( struct timeval* inp, int nMilisconds );

/// Creates new thread.
/// NOTE: Remember to not capture by reference, only by copy.
template<class T>
bool HvCreateThread2( T calb3, void* param2, pthread_t* thread3 )
{
	return HvCreateThread( calb3, param2, thread3 );
}
auto HvBoxToClippedAtPosZoomFrame( const HfDim& inp, const HfPt& pos2, float fZoom, const HfRct& frame2 ) -> std::pair<HfTRct<int>,HfTDim<int> >;
auto HvGetBoxOffsetForULOnPreScale( const HfRct& imgRect, const HfPt& posCursor, float fOldScale, float fNewScale, int flags3 ) -> std::pair<int,int>;
auto HvTokenizeStringToNumericAware( const char* inp ) -> HvNatSortTokens_t;
int  HvNumericAwareTokensCompare( const HvNatSortTokens_t& a, const HvNatSortTokens_t& b );
void HvTestNatSertToeknsCompare();
auto HvStrReplace( std::string str, const std::string& oldStr, const std::string& newStr ) -> std::string;
int  HvStrCmpWithPrio( const char* a, const char* b, const char* sHighPrio, const char* sLowPrio, int flags3 );

/// Used by HvComposedBox3 class member functions, eg. HvComposedBox3::resetScale().
struct HvBoxDirtyOut{
	std::vector<HfRct> dirty3;
	//
	auto appendFromOther( const HvBoxDirtyOut& otherr ) -> HvBoxDirtyOut&;
};

/// See HvComposedBox3::getCurrentComposition().
struct HvBoxCurrentOut{
	/// area, the rectangle, inside the image that is to be scalled to
	/// the dimension specified by 'displayDim' member.
	HfRct imageCropRect;
	/// display dimension the cropped image is to be rescaled to.
	HfDim displayDim;
	/// origin at which to show the image in the window. upper left coordinates.
	HfPt  composedOrigin;
};

/// Composition of rectangle inside frame.
/// Both represented as rectangle with x,y,w and h members.
struct HvComposedBox3
{
	;             HvComposedBox3( const HfRct& frame2, const HfRct& rect2 );
	void          setScaleOrigin3( const HfPt& inp );
	HvBoxDirtyOut resetScale( double inp );
	void          setFrame2( const HfRct& frame2 );
	HvBoxDirtyOut resetRectPosition( const HfPt& inp );
	auto          getCurrentComposition()const -> HvBoxCurrentOut;
	HvBoxDirtyOut addPositionDelta2( const HfPt& inp );
	bool          isRectCompletelyInside()const;
	HvBoxDirtyOut centerInFrame2();
	auto          getFrameFitMetrics()const -> std::pair<double,HfPt>;
	HfDim         getOriginalRectDimensions()const;
private:
	static HfRct  rectFrom2xSegment( const HfSegmentHO<int,double>& a, const HfSegmentHO<int,double>& b );
private:
	HfScaledEnclosure<int,double> EnclX, EnclY;
	HfPt                          ScaOrig;   //scale origin.
	HfDim                         OrigRectDim;   //original rect|segment dimensions.
};


#endif //_HV_UTIL_H_
