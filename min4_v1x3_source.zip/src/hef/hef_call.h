#ifndef HEF_CALL_H_INCLUDED
#define HEF_CALL_H_INCLUDED
#include <functional>
#include <assert.h>
#include <string.h>

namespace hef{

/**
	\file
	File holding helper routines for performing
	calls with user types using lambdas.
	Two main functions for user code are:
	HfCallWithType() and HfCallWithTypeUnwrap().

*/

static_assert(__cplusplus >= 201103L, "Std must be C++11. Compiler switch: '-std=c++11'." );

/// Internal parameters, used by HfCallWithType() and HfCallWithTypeUnwrap().
template<class T1,class T2>
struct HfCallWithTypeParams{
	T1 a;
	T2 b;
	int flags2, d, cnt = 0;
};
/// Intended for use with HfCallWithType().
template<class T, class U>
size_t HfCallWithTypeUnwrap( void* ptrInternal, U user2 )
{
	using fnc3_t = std::function<size_t(T,U)>;
	auto cpl = (HfCallWithTypeParams<fnc3_t,T>*) ptrInternal;
	if( 600594824 != cpl->d ){
		assert(!"[zjytqber2]");
	}
	cpl->cnt++;
	size_t rv2 = cpl->a( cpl->b, user2 );
	if( cpl->flags2 & 0x1 ){
		assert( cpl->cnt == 1 );
		cpl->d = 0;
		delete cpl;
	}
	return rv2;
}
/**
	Template global function that makes possible to make inline call to
	lambda with local types from any C style callback that takes only
	user pointer ('void*') as its only available user-data parameter.
	Must be used toogether with call to another global, HfCallWithTypeUnwrap().
	Template parameters 'T' and 'U' are used as user parameters.
	First, 'T', is available on HfCallWithType() call,
	and second, 'U', available on HfCallWithTypeUnwrap() call.

	\param calb2 - initial callback.
	\param calb3 - final callback.
	\param userr - first user param.
	\param szFlags - flags c-string.
					'r': indicates two things: (1) remote cleanup and (2)
					     that final callback can be called only one time.
					     For use with calls from the remote thread.
					     If calls are to be done in the same thread, this falg
					     should not be set.
	\n
	Example 1:
	\code
		HfCallWithType< float, int >(
			[]( void* ptrInternal2 ){
				Fl::awake( ( []( void* ptrInternal2 ){
					HfCallWithTypeUnwrap< float, int >( ptrInternal2, -3 );
				}), ptrInternal2 );
			},
			[&]( float rv3, int ){
				localScanDone( rv3 );
				return 1;
		}, 2.2f, "" );
	\endcode
*/
template<class T, class U> void
HfCallWithType( std::function<void(void* i)> calb2, std::function<size_t(T,U)> calb3, T userr, const char* szFlags )
{
	using fnc3_t = std::function<size_t(T,U)>;
	auto cpl = new HfCallWithTypeParams<fnc3_t, T>;
	cpl->a      = calb3;
	cpl->b      = userr;
	cpl->flags2 = ( szFlags ? ( strchr( szFlags,'r') ? 0x1 : 0 ) : 0 );
	cpl->d      = 600594824;  //for malformed data check, immediate random value.
	calb2( cpl );
	if( !(cpl->flags2 & 0x1) )
		delete cpl;
}

} // end namespace hef

#endif // HEF_CALL_H_INCLUDED
