#include "hef_flat_geom.h"
#include <algorithm>
#include <assert.h>
namespace hef{


/// Retrieves clipping information for: b,c,e,d,e and f.
/// See: "rects_6part_clip_hfzjfue.png".
template<class Tvv>
HfTDim<Tvv> HfTRct<Tvv>::clip6PartCD( const HfTRct<Tvv>& rectB )const
{
	HfTDim<Tvv> outp;
	outp.w = rectB.x - x;
	outp.h = rectB.y - y;
	return outp;
}
/// see HfTRct<Tvv>::clip6PartCD()
template<class Tvv>
HfTDim<Tvv> HfTRct<Tvv>::clip6PartEF( const HfTRct<Tvv>& rectB )const
{
	HfTDim<Tvv> outp;
	outp.w = rectB.r() - r();
	outp.h = rectB.b() - b();
	return outp;
}
/// see HfTRct<Tvv>::clip6PartCD()
template<class Tvv>
HfTDim<Tvv> HfTRct<Tvv>::clip6PartGH( const HfTRct<Tvv>& rectB )const
{
	HfTRct<Tvv> rc2 = getClipped( rectB );
	return {rc2.w, rc2.h,};
}
template<class Tvx>
std::string HfTDim<Tvx>::sprintfAny( float a )
{
	char bfr[64];
	sprintf( bfr, "%f", a );
	return bfr;
}
template<class Tvx>
std::string HfTDim<Tvx>::sprintfAny( int a )
{
	char bfr[64];
	sprintf( bfr, "%d", a );
	return bfr;
}
template<class Tvx>
std::string HfTDim<Tvx>::sprintfAny( double a )
{
	return sprintfAny( static_cast<float>(a) );
}
//*/
template<class Tvx>
std::string HfTDim<Tvx>::toStr()const
{
	char bfr[128];
	//sprintf( bfr, "%d,%d", w, h );
	sprintf( bfr, "%s,%s", sprintfAny(w).c_str(), sprintfAny(h).c_str() );
	return bfr;
}
template<class Tvx>
HfTDim<Tvx> HfTDim<Tvx>::operator*( float inp )const
{
	HfTDim<Tvx> o(*this);
	o.w *= inp;
	o.h *= inp;
	return o;
}
template<class Tvx>
HfTDim<Tvx> HfTDim<Tvx>::operator/( float inp )const
{
	HfTDim<Tvx> o(*this);
	o.w /= inp;
	o.h /= inp;
	return o;
}
template<class Tvx>
HfTDim<Tvx>& HfTDim<Tvx>::fromStdPair( const std::pair<Tvx,Tvx>& inp )
{
	w = inp.first;
	h = inp.second;
	return *this;
}
template<class Tvx>
bool HfTDim<Tvx>::isPointInside( const HfTPt<Tvx>& p )const
{
	return( p.x >= 0 && p.x < w && p.y >= 0 && p.y < h );
}
template<class Tvx>
bool HfTDim<Tvx>::operator==( const HfTDim<Tvx>& o )const
{
	return (w == o.w && h == o.h);
}
template<class Tvx>
bool HfTDim<Tvx>::operator!=( const HfTDim<Tvx>& o )const
{
	return (w != o.w || h != o.h);
}
template<class Tvx>
HfTDim<int> HfTDim<Tvx>::toIntDimRounded()const
{
	return { int(llround(w)), int(llround(h)), };
}

template<class Tvv>
std::string HfTRct<Tvv>::toStr()const
{
	char bfr[128];
	sprintf( bfr, "%s,%s,%s,%s",
		HfTDim<Tvv>::sprintfAny(x).c_str(),
		HfTDim<Tvv>::sprintfAny(y).c_str(),
		HfTDim<Tvv>::sprintfAny(w).c_str(),
		HfTDim<Tvv>::sprintfAny(h).c_str() );
	return bfr;
}
template<class Tvv>
bool HfTRct<Tvv>::isEmpty2()const
{
	return isEmpty() || x >= x+w || y >= y+h;
}

/// Clips this rectangle with another one (const).
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::getClipped( const HfTRct<Tvv>& inp )const
{
	HfTRct<Tvv> r = *this;
	r.clipAgainst( inp );
	return r;
}
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::getClippedInv( const HfTRct<Tvv>& inp )const
{
	HfTRct<Tvv> r = getClipped( inp );
	r.x -= inp.x;
	r.y -= inp.y;
	return r;
}
/// Clips this rectangle with another one (non-const).
/// ref: Irrlicht engine "irr::core::rect<T>::clipAgainst()".
template<class Tvv>
HfTRct<Tvv>& HfTRct<Tvv>::clipAgainst( const HfTRct<Tvv>& inp )
{
	HfTPt<Tvv> UpperLeftCorner            = { x, y, };
	HfTPt<Tvv> LowerRightCorner           = { x + w, y + h, };
	const HfTPt<Tvv> inp_UpperLeftCorner  = { inp.x, inp.y, };
	const HfTPt<Tvv> inp_LowerRightCorner = { inp.x + inp.w, inp.y + inp.h, };

	if (inp_LowerRightCorner.x < LowerRightCorner.x)
		LowerRightCorner.x = inp_LowerRightCorner.x;
	if (inp_LowerRightCorner.y < LowerRightCorner.y)
		LowerRightCorner.y = inp_LowerRightCorner.y;

	if (inp_UpperLeftCorner.x > UpperLeftCorner.x)
		UpperLeftCorner.x = inp_UpperLeftCorner.x;
	if (inp_UpperLeftCorner.y > UpperLeftCorner.y)
		UpperLeftCorner.y = inp_UpperLeftCorner.y;

	// correct possible invalid rect resulting from clipping
	if (UpperLeftCorner.y > LowerRightCorner.y)
		UpperLeftCorner.y = LowerRightCorner.y;
	if (UpperLeftCorner.x > LowerRightCorner.x)
		UpperLeftCorner.x = LowerRightCorner.x;
	//
	x = UpperLeftCorner.x;
	y = UpperLeftCorner.y;
	w = LowerRightCorner.x - UpperLeftCorner.x;
	h = LowerRightCorner.y - UpperLeftCorner.y;
	return *this;
}

/// Moves this rectangle to fit inside another one.
/// Returns true on success, false if not possible.
/// ref: Irrlicht engine "irr::core::rect<T>::constrainTo()".
template<class Tvv>
bool HfTRct<Tvv>::constrainTo( const HfTRct<Tvv>& inp )
{
	HfTPt<Tvv> UpperLeftCorner            = { x, y, };
	HfTPt<Tvv> LowerRightCorner           = { x + w, y + h, };
	const HfTPt<Tvv> inp_UpperLeftCorner  = { inp.x, inp.y, };
	const HfTPt<Tvv> inp_LowerRightCorner = { inp.x + inp.w, inp.y + inp.h, };

	if (inp.w < w || inp.h < h )
	   return 0;

	int diff = inp_LowerRightCorner.x - LowerRightCorner.x;
	if (diff < 0)
	{
	   LowerRightCorner.x += diff;
	   UpperLeftCorner.x  += diff;
	}

	diff = inp_LowerRightCorner.y - LowerRightCorner.y;
	if (diff < 0)
	{
	   LowerRightCorner.y += diff;
	   UpperLeftCorner.y  += diff;
	}

	diff = UpperLeftCorner.x - inp_UpperLeftCorner.x;
	if (diff < 0)
	{
	   UpperLeftCorner.x  -= diff;
	   LowerRightCorner.x -= diff;
	}
	diff = UpperLeftCorner.y - inp_UpperLeftCorner.y;
	if (diff < 0)
	{
	   UpperLeftCorner.y  -= diff;
	   LowerRightCorner.y -= diff;
	}
	x = UpperLeftCorner.x;
	y = UpperLeftCorner.y;
	w = LowerRightCorner.x - UpperLeftCorner.x;
	h = LowerRightCorner.y - UpperLeftCorner.y;
	return 1;
}
/// Filters this rectangle inside the viewport rectangle.
/// Returns new rectangle, that contains the portion
/// that is visible inside the viewport.
/// Purpose of this function is for calculating new rectangles for images that
/// are to be drawn inside the parent window.
/// \param vport - input viewport.
/// \param posInVP - position of the output rectangle inside the viewport.
///                  it's coordinates must be relative to viewport's 'x' and 'y'.
/// \param flags2 - flags, fe. \ref HF_FIVPF_NegativeDimensionOK.
/// \return Returned is rectangle with coordinates relative to rectangle:
///         '{ 0, 0, this->w, this->h, }'.
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::filterInViewPort( const HfTRct<Tvv>& vport, HfTPt<Tvv>* posInVP, int flags2 )const
{
//	struct LocalPoint{
//		Tvv x, y;
//	};
//	LocalPoint pt = {//HfTPt<Tvv>
//			std::max( vport.x, x ),
//			std::max( vport.y, y ), };
	HfTPt<Tvv> pt = {//HfTPt<Tvv>
			std::max( vport.x, x ),
			std::max( vport.y, y ), };
	if(posInVP){
		//x*posInVP = pt;
		posInVP->x = pt.x;
		posInVP->y = pt.y;
	}
	HfTRct<Tvv> r = {0,0,0,0,};
	if( x < vport.x ){
		Tvv dif = vport.x - x;
		r.x = dif;
		r.w = w - dif;
	}else{
		r.x = 0;
		r.w = w;
	}
	if( y < vport.y ){
		Tvv dif = vport.y - y;
		r.y = dif;
		r.h = h - dif;
	}else{
		r.y = 0;
		r.h = h;
	}
	if( pt.x + r.w > vport.x + vport.w ){
		Tvv dif = (pt.x + r.w) - (vport.x + vport.w);
		r.w -= dif;
	}
	if( pt.y + r.h > vport.y + vport.h ){
		Tvv dif = (pt.y + r.h) - (vport.y + vport.h);
		r.h -= dif;
	}
	// detect if completely outside viewport. this is indicated
	// via 'w' or 'h' negative or zero.
	if( (r.w <= 0 || r.h <= 0) && !(flags2 & HF_FIVPF_NegativeDimensionOK) )
		r.w = r.h = 0;
	return r;
}


template<class Tvv>
bool HfTRct<Tvv>::operator==( const HfTRct<Tvv>& oth )const
{
	return x == oth.x && y == oth.y && w == oth.w && h == oth.h;
}
template<class Tvv>
bool HfTRct<Tvv>::operator!=( const HfTRct<Tvv>& oth )const
{
	return !(*this == oth);
}
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::operator/( float inp )const
{
	HfTRct<Tvv> o(*this);
	o.x /= inp;
	o.y /= inp;
	o.w /= inp;
	o.h /= inp;
	return o;
}
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::operator*( float inp )const
{
	HfTRct<Tvv> o(*this);
	o.x *= inp;
	o.y *= inp;
	o.w *= inp;
	o.h *= inp;
	return o;
}
template<class Tvv>
bool HfTRct<Tvv>::isPointInside( const HfTPt<Tvv>& p )const
{
	return( p.x >= x && p.x < x+w && p.y >= y && p.y < y+h );
}
template<class Tvv>
HfTRct<int> HfTRct<Tvv>::toIntRectRounded()const
{
	// others: roundf()//round()roundl()//llround()//llroundl()
	HfTRct<int> outp = {
		int(llround(x)), int(llround(y)),
		int(llround(w)), int(llround(h)), };
	return outp;
}
template<class Tvv>
HfTRct<int> HfTRct<Tvv>::toIntRect()const
{
	HfTRct<int> outp = { int(x), int(y), int(w), int(h), };
	return outp;
}

template<class Tvv>
HfTMidRct<Tvv> HfTRct<Tvv>::toMidRect()const
{
	HfTMidRct<Tvv> r( { { Tvv(x+(w*0.5)), Tvv(y+(h*0.5)),}, {w,h,},} );
	//HfTMidRct<Tvv> r({ Tvv(x+(w * 0.5)), Tvv(y+(h * 0.5)), w,h,});
	return r;
}
template<class Tvv>
HfTRct<Tvv>& HfTRct<Tvv>::fromMidRect( const HfTMidRct<Tvv>& inp )
{
	x = inp.p.x - (inp.d.w * 0.5);
	y = inp.p.y - (inp.d.h * 0.5);
	w = inp.d.w;
	h = inp.d.h;
	return *this;
}

template<class Tvv>
HfTRct<Tvv>::HfTRct( std::initializer_list<Tvv> inp )
{
	assert( inp.size() == 4 );
	x = inp.begin()[0];
	y = inp.begin()[1];
	w = inp.begin()[2];
	h = inp.begin()[3];
}
/// Retrieves rects inside bigger.
/// Returned are rects in clockwise order starting at upper left rectangle.
/// See: "rects_6part_clip_hfzjfue.png".
/// \param flags4 - flags, fe. \ref HF_RIB_KeepEmpty.
template<class Tvv>
auto HfTRct<Tvv>::
getRectsInsideBigger( const HfTRct<Tvv>& biggerr, int flags4 )const -> std::vector<HfTRct<Tvv> >
{
	const HfTRct<Tvv>& B = biggerr;
	std::vector<HfTRct<Tvv> > ouu;
	if( getClipped(B).isEmpty() )
		return ouu;
    Tvv mxx = std::max(B.x,x);
    Tvv mxy = std::max(B.y,y);
    Tvv mix = std::min(B.x,x);
    Tvv miy = std::min(B.y,y);
    Tvv mxr = std::max(B.r(),r());
    Tvv mxb = std::max(B.b(),b());
    Tvv mir = std::min(B.r(),r());
    Tvv mib = std::min(B.b(),b());
	ouu.push_back( { mix, miy, mxx-mix, mxy-miy, } ); //tl (top left rectangle)
	ouu.push_back( { mxx, miy, mir-mxx, mxy-miy, } ); //tm (top middle rectangle)
	ouu.push_back( { mir, miy, mxr-mir, mxy-miy, } ); //tr ...
	ouu.push_back( { mir, mxy, mxr-mir, mib-mxy, } ); //rm
	ouu.push_back( { mir, mib, mxr-mir, mxb-mib, } ); //br
	ouu.push_back( { mxx, mib, mir-mxx, mxb-mib, } ); //bm (bottom middle rectangle)
	ouu.push_back( { mix, mib, mxx-mix, mxb-mib, } ); //bl
	ouu.push_back( { mix, mxy, mxx-mix, mib-mxy, } ); //lm
	if( !(flags4 & HF_RIB_KeepEmpty) ){
		typename std::vector<HfTRct<Tvv> >::iterator a;
		for( a = ouu.begin(); a != ouu.end(); ){
			HfTRct<Tvv> rcx = a->getClipped( B );
			if( rcx.getDim().getArea() <= 0 ){
				a = ouu.erase(a);
			}else{
				++a;
			}
		}
	}
	if( !(flags4 & HF_RIB_DontMerge) ){
		typename std::vector<HfTRct<Tvv> >::iterator a,b,d;
		for( int k=0; k<2; k++ ){ // 2nd iteration is on reversed.
			for( a = ouu.begin(); a != ouu.end(); ){
				b = a;
				d = std::find_if( ++b, ouu.end(), [&]( const HfTRct<Tvv>& c )->bool{
						if( a->x + a->w == c.x && a->h == c.h )
							return !!( a->w = c.r() - a->x );
						else if( a->y + a->h == c.y && a->w == c.w )
							return !!( a->h = c.b() - a->y );
						return 0;
				});
				if( d != ouu.end() ){
					a = ouu.erase(d);
				}else{
					++a;
				}
			}
			// reverse for reversed order second time search.
			std::reverse( ouu.begin(), ouu.end() );
		}
	}
	return ouu;
}
template<class Tvv>
HfTRct<Tvv> HfTRct<Tvv>::getMaxExtend( const HfTRct<Tvv>& oth )const
{
	Tvv ll = std::min( x, oth.x );
	Tvv tt = std::min( y, oth.y );
	Tvv rr = std::max( r(), oth.r() );
	Tvv bb = std::max( b(), oth.b() );
	HfTRct<Tvv> ouu( { ll, tt, rr-ll, bb-tt, }  );
	return ouu;
}
template<class Tvv>
HfTRct<Tvv>& HfTRct<Tvv>::fromIntRect( const HfTRct<int>& inp )
{
	x = Tvv(inp.x);
	y = Tvv(inp.y);
	w = Tvv(inp.w);
	h = Tvv(inp.h);
	return *this;
}


template<class Tvz>
std::string HfTMidRct<Tvz>::toStr()const
{
	char bfr[128];
	sprintf( bfr, "%s,%s,%s,%s",
		HfTDim<Tvz>::sprintfAny(p.x).c_str(),
		HfTDim<Tvz>::sprintfAny(p.y).c_str(),
		HfTDim<Tvz>::sprintfAny(d.w).c_str(),
		HfTDim<Tvz>::sprintfAny(d.h).c_str() );
	return bfr;
}

template<class Tvz>
HfTMidRct<Tvz> HfTMidRct<Tvz>::operator/( float inp )const
{
	HfTMidRct<Tvz> o(*this);
	o.p.x /= inp;
	o.p.y /= inp;
	o.d.w /= inp;
	o.d.h /= inp;
	return o;
}
template<class Tvz>
HfTMidRct<Tvz> HfTMidRct<Tvz>::operator*( float inp )const
{
	HfTMidRct<Tvz> o(*this);
	o.p.x *= inp;
	o.p.y *= inp;
	o.d.w *= inp;
	o.d.h *= inp;
	return o;
}
template<class Tvz>
HfTMidRct<Tvz> HfTMidRct<Tvz>::getClipped( const HfTMidRct<Tvz>& inp )const
{
	HfTRct<Tvz> rcxy2, rcxy3;
	rcxy2.fromMidRect( *this );
	rcxy3.fromMidRect( inp );
	return rcxy2.getClipped( rcxy3 ).toMidRect();
}
template<class Tvz> //toIntRectRounded
HfTMidRct<int> HfTMidRct<Tvz>::toIntMRectRounded()const
{
	HfTMidRct<int> outp = {
		{int(llround(p.x)), int(llround(p.y)),},
		{int(llround(d.w)), int(llround(d.h)),}, };
	return outp;
}



template<class Txv>
HfTPt<Txv>::HfTPt( std::initializer_list<Txv> inp )
{
	assert( inp.size() == 2 );
	x = inp.begin()[0];
	y = inp.begin()[1];
}
template<class Txv>
HfTPt<Txv> HfTPt<Txv>::getMaxWith( const HfTPt<Txv>& otherr )const
{
	HfTPt<Txv> ou = { std::max( x, otherr.x ), std::max( y, otherr.y ),};
	return ou;
}
template<class Txv>
HfTPt<Txv> HfTPt<Txv>::getMinWith( const HfTPt<Txv>& otherr )const
{
	HfTPt<Txv> ou = { std::min( x, otherr.x ), std::min( y, otherr.y ),};
	return ou;
}

// instantiations #1.
template class HfTDim<int>;
template class HfTDim<float>;
template class HfTDim<double>;
// instantiations #2.
template class HfTRct<int>;
template class HfTRct<float>;
template class HfTRct<double>;
// instantiations #3.
template class HfTMidRct<int>;
template class HfTMidRct<float>;
template class HfTMidRct<double>;
// instantiations #4.
template class HfTPt<int>;
template class HfTPt<float>;
template class HfTPt<double>;


/// Scales segment given scale-factor and origin.
/// \param flags2 - flags, eg. \ref HF_SGF_Prevent0Len.
template<class Txi,class Txf> void HfSegmentHO<Txi,Txf>::
scaleAtOriginOrAtEdge( Txf scale2, Txi orig2, int flags2 )
{
	Txi endd = Pos2 + Len2;
	orig2 = std::min( std::max( orig2, Pos2 ), endd );

	Txi a2 = orig2 - Pos2;
	Txi b2 = endd  - orig2;
	Txi a3 = a2 * scale2;
	Txi b3 = b2 * scale2;

	Pos2 = orig2 - a3;
	endd = orig2 + b3;
	Len2 = endd  - Pos2;
	if( flags2 & HF_SGF_Prevent0Len && !Len2 ){
		Len2 = 1;
	}
}
/**
	Returns difference computed with the other segment.
	Reurns portions as std::vector<> of always 2 elements in size.
    Returned portions with positive length are within [otherr] segment,
    while portions with negative length are withing [this] segment.
    Negative portions need to be inverted with getInverted() if intended to be used
    correctly with other positive portions.
*/
template<class Txi,class Txf> std::vector<HfSegmentHO<Txi,Txf> > HfSegmentHO<Txi,Txf>::
getDifference( const HfSegmentHO<Txi,Txf>& otherr )const
{
	std::vector<HfSegmentHO<Txi,Txf> > outp;
	outp.emplace_back( HfSegmentHO<Txi,Txf>( otherr.Pos2, Pos2 - otherr.Pos2 ) );
	outp.emplace_back( HfSegmentHO<Txi,Txf>( getEndPos(), otherr.getEndPos() - getEndPos() ) );
	for( auto& a : outp ){
		if( a.Len2 >= 0 ){
            a = a.getClipped( otherr );
		}else{
			a = a.getInverted();
			a = a.getClipped( *this );
			a = a.getInverted();
		}
	}
	return outp;
}

/// Returns result of clipping against the other segment.
template<class Txi,class Txf>
HfSegmentHO<Txi,Txf>
HfSegmentHO<Txi,Txf>::
getClipped( const HfSegmentHO<Txi,Txf>& oth )const
{
	Txi l = Pos2, r = getEndPos(), l2 = oth.Pos2, r2 = oth.getEndPos();
	if( r2 < r )
		r = r2;
	if( l2 > l )
		l = l2;
	if( l > r )
		l = r;
	return HfSegmentHO<Txi,Txf>( l, r-l );
}
template<class Txi,class Txf> HfSegmentHO<Txi,Txf> HfSegmentHO<Txi,Txf>::
getInverted()const
{
	HfSegmentHO<Txi,Txf> x;// = *this;
	x.Pos2 = Pos2 + Len2;
	x.Len2 = -Len2;
	return x;
}
template<class Txi,class Txf> void HfSegmentHO<Txi,Txf>::
makeAbsoluteIfLenNeg()
{
	if( Len2 < 0 ){
		*this = getInverted();
	}
}
/// Test routines as static member functopm.
/// Uses printf calls to show some data.
template<class Txi,class Txf> void HfSegmentHO<Txi,Txf>::
simpleSegmentTests2()
{
	HfSegmentHO<int,float> other2( 5, 16-5 );
	printf("==this==, [other2]\n");
	printf("other2: %-2d,%-2d\n", other2.Pos2, other2.Len2 );
	std::vector<HfSegmentHO<int,float> > ls2;
	ls2.push_back( {8,13-8,} );
	ls2.push_back( {12,19-12,} );
	ls2.push_back( {2,11-2,} );
	ls2.push_back( {4,17-4,} );
	ls2.push_back( {1,4-1,} );
	ls2.push_back( {18,21-18,} );
	for( const auto a : ls2 ){
		auto ls3 = a.getDifference( other2 );
		for( int i=0; i<28; i++ ){
			if( i == other2.Pos2 ){
				printf("[");
			}else if( i == other2.getEndPos()-1 ){
				printf("]");
			}else if( i >= a.Pos2 && i < a.getEndPos() ){
				printf("=");
			}else{
				printf(".");
			}
		}
		printf(" %-2d,%-2d --> %-2d,%-2d; %-2d,%-2d\n",
			a.Pos2, a.Len2,
			ls3[0].Pos2, ls3[0].Len2,
			ls3[1].Pos2, ls3[1].Len2 );
	}
}
template<class Txi, class Txf> std::vector<HfSegmentHO<Txi,Txf> > HfSegmentHO<Txi,Txf>::
resizeAtOriginOrAtEdge( Txi len2, Txi orig2 )
{
	orig2 = std::max( std::min( getEndPos(), orig2 ), Pos2 );
	Txf fLeftSidePerc = Txf(orig2 - Pos2) / Len2;
	Txi a = Txi( fLeftSidePerc * len2 );
	Txi b = len2 - a;

	HfSegmentHO<Txi,Txf> seg2;
	seg2.Pos2 = orig2 - a;
	seg2.Len2 = ( orig2 + b ) - seg2.Pos2;

	auto lsx = seg2.getDifference( *this );
//	auto lsx = getDifference( seg2 );
//	for( auto& a : lsx )
//		if( a.Len2 < 0 )
//			a = a.getInverted();
	Pos2 = seg2.Pos2;
	Len2 = seg2.Len2;
	return lsx;
}
/// Constructor.
template<class Txi, class Txf> HfEnclosure<Txi,Txf>::
HfEnclosure( Txi posStrch, Txi lenStrch, Txi posSeg, Txi lenSeg )
	: Strch(posStrch,lenStrch), Seg(posSeg,lenSeg)
{
}
template<class Txi, class Txf> HfSegmentHO<Txi,Txf> HfEnclosure<Txi,Txf>::
getSegment()const
{
	return Seg;
}
template<class Txi, class Txf> HfSegmentHO<Txi,Txf> HfEnclosure<Txi,Txf>::
getStretch()const
{
	return Strch;
}
template<class Txi, class Txf> std::vector<HfSegmentHO<Txi,Txf> > HfEnclosure<Txi,Txf>::
scaleSegmentAtOriginOrAtEdge( Txf scale2, Txi orig2, int flags2 )
{
	HfSegmentHO<Txi,Txf> seg2 = Seg;
	seg2.scaleAtOriginOrAtEdge( scale2, orig2, flags2 );
	auto lsx = Seg.getDifference( seg2 );
	Seg = seg2;
	clipAgainstStretch( lsx );
	return lsx;
}
template<class Txi, class Txf> std::vector<HfSegmentHO<Txi,Txf> > HfEnclosure<Txi,Txf>::
resizeSegmentAtOriginOrAtEdge( Txi len2, Txi orig2 )
{
	HfSegmentHO<Txi,Txf> seg2 = Seg;
	auto lsx = seg2.resizeAtOriginOrAtEdge( len2, orig2 );
	//auto lsx = Seg.getDifference( seg2 );
	Seg = seg2;
	clipAgainstStretch( lsx );
	return lsx;
}

/// Resets segment to new position and length, and returns dirty segments.
template<class Txi, class Txf> std::vector<HfSegmentHO<Txi,Txf> > HfEnclosure<Txi,Txf>::
resetSegment( const HfSegmentHO<Txi,Txf>& seg2 )
{
	auto lsx = seg2.getDifference( Seg );
	Seg = seg2;
	clipAgainstStretch( lsx );
//	HfSegmentHO<Txi,Txf> seg3 = Seg;
//	orig4.second = ( orig4.first ? orig4.second : Seg.Pos2 );
//	orig4.second = std::max( std::min( Seg.getEndPos(), orig4.second ), Seg.Pos2 );
	return lsx;
}

/// Returns portion, part of the inner-segment within the outer stretch.
/// Returned portion is empty in case if inner-segment is completely
/// outside the stretch.
/// position of the returned portion is absolute, ie. it is not an
/// offset withing the outer-stretch.
template<class Txi, class Txf> HfSegmentHO<Txi,Txf> HfEnclosure<Txi,Txf>::
getPortion()const
{
	if( Seg.Pos2 < Strch.getEndPos() && Seg.getEndPos() > Strch.Pos2 ){
		Txi pos2 = std::max( Seg.Pos2, Strch.Pos2 );
		Txi endd = std::min( Seg.getEndPos(), Strch.getEndPos() );
		return HfSegmentHO<Txi,Txf>( pos2, endd - pos2 );
	}
	return HfSegmentHO<Txi,Txf>( 0, 0 );
}
template<class Txi, class Txf> HfSegmentHO<Txi,Txf> HfEnclosure<Txi,Txf>::
getPortionOfSegment()const
{
	auto prtn = getPortion();
	if( !prtn.Len2 )
		return HfSegmentHO<Txi,Txf>( 0, 0 );
	HfSegmentHO<Txi,Txf> seg_prtn;
	seg_prtn.Pos2 = prtn.Pos2 - Seg.Pos2;
	seg_prtn.Len2 = prtn.Len2;
	return seg_prtn;
}
template<class Txi, class Txf> void HfEnclosure<Txi,Txf>::
clipAgainstStretch( std::vector<HfSegmentHO<Txi,Txf> >& inp )const
{
	for( auto& a : inp ){
		if( a.Len2 >= 0 ){
			a = a.getClipped( Strch );
		}else{
			a = a.getInverted();
			a = a.getClipped( Strch );
			a = a.getInverted();
		}
	}
}
/// Sets stretch component to new value.
/// If returned segment is not empty, it is a dirty part of the inner segment.
template<class Txi, class Txf> HfSegmentHO<Txi,Txf> HfEnclosure<Txi,Txf>::
resetStretch( const HfSegmentHO<Txi,Txf>& stretch2 )
{
	HfSegmentHO<Txi,Txf> seg2(0,0);
	std::vector<HfSegmentHO<Txi,Txf> > lsx = stretch2.getDifference( Strch );
	for( auto& a : lsx ){
		if( a.Len2 < 0 ){
			a = a.getInverted();
			a = a.getClipped( Seg );
			seg2 = a;
			break;
		}
	}
	Strch = stretch2;
	return seg2;
}
template<class Txi, class Txf> bool HfEnclosure<Txi,Txf>::
isSegmentCompletelyInside()const
{
	auto prtn = getPortion();
	if( prtn.Len2 == Seg.Len2 ){
		return 1;
	}
	return 0;
}


/// Constructor.
template<class Txi, class Txf> HfScaledEnclosure<Txi,Txf>::
HfScaledEnclosure( Txi posStrch, Txi lenStrch, Txi posSeg, Txi lenSeg )
	: HfEnclosure<Txi,Txf>( posStrch, lenStrch, posSeg, lenSeg )
	, OrigSeg( posSeg, lenSeg )//, fZoom(1)
{
}

/// Returns unscaled portion.
/// This function is a complemnent to HfEnclosure<>::getPortionOfSegment(),
/// which in turn returns scaled portion.
template<class Txi,class Txf> HfSegmentHO<Txi,Txf> HfScaledEnclosure<Txi,Txf>::
getPortionOfSegmentUnscaled()const
{
	auto prtn = this->getPortionOfSegment();
	auto seg  = this->getSegment();
	Txf fBgnPos = Txf(prtn.Pos2)        / seg.Len2;
	Txf fEndPos = Txf(prtn.getEndPos()) / seg.Len2;
	HfSegmentHO<Txi,Txf> outp;
	outp.Pos2 = Txi( fBgnPos * OrigSeg.Len2 );
	outp.Len2 = Txi( fEndPos * OrigSeg.Len2 ) - outp.Pos2;
	return outp;
}
// Instantiations [ost3v7qvhf8m]
template struct HfSegmentHO<int,float>;
template struct HfSegmentHO<int,double>;
template struct HfEnclosure<int,float>;
template struct HfEnclosure<int,double>;
template struct HfScaledEnclosure<int,float>;
template struct HfScaledEnclosure<int,double>;
} // end namespace hef
