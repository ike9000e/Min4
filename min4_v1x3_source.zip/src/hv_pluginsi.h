
#ifndef HV_PLUGINSI_H_INCLUDED
#define HV_PLUGINSI_H_INCLUDED

struct HvxImageLoadInit
{
	int         nColumns, nRows;
	void*       pInternal;
};
struct HvxLoadImageData
{
	const char* filename;
	void*       pInternal;
	bool(*fnLoadInit)( const HvxImageLoadInit*, void* pInternal );
	bool(*fnEachLine)( const uint32_t* data2, void* pInternal );
};

struct HvxCYLTI
{
	const char* filename;
	void*       pInternal;
};

struct HvxPluginInitData
{
	const char*  szConfigStr;
	void*        pInternal;
};

#ifndef HVX_NOT_PLUGIN
	// For plugin creators, all you have to do is NOT to have
	// HVX_NOT_PLUGIN defined in your project.
	extern "C"{
		bool   HvxPluginInit( const HvxPluginInitData* );
		void   HvxPluginDeinit();
		void   HvxGetFileExtHints( void(*fnAddExt)( const char* szExt, void* i ), void* i );
		bool   HvxLoadImage( const HvxLoadImageData* );
		bool   HvxCanYouLoadThisImage( const HvxCYLTI* );
	}
#endif
typedef bool(*HvxPluginInit_t)( const HvxPluginInitData* );
typedef void(*HvxPluginDeinit_t)();
typedef void(*HvxGetFileExtHints_t)( void(*fnAddExt)( const char* szExt, void* i ), void* i );
typedef bool(*HvxLoadImage_t)( const HvxLoadImageData* );
typedef bool(*HvxCanYouLoadThisImage_t)( const HvxCYLTI* );

#endif //HV_PLUGINSI_H_INCLUDED
