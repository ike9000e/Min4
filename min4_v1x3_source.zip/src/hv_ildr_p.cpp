#include "hv_ildr_p.h"
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "png/png.h"


//void readpng_version_info()
void HvPNGReadPngVersionInfo()
{
	printf("LIBPNG Compiled with ver %s; using ver %s.\n",
			PNG_LIBPNG_VER_STRING, png_libpng_ver );
}

// ref: https://gist.github.com/niw/5963798
// -    http://zarb.org/~gc/html/libpng.html
bool
HvPNGReadFileIntrnl( const char* szFilename,
			std::function<bool(const HvImageReadInfo&)> calbEachScanline )
{
	int         width2 = 0, height2 = 0;
	png_byte    color_type = 0;
	png_byte    bit_depth = 0;

	FILE* fpx = fopen( szFilename, "rb" );
	if( !fpx )
		return 0;

	png_structp png_ptr = png_create_read_struct(PNG_LIBPNG_VER_STRING, NULL, NULL, NULL);
	if(!png_ptr){
		fclose(fpx);
		return 0; //abort();
	}
	png_infop info = png_create_info_struct(png_ptr);
	if(!info){
		png_destroy_read_struct( &png_ptr, 0, (png_infopp)0 );
		fclose(fpx);
		return 0;
	}
	if(setjmp(png_jmpbuf(png_ptr))){
		png_destroy_read_struct( &png_ptr, &info, (png_infopp)0 );
		fclose(fpx);
		return 0;
	}
	png_init_io(png_ptr, fpx);

	png_read_info(png_ptr, info);

	width2     = png_get_image_width(png_ptr, info);
	height2    = png_get_image_height(png_ptr, info);
	color_type = png_get_color_type(png_ptr, info);
	bit_depth  = png_get_bit_depth(png_ptr, info);
	printf("PNG image WxH: %d,%d\n", width2, height2 );
	int number_of_passes = 1;
	int interlace_type = 0;
	png_get_IHDR( png_ptr, info, 0,0,0,0, &interlace_type, 0, 0 );

	// Read any color_type into 8bit depth, RGBA format.
	// See http://www.libpng.org/pub/png/libpng-manual.txt

	if(bit_depth == 16)
		png_set_strip_16(png_ptr);

	if(color_type == PNG_COLOR_TYPE_PALETTE)
		png_set_palette_to_rgb(png_ptr);

	// PNG_COLOR_TYPE_GRAY_ALPHA is always 8 or 16bit depth.
	if(color_type == PNG_COLOR_TYPE_GRAY && bit_depth < 8)
		png_set_expand_gray_1_2_4_to_8(png_ptr);

	if(png_get_valid(png_ptr, info, PNG_INFO_tRNS))
		png_set_tRNS_to_alpha(png_ptr);

	// These color_type don't have an alpha channel then fill it with 0xff.
	if(color_type == PNG_COLOR_TYPE_RGB ||
				color_type == PNG_COLOR_TYPE_GRAY ||
				color_type == PNG_COLOR_TYPE_PALETTE)
		png_set_filler( png_ptr, 0xFF, PNG_FILLER_AFTER );

	if( color_type == PNG_COLOR_TYPE_GRAY || color_type == PNG_COLOR_TYPE_GRAY_ALPHA )
		png_set_gray_to_rgb(png_ptr);
	if( interlace_type == PNG_INTERLACE_ADAM7 )
		number_of_passes = png_set_interlace_handling( png_ptr );

	printf("PNG number_of_passes: %d\n", number_of_passes );

	png_read_update_info(png_ptr, info);

//	png_bytep* row_pointers = 0;
//	row_pointers = reinterpret_cast<png_bytep*>(malloc( sizeof(png_bytep) * height2 ));
//	for( int y = 0; y < height2; y++ ){
//		row_pointers[y] = reinterpret_cast<png_byte*>(malloc(png_get_rowbytes(png_ptr,info)));
//	}
//	png_read_image(png_ptr, row_pointers);

	//png_read_rows( png_ptr, row_pointers, NULL, number_of_rows);
	//png_bytep row_pointer = row;
	//png_read_row(png_ptr, row_pointer, 0 );
	std::vector<uint32_t> data2( width2, 0 );
	HvImageReadInfo rii( data2 );
	rii.uRow     = 0;
	rii.nNumCols = width2;
	rii.nNumRows = height2;
	rii.nBtPerPx = 4;

	int num_row_bytes = png_get_rowbytes(png_ptr,info);
	printf("PNG num_row_bytes: %d\n", num_row_bytes );

	png_byte* row_pointer = reinterpret_cast<png_byte*>( malloc( num_row_bytes ) );
	for( int i=0; i < number_of_passes; i++ ){ // more than 1 for interlaced mode PNGs.
		if( i+1 < number_of_passes ){ // if is not last interlaced pass.
			// from analysing source code, it looks like at least one of 2 parameters
			// for png_read_rows(), 'row' or 'display_row',
			// must not be null for it to work correctly.
			//png_read_rows( png_ptr, &row_pointer, 0, height2 );
			for( int y = 0; y < height2; y++ )
				png_read_row( png_ptr, row_pointer, 0 );
		}else{ // else, is last interlaced pass.
			for( int y = 0; y < height2; y++ ){
				png_read_row( png_ptr, row_pointer, 0 );
				for( int k=0; k<width2; k++ ){ //PNG_FORMAT_RGBA,PNG_FORMAT_ARGB
					assert( k*4 < num_row_bytes );
					assert( k < (int)data2.size() );
					png_byte* px2 = &row_pointer[k*4];
					uint32_t px3 = 0;
					px3 |= (uint32_t(px2[2]) << 0); //2
					px3 |= (uint32_t(px2[1]) << 8); //1
					px3 |= (uint32_t(px2[0]) << 16); //0
					px3 |= (uint32_t(px2[3]) << 24); //3
					data2[k] = px3;
				}
				rii.uRow = y;
				calbEachScanline( rii );
			}
		}
	}
	free(row_pointer);
	row_pointer = 0;
	// deinit.
	png_destroy_read_struct( &png_ptr, &info, 0 );
//	for( int y = 0; y < height2; y++ ){
//		assert( row_pointers[y] );
//		free( row_pointers[y] );
//		row_pointers[y] = 0;
//	}
//	free(row_pointers);

	fclose(fpx);
	return 1;
}
