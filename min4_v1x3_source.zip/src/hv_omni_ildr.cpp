#include "hv_omni_ildr.h"
#include <assert.h>
#include <string.h>
#include <dlfcn.h>
#include <unistd.h>
#include <stdlib.h>
#include <limits.h>
#include "hef/hef_filesystem.h"
#include "hef/hef_file.h"
#include "hef/hef_call.h"
#include "hv_pluginsi.h"
using namespace hef;

HvOmniImageLoader::HvOmniImageLoader()
{
}
std::vector<std::string> HvOmniImageLoader::
getCommaExtHints( std::string filename2 )
{
	std::vector<std::string> outp;
	std::string str = hf_basename3( filename2.c_str(), 0, 32 ).first;
	std::vector<std::string> exts2;
	hf_explode<char>( str.c_str(), ",", exts2, "\x20\r\n\t", -1 );
	if( !exts2.empty() ){
		exts2.erase( exts2.begin() );
		outp = exts2;
	}
	return outp;
}
bool HvOmniImageLoader::oixTryLoadImage( const STryLoad& inp )
{
	if( Plugins2.empty() ){
		HfDirContents dcn( szPluginsDir, 0 );
		HfDirContents::SFile sff;
		while( dcn.getNextFile( sff ) ){
			std::string bnm2 = hf_basename( sff.fname.c_str() );
			std::string fn2 = ( szPluginsDir + std::string("/") + bnm2 );
			if( hf_FileExists( fn2.c_str() ) ){
				if( !strncmp( "min4il_", bnm2.c_str(), 7 ) ){
					printf("Possible loader plugin: [%s]\n", bnm2.c_str() );
					fn2 = hf_Realpath( fn2.c_str(), "" );
					if( hf_FileExists( fn2.c_str() ) ){
						printf("Loader: [%s]\n", fn2.c_str() );
						SLdr slr2;
						slr2.ssRealPath = fn2;
						slr2.ssLibName  = bnm2;
						slr2.ExtHints   = getCommaExtHints( bnm2.c_str() );
						slr2.ident2     = ++LastId;
						printf("Num exts: %ld\n", slr2.ExtHints.size() );
						Plugins2.push_back( slr2 );
					}
				}
			}
		}
	}
	return tryLoadImage2( inp );
}
HvOmniImageLoader::~HvOmniImageLoader()
{
	for( auto& a : Plugins2 ){
		std::string str = hf_basename( a.ssRealPath.c_str() );
		printf("Unloading plugin: [%s]\n", str.c_str() );
		if( a.HvxPluginDeinit )
			a.HvxPluginDeinit();
		dlclose( a.hDll3 );
	}
	Plugins2.clear();
}


bool HvOmniImageLoader::loadPluginIfNeeded( SLdr& inp )
{
	if( inp.isLoaded() )
		return 1;
	if( inp.isLoadable() ){
		const std::string fn3 = inp.ssRealPath;
		//if( !hf_FileExists( inp.ssRealPath.c_str() ) ){
		//	printf("ERROR: plugin file not found [e4VOaEeg]\n");
		//	printf("       [%s]\n", fn3.c_str() );
		//	inp.bValid = 0;
		//}
		void* hDll2 = dlopen( fn3.c_str(), RTLD_LAZY );  //RTLD_LOCAL,RTLD_GLOBAL,RTLD_LAZY
		if( !hDll2 ){
			const char* szErr = dlerror();
			szErr = ( szErr ? szErr : "<none>" );
            std::vector<std::string> lns3;
            std::vector<std::string>::const_iterator a;
			hf_split( szErr, 52, lns3 );
			printf("ERROR: Plugin loading failed. Function dlopen() returned null [m4k7QqUO]\n");
			printf("       [%s]\n", hf_MidTruncateStr<char>( fn3, 60, " ... " ).c_str() );
			int i=0;
			for( a = lns3.begin(); a != lns3.end(); ++a, i++ ){
				if( !i ){
					printf("       Message: %s\n", a->c_str() );
				}else
					printf("                %s\n", a->c_str() );
			}
			inp.bValid = 0;
			return 0;
		}else{
			inp.hDll3 = hDll2;
			//using fn2_t = int(*)(int,int);
			//fn2_t fnc2 = reinterpret_cast<fn2_t>( dlsym( inp.hDll3, "fnTestDllExport" ) );
			//assert(fnc2);
			//printf("fnc2: [%d]\n", fnc2(1,2) );
			inp.HvxPluginInit =
				reinterpret_cast<HvxPluginInit_t>(
					dlsym( inp.hDll3, "HvxPluginInit" ) );
			inp.HvxPluginDeinit =
				reinterpret_cast<HvxPluginDeinit_t>(
					dlsym( inp.hDll3, "HvxPluginDeinit" ) );
			inp.HvxGetFileExtHints =
				reinterpret_cast<HvxGetFileExtHints_t>(
					dlsym( inp.hDll3, "HvxGetFileExtHints" ) );
			inp.HvxLoadImage =
				reinterpret_cast<HvxLoadImage_t>(
					dlsym( inp.hDll3, "HvxLoadImage" ) );
			inp.HvxCanYouLoadThisImage =
				reinterpret_cast<HvxCanYouLoadThisImage_t>(
					dlsym( inp.hDll3, "HvxCanYouLoadThisImage" ) );

			if( !inp.HvxLoadImage ){
				std::string bn2 = hf_basename( inp.ssLibName.c_str() );
				printf("WARN: Plugin doesn't provide 'HvxLoadImage' function.\n");
				printf("      [%s]\n", bn2.c_str() );
				inp.bValid = 0;
			}
			HvxPluginInitData ida;
			ida.pInternal   = 0;
			ida.szConfigStr = "";
			if( inp.HvxPluginInit )
				inp.HvxPluginInit( &ida );

			if( inp.HvxGetFileExtHints ){
				HfCallWithType<int, std::string>(
					[&]( void* ptrIntrnl ){
						inp.HvxGetFileExtHints(
							[&]( const char* szExt, void* ptrIntrnl ){
								assert(ptrIntrnl);
								HfCallWithTypeUnwrap<int,std::string>( ptrIntrnl, szExt );
								//fnc2( ptrIntrnl, szExt );
							}, ptrIntrnl
						);
					},
					[&]( int, std::string ssExt ){
						auto b = std::find( inp.ExtHints.begin(), inp.ExtHints.end(), ssExt );
						if( b == inp.ExtHints.end() ){
							inp.ExtHints.push_back( ssExt );
						}
						return 1;
				}, -1, 0 );
			}
			inp.bInited = 1;
			return inp.bValid;
		}
	}
	return 0;
}
bool HvOmniImageLoader::tryLoadImage3( const SLdr& ldr2, const STryLoad& inp )
{
	assert( ldr2.HvxLoadImage );
	using params_t = std::pair<const HvxImageLoadInit*,const uint32_t*>;
	int iRow = 0;
	bool rs2 = 0;
	HfCallWithType<int,params_t>(
		[&]( void* i ){
			HvxLoadImageData lii;
			lii.pInternal  = i;
			lii.filename   = inp.filename;
			lii.fnLoadInit = []( const HvxImageLoadInit* in2, void* i )->bool{
				return !!HfCallWithTypeUnwrap<int,params_t>( i, params_t( in2, 0 ) );
			};
			lii.fnEachLine = []( const uint32_t* data2, void* i )->bool{
				return !!HfCallWithTypeUnwrap<int,params_t>( i, params_t( 0, data2 ) );
			};
			rs2 = ldr2.HvxLoadImage( &lii );
		},
		[&]( int, params_t in3 )->int{
			if( in3.first ){
				int rezz[2] = { in3.first->nColumns, in3.first->nRows, };
				printf("INFO: init image loading, %d*%d\n", rezz[0], rezz[1] );
				return inp.fnLoadInit2( rezz[0], rezz[1] );
			}else{
				printf("INFO: new inage row: %d\n", iRow++ );
				assert( in3.second );
				return inp.fnEachLine2( in3.second );
			}
		},
		-1, ""
	);
	return rs2;//*/
	//return 0;
}
bool HvOmniImageLoader::tryLoadImage2( const STryLoad& inp )
{
	std::vector<SLdr>::iterator a;
	std::vector<int> aFailedLoaders;
	{
		std::vector<SLdr>::iterator ldr = Plugins2.end();
		const std::vector<SLdr>::iterator endd = Plugins2.end();
		std::string ext2 = hf_basename3( inp.filename, 0, 32 ).second;
		if( !ext2.empty() ){
			for( a = Plugins2.begin(); a != Plugins2.end() && ldr == endd; ++a ){
				auto b = std::find( a->ExtHints.begin(), a->ExtHints.end(), ext2 );
				if( b != a->ExtHints.end() ){
					printf("INFO: Plugin match by filename comma-ext pattern [%s]\n", ext2.c_str() );
					if( loadPluginIfNeeded( *a ) ){
						ldr = a;
						break;
					}
				}
			}
			for( a = Plugins2.begin(); a != Plugins2.end() && ldr == endd; ++a ){
				if( loadPluginIfNeeded(*a) ){
					auto b = std::find( a->ExtHints.begin(), a->ExtHints.end(), ext2 );
					if( b != a->ExtHints.end() ){
						printf("INFO: Plugin match by ext-hint [%s]\n", ext2.c_str() );
						ldr = a;
						break;
					}
				}
			}
		}
		// if some plugin has been found based on match conditions above,
		// try loading the image with it.
		if( ldr != endd ){
			assert( ldr->HvxLoadImage );
			if( tryLoadImage3( *ldr, inp ) )
				return 1;
			aFailedLoaders.push_back( ldr->ident2 );
		}
	}
	// try loading the image based on 'HvxCanYouLoadThisImage' export,
	// if plugin has it. iterate plugins, if the plugin has
	// been already tried, skip it.
	for( a = Plugins2.begin(); a != Plugins2.end(); ++a ){
		auto b = std::find( aFailedLoaders.begin(), aFailedLoaders.end(), a->ident2 );
		if( b == aFailedLoaders.end() ){
			if( loadPluginIfNeeded(*a) ){
				if( a->HvxCanYouLoadThisImage ){
					HvxCYLTI scti;
					scti.filename  = inp.filename;
					scti.pInternal = 0;
					if( a->HvxCanYouLoadThisImage( &scti ) ){
						assert( a->HvxLoadImage );
						if( tryLoadImage3( *a, inp ) )
							return 1;
						aFailedLoaders.push_back( a->ident2 );
					}
				}
			}
		}
	}
	//
	// finally, try all remaining plugins and try load just via the
	// load-image function.
	for( a = Plugins2.begin(); a != Plugins2.end(); ++a ){
		auto b = std::find( aFailedLoaders.begin(), aFailedLoaders.end(), a->ident2 );
		if( b == aFailedLoaders.end() ){
			if( loadPluginIfNeeded(*a) ){
				assert( a->HvxLoadImage );
				if( tryLoadImage3( *a, inp ) )
					return 1;
				aFailedLoaders.push_back( a->ident2 );
			}
		}
	}
	return 0;
}





