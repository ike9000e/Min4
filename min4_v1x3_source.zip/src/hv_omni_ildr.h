#include "hv_vpimg_g.h"
#include <vector>
#include <string>
#include "hv_pluginsi.h"

struct HvOmniImageLoader : HvOmniLdr
{
	;            HvOmniImageLoader();
	;            ~HvOmniImageLoader();
	virtual bool oixTryLoadImage( const STryLoad& inp )override;
private:
	struct SLdr;
	bool tryLoadImage2( const STryLoad& inp );
	bool tryLoadImage3( const SLdr& ldr2, const STryLoad& inp );
	bool loadPluginIfNeeded( SLdr& inp );
	static std::vector<std::string> getCommaExtHints( std::string fn2 );
private:
	struct SLdr{
		std::string              ssLibName, ssRealPath;
		int                      ident2 = -1;
		void*                    hDll3 = 0;
		bool                     bValid = 1, bInited = 0;
		std::vector<std::string> ExtHints;

		HvxPluginInit_t          HvxPluginInit = 0;
		HvxPluginDeinit_t        HvxPluginDeinit = 0;
		HvxGetFileExtHints_t     HvxGetFileExtHints = 0;
		HvxLoadImage_t           HvxLoadImage = 0;
		HvxCanYouLoadThisImage_t HvxCanYouLoadThisImage = 0;

		bool isLoaded()const{ return (hDll3 && bValid); }
		bool isLoadable()const{ return (!hDll3 && bValid); }
	};
	const char* szPluginsDir = "./loaders";
	std::vector<SLdr> Plugins2;
	int LastId = 2000;
};
