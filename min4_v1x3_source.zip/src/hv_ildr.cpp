//
// This file is based on "example.c",
// location: "https://github.com/LuaDist/libjpeg/blob/master/example.c"
//
#include "hv_ildr.h"
#include <stdio.h>
#include <unistd.h>
#include <assert.h>
#include <string.h>


// Include file for users of JPEG library.
// You will need to have included system headers that define at least
// the typedefs FILE and size_t before you can include jpeglib.h.
// (stdio.h is sufficient on ANSI-conforming systems.)
// You may also wish to include "jerror.h".

#include "jpeg/jpeglib.h"
#include "jpeg/jversion.h"   //JVERSION

// <setjmp.h> is used for the optional error recovery mechanism shown in
// the second part of the example.

#include <setjmp.h>


/******************** JPEG DECOMPRESSION SAMPLE INTERFACE *******************/

/* This half of the example shows how to read data from the JPEG decompressor.
 * It's a bit more refined than the above, in that we show:
 *   (a) how to modify the JPEG library's standard error-reporting behavior;
 *   (b) how to allocate workspace using the library's memory manager.
 *
 * Just to make this example a little different from the first one, we'll
 * assume that we do not intend to put the whole image into an in-memory
 * buffer_, but to send it line-by-line someplace else.  We need a one-
 * scanline-high JSAMPLE array as a work buffer_, and we will let the JPEG
 * memory manager allocate it for us.  This approach is actually quite useful
 * because we don't need to remember to deallocate the buffer_ separately: it
 * will go away automatically when the JPEG object is cleaned up.
 */


/*
 * ERROR HANDLING:
 *
 * The JPEG library's standard error handler (jerror.c) is divided into
 * several "methods" which you can override individually.  This lets you
 * adjust the behavior without duplicating a lot of code, which you might
 * have to update with each future release.
 *
 * Our example here shows how to override the "error_exit" method so that
 * control is returned to the library's caller when a fatal error occurs,
 * rather than calling exit() as the standard error_exit method does.
 *
 * We use C's setjmp/longjmp facility to return control.  This means that the
 * routine which calls the JPEG library must first execute a setjmp() call to
 * establish the return point.  We want the replacement error_exit to do a
 * longjmp().  But we need to make the setjmp buffer_ accessible to the
 * error_exit routine.  To do this, we make a private extension of the
 * standard JPEG error handler object.  (If we were using C++, we'd say we
 * were making a subclass of the regular error handler.)
 *
 * Here's the extended error handler struct:
 */

struct my_error_mgr {
  struct jpeg_error_mgr pub;	/* "public" fields */

  jmp_buf setjmp_buffer;	/* for return to caller */
};

typedef struct my_error_mgr * my_error_ptr;

/*
 * Here's the routine that will replace the standard error_exit method:
 */
METHODDEF(void)
my_error_exit (j_common_ptr cinfo)
{
  /* cinfo->err really points to a my_error_mgr struct, so coerce pointer */
  my_error_ptr myerr = (my_error_ptr) cinfo->err;

  /* Always display the message. */
  /* We could postpone this until after returning, if we chose. */
  (*cinfo->err->output_message) (cinfo);

  /* Return control to the setjmp point */
  longjmp(myerr->setjmp_buffer, 1);
}

void HvJPEGShowVersionInfo()
{
	printf("LIBJPEG ver %d.%d [%s]\n",
			JPEG_LIB_VERSION_MAJOR, JPEG_LIB_VERSION_MINOR, JVERSION );
}

/**
	Reads JPEG image given file name.

	\param szFilename - JPEG file name.
	\param calbEachScanline -
		Function called for each scan line (row) of the input JPEG image.
		For each line from top to bottom, pixels stored left-to-right.
		In callback parameter, in member 'inp.aLinePxs', single element of the vector
		array, type uint32_t, has the following pixel format: 0x00RRGGBB.
		Highest order byte is always zero.
		\code
			// For example, assuming color at 0, in HTML notation, is "#ff7700"
			printf("[-%08X-]", inp.aLinePxs[0] );
			// outputs: "[-00FF7700-]"
		\endcode
	old: read_JPEG_file()
*/
bool
HvJPEGReadFileIntrnl( const char* szFilename,
			std::function<bool(const HvImageReadInfo&)> calbEachScanline )
{
	/* This struct contains the JPEG decompression parameters and pointers to
	*  working space (which is allocated as needed by the JPEG library).
	*/
	struct jpeg_decompress_struct cinfo;
	/* We use our private extension JPEG error handler.
	*  Note that this struct must live as long as the main JPEG parameter
	*  struct, to avoid dangling-pointer problems.
	*/
	struct my_error_mgr jerr;
	/* More stuff */
	FILE * infile;		/* source file */
	JSAMPARRAY buffer2;	/* Output row buffer_ */
	int row_stride;		/* physical row width in output buffer_ */

	/* In this example we want to open the input file before doing anything else,
	*  so that the setjmp() error recovery below can assume the file is open.
	*  VERY IMPORTANT: use "b" option to fopen() if you are on a machine that
	*  requires it in order to read binary files.
	*/

	if ((infile = fopen(szFilename, "rb")) == NULL) {
		//fprintf(stderr, "can't open %s\n", szFilename);
		return 0;
	}

	/* Step 1: allocate and initialize JPEG decompression object */

	/* We set up the normal JPEG error routines, then override error_exit. */
	cinfo.err = jpeg_std_error(&jerr.pub);
	jerr.pub.error_exit = my_error_exit;
	/* Establish the setjmp return context for my_error_exit to use. */
	if (setjmp(jerr.setjmp_buffer)) {
		/* If we get here, the JPEG code has signaled an error.
		 * We need to clean up the JPEG object, close the input file, and return.
		 */
		jpeg_destroy_decompress(&cinfo);
		fclose(infile);
		return 0;
	}
	/* Now we can initialize the JPEG decompression object. */
	jpeg_create_decompress(&cinfo);

	/* Step 2: specify data source (eg, a file) */

	jpeg_stdio_src(&cinfo, infile);

	/* Step 3: read file parameters with jpeg_read_header() */

	(void) jpeg_read_header(&cinfo, TRUE);
	/* We can ignore the return value from jpeg_read_header since
	*    (a) suspension is not possible with the stdio data source, and
	*    (b) we passed TRUE to reject a tables-only JPEG file as an error.
	*  See libjpeg.txt for more info.
	*/

	/* Step 4: set parameters for decompression */

	/* In this example, we don't need to change any of the defaults set by
	*  jpeg_read_header(), so we do nothing here.
	*/

	/* Step 5: Start decompressor */

	(void) jpeg_start_decompress(&cinfo);
	/* We can ignore the return value since suspension is not possible
	*  with the stdio data source.
	*/

	/* We may need to do some setup of our own at this point before reading
	*  the data.  After jpeg_start_decompress() we have the correct scaled
	*  output image dimensions available, as well as the output colormap
	*  if we asked for color quantization.
	*  In this example, we need to make an output work buffer_ of the right size.
	*/
	/* JSAMPLEs per row in output buffer_ */
	row_stride = cinfo.output_width * cinfo.output_components;
	/* Make a one-row-high sample array that will go away when done with image */
	buffer2 = (*cinfo.mem->alloc_sarray)
		((j_common_ptr) &cinfo, JPOOL_IMAGE, row_stride, 1);

	/* Step 6: while (scan lines remain to be read) */
	/*           jpeg_read_scanlines(...); */

	/* Here we use the library's state variable cinfo.output_scanline as the
	*  loop counter, so that we don't have to keep track ourselves.
	*/
	std::vector<uint32_t> data2( cinfo.output_width, 0 );
	bool bAborded = 0;
	HvImageReadInfo inf( data2 );
	inf.uRow       = 0; // == cinfo.output_scanline
	inf.nNumCols   = cinfo.output_width;
	inf.nNumRows   = cinfo.output_height;
	inf.nBtPerPx   = cinfo.out_color_components;

	for( int i=0; cinfo.output_scanline < cinfo.output_height; i++ ){
		assert( i == static_cast<int>(cinfo.output_scanline) );
		// jpeg_read_scanlines expects an array of pointers to scanlines.
		// Here the array is only one element long, but you could ask for
		// more than one scanline at a time if that's more convenient.

		// typedef struct jpeg_decompress_struct* j_decompress_ptr;
		// typedef JSAMPLE FAR *JSAMPROW;	/* ptr to one image row of pixel samples. */
		// typedef JSAMPROW* JSAMPARRAY;	/* ptr to some rows (a 2-D sample array) */
		//
		// EXTERN(JDIMENSION) jpeg_read_scanlines JPP((j_decompress_ptr cinfo,
		//					    JSAMPARRAY scanlines,
		//					    JDIMENSION max_lines));
		// JSAMPARRAY buffer2; == typedef unsigned char JSAMPLE;
		//printf("%ld", sizeof(**buffer2) );//==1

		jpeg_read_scanlines( &cinfo, buffer2, 1 ); // Image data is returned in top-to-bottom scanline order.

		// make sure image is not rescalled by the jpeg library somewhere.
		assert( cinfo.output_height == cinfo.image_height );
		// make sure not using color map (aka indexed images (?)),
		// also 'cinfo.colormap' null.
		assert( !cinfo.actual_number_of_colors );
		assert( !cinfo.colormap );
		assert( cinfo.num_components == cinfo.out_color_components );
		// Pixels are stored by scanlines, with each scanline running from left to right.
		// The component values for each pixel are adjacent in the row. For
		// example, R,G,B,R,G,B,R,G,B,... for 24-bit RGB color.
		const uint8_t* ptrLinePxs = buffer2[0]; // zero is only valid index if 3rd param to read fnc was 1.
		if( cinfo.num_components == 3 ){
			for( size_t c=0, n=0; c < inf.nNumCols; c++ ){ // for each pixel in the row (scan-line).
				uint32_t pxx = 0; // "2.1 Data formats"
				for( size_t k = inf.nBtPerPx; k > 0; k--, n++ ){ //for each byte in the pixel.
					uint32_t x = ptrLinePxs[n];
					pxx |= (x << (8*(k-1)));
				}
				assert( c < data2.size() );
				// Assign alpha value to 255 default. Imlib2 interprets 255 as fully opaque.
				pxx |= 0xFF000000;
				data2[c] = pxx;
			}
		}else if( cinfo.num_components == 1 ){
			for( size_t n=0; n < inf.nNumCols; n++ ){
				uint32_t pxx = 0, x = ptrLinePxs[n];
				pxx |= x | (x<<8) | (x<<16) | 0xFF000000;
				assert( n < data2.size() );
				data2[n] = pxx;
			}
		}else{ // if unhandled number of bytes per pixel. assign all to single color.
			data2.clear();
			data2.resize( inf.nNumCols, 0xFFFF00FF );
		}
		//printf("occ %d\n", cinfo.out_color_components );
		inf.uRow = i; // == cinfo.output_scanline
		if( !calbEachScanline( inf ) ){  //jpeg_abort()//jpeg_destroy()
			bAborded = ( cinfo.output_scanline != cinfo.output_height );
			break;
		}
	}
	// Step 7: Finish decompression

	// It is an error to call jpeg_finish_decompress() before reading
	// the correct total number of scanlines. If you wish to abort
	// compression, call jpeg_abort() as discussed below (in HTML).
	if(!bAborded){
		//printf("calling jpeg_finish_decompress()\n");
		jpeg_finish_decompress(&cinfo);
		// We can ignore the return value since suspension is not possible
		// with the stdio data source.
	}

	/* Step 8: Release JPEG decompression object */

	/* This is an important step since it will release a good deal of memory. */
	jpeg_destroy_decompress(&cinfo);

	/* After finish_decompress, we can close the input file.
	* Here we postpone it until after no more JPEG errors are possible,
	* so as to simplify the setjmp error logic above.  (Actually, I don't
	* think that jpeg_destroy can do an error exit, but why assume anything...)
	*/
	fclose(infile);

	/* At this point you may want to check to see whether any corrupt-data
	*  warnings occurred (test whether jerr.pub.num_warnings is nonzero).
	*/

	/* And we're done! */
	return 1;
}
/*
 * SOME FINE POINTS:
 *
 * In the above code, we ignored the return value of jpeg_read_scanlines,
 * which is the number of scanlines actually read.  We could get away with
 * this because we asked for only one line at a time and we weren't using
 * a suspending data source.  See libjpeg.txt for more info.
 *
 * We cheated a bit by calling alloc_sarray() after jpeg_start_decompress();
 * we should have done it beforehand to ensure that the space would be
 * counted against the JPEG max_memory setting.  In some systems the above
 * code would risk an out-of-memory error.  However, in general we don't
 * know the output image dimensions before jpeg_start_decompress(), unless we
 * call jpeg_calc_output_dimensions().  See libjpeg.txt for more about this.
 *
 * Scanlines are returned in the same order as they appear in the JPEG file,
 * which is standardly top-to-bottom.  If you must emit data bottom-to-top,
 * you can use one of the virtual arrays provided by the JPEG memory manager
 * to invert the data.  See wrbmp.c for an example.
 *
 * As with compression, some operating modes may require temporary files.
 * On some systems you may need to set up a signal handler to ensure that
 * temporary files are deleted if the program is interrupted.  See libjpeg.txt.
 */
